// ComfyUI-MiniMaxH3-OneNode — single-node MiniMax H3 video + audio panel.
//
// Ported from the One Node family (Krea-2 image / Wan 2.2 video / LTX-2 video):
// the same lime-on-black in-panel UI, workflow-injection + /prompt submission,
// scanned model dropdowns, in-node download docs, and a headless build test.
// Retargeted to the native ComfyUI MiniMax H3 pipeline (PR #15224):
//
//   T2V / I2V / FLF  -> MiniMaxH3ImageToVideo  (fl2va weights)
//   R2V (references) -> MiniMaxH3ReferenceToVideo (ref2va weights)
//
// H3 generates video WITH native stereo audio in one pass, so there is no
// separate audio step. It is guidance-distilled: BasicGuider (positive-only),
// NO CFG and NO negative prompt. Sampler res_multistep + BasicScheduler.
//
// FULLY NAMESPACED so it coexists with the other One Node packages:
// extension "MiniMaxH3OneNode.v1", node class "MiniMaxH3OneNode",
// window.__mmh3_nodes, localStorage "minimaxh3_one_node_state",
// CSS keyframe prefix "mmh3-", routes "/minimaxh3/*", log tag "[MMH3]".
import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const VERSION = "v2.1";
const LIME = "#f0ff41";
const C = {
  bg0:"#0a0a0a", bg1:"#111", bg2:"#161616", bg3:"#1d1d1d",
  border:"#2a2a2a", text:"#e8e8e8", muted:"#888", accent:LIME,
};
const NODE_W = 1040;
// Taller than 16:9 on purpose: the left control column is dense (prompt + mode
// inputs + video + sampling + collapsibles), so a short node buried half of it
// behind an internal scrollbar. This height shows the everyday controls at once
// and gives the video preview real estate on the right.
const NODE_H = 720;
// The node is user-resizable. ComfyUI forces a freshly-created node to computeSize's
// floor, so these double as the default open size — chosen to show the everyday
// controls comfortably; the user can drag the node LARGER for a bigger preview.
const MIN_W = 1000, MIN_H = 700;
// Height litegraph reserves for the node title bar; the DOM panel gets the rest.
const TITLE_H = 30;
// Megapixel steps for the resolution preview table (mirrors the official workflow's
// size-reference note, but computed live for the chosen aspect ratio).
const MP_STEPS = [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.98, 1.2, 1.5, 1.8, 2.0];

const LS_KEY = "minimaxh3_one_node_state";

// H3 canvas / timing constants (from comfy_extras/nodes_minimax_h3.py)
const FPS = 24;
const MULTIPLE = 32;
const BASE_SHORT_EDGE = 768;
const MAX_PIXELS = 768 * 1344;      // model's area cap for the trained canvas
const LEN_MIN = 124;                 // ~5s  (trained low end)
const LEN_MAX = 362;                 // ~15s (trained high end)

// ResolutionSelector aspect ratios (exact list from comfy_extras/nodes_resolution.py)
const ASPECT = {
  "1:1 (Square)":[1,1],
  "2:3 (Portrait Photo)":[2,3],
  "3:2 (Photo)":[3,2],
  "3:4 (Portrait Standard)":[3,4],
  "4:3 (Standard)":[4,3],
  "9:16 (Portrait Widescreen)":[9,16],
  "16:9 (Widescreen)":[16,9],
  "21:9 (Ultrawide)":[21,9],
};
const ASPECT_KEYS = Object.keys(ASPECT);

const SAMPLERS = ["res_multistep","res_2m","euler","dpmpp_2m","dpmpp_2m_sde","uni_pc","deis","gradient_estimation"];
const SCHEDULERS = ["simple","beta","normal","karras","sgm_uniform","ddim_uniform","kl_optimal","linear_quadratic"];

const MAX_REF_IMAGES = 9;
const REF_IMAGES_SAFE = 5;   // MiniMax's recommended maximum for best identity
const MAX_REF_VIDEOS = 3;
const MAX_REF_AUDIOS = 3;

// ── math helpers (mirror the python exactly) ──────────────────────────────────
// ResolutionSelector: width/height from aspect + megapixels, rounded to `multiple`.
function calcRes(aspectKey, megapixels, multiple){
  const [wr,hr] = ASPECT[aspectKey] || [16,9];
  const total = megapixels * 1024 * 1024;
  const scale = Math.sqrt(total / (wr * hr));
  const w = Math.max(multiple, Math.round(wr * scale / multiple) * multiple);
  const h = Math.max(multiple, Math.round(hr * scale / multiple) * multiple);
  return { w, h };
}
// align_frame_count: smallest n>=input with n%17==5 (the model re-aligns anyway).
function alignLen(n){ n = Math.max(5, Math.round(n)); while(n % 17 !== 5) n++; return n; }
function durToLen(sec){ return alignLen(Math.max(5, Math.round(sec * FPS))); }

// ── DOM helpers (ported) ──────────────────────────────────────────────────────
const mk = (tag,css={},props={}) => { const e=document.createElement(tag); Object.assign(e.style,css); Object.assign(e,props); return e; };
const tx = (e,t) => { e.textContent=t; return e; };
const cap = (t) => tx(mk("div",{fontSize:"9px",fontWeight:"700",letterSpacing:".1em",textTransform:"uppercase",color:C.muted,margin:"0 0 5px"}),t);
function fmtErr(v){ if(v==null)return"unknown error"; if(typeof v==="string")return v; if(v instanceof Error)return v.message||String(v);
  try{ if(v.message)return v.message; return JSON.stringify(v); }catch(e){ return String(v); } }
function link(text,href){ return `<a href="${href}" target="_blank" style="color:${LIME};text-decoration:none">${text}</a>`; }

function Toggle(labelTxt,checked,onChange,activeColor){
  const wrap=mk("label",{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer",fontSize:"11px",color:C.text,userSelect:"none"});
  const track=mk("div",{width:"34px",height:"18px",borderRadius:"10px",background:checked?(activeColor||LIME):C.bg3,position:"relative",transition:"background .15s",flex:"0 0 auto",border:"1px solid "+C.border});
  const knob=mk("div",{width:"12px",height:"12px",borderRadius:"50%",background:checked?"#000":"#777",position:"absolute",top:"2px",left:checked?"18px":"3px",transition:"left .15s"});
  track.appendChild(knob);
  const lbl=tx(mk("span"),labelTxt);
  let val=checked;
  wrap.append(track,lbl);
  wrap.onclick=()=>{ val=!val; track.style.background=val?(activeColor||LIME):C.bg3; knob.style.left=val?"18px":"3px"; knob.style.background=val?"#000":"#777"; onChange(val); };
  wrap._set=(v)=>{ val=v; track.style.background=v?(activeColor||LIME):C.bg3; knob.style.left=v?"18px":"3px"; knob.style.background=v?"#000":"#777"; };
  return wrap;
}

function DD(items,selected,onChange){
  const wrap=mk("div",{position:"relative",width:"100%"});
  const btn=mk("div",{display:"flex",alignItems:"center",justifyContent:"space-between",gap:"6px",padding:"6px 9px",background:C.bg2,border:"1px solid "+C.border,borderRadius:"7px",cursor:"pointer",fontSize:"11px",color:C.text,whiteSpace:"nowrap",overflow:"hidden"});
  const lbl=tx(mk("span",{overflow:"hidden",textOverflow:"ellipsis"}),selected||"none");
  const car=tx(mk("span",{color:C.muted,fontSize:"9px"}),"▾"); btn.append(lbl,car);
  const panel=mk("div",{position:"absolute",top:"calc(100% + 3px)",left:"0",right:"0",maxHeight:"260px",overflowY:"auto",background:C.bg1,border:"1px solid "+C.border,borderRadius:"7px",zIndex:"1000",display:"none",boxShadow:"0 8px 24px rgba(0,0,0,.6)"});
  let cur=selected, list=items.slice();
  const render=()=>{ panel.innerHTML=""; list.forEach(it=>{ const row=tx(mk("div",{padding:"6px 9px",fontSize:"11px",cursor:"pointer",color:it===cur?LIME:C.text,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}),it);
    row.onmouseenter=()=>row.style.background=C.bg3; row.onmouseleave=()=>row.style.background="";
    row.onclick=()=>{ cur=it; lbl.textContent=it; panel.style.display="none"; onChange(it); }; panel.appendChild(row); }); };
  const close=()=>panel.style.display="none";
  btn.onclick=(e)=>{ e.stopPropagation(); const open=panel.style.display==="none"; render(); panel.style.display=open?"block":"none"; };
  document.addEventListener("click",(e)=>{ if(!wrap.contains(e.target))close(); });
  wrap.append(btn,panel);
  wrap.set=(v)=>{ cur=v; lbl.textContent=v; };
  wrap.updateItems=(arr)=>{ list=arr.slice(); };
  return wrap;
}

function Pill(txt,active,onClick){
  const b=tx(mk("button",{padding:"7px 16px",borderRadius:"8px",border:"1px solid "+(active?LIME:C.border),background:active?"rgba(240,255,65,.12)":C.bg2,color:active?LIME:C.muted,fontSize:"11px",fontWeight:"700",letterSpacing:".05em",cursor:"pointer",textTransform:"uppercase"}),txt);
  b.onclick=onClick;
  b._set=(a)=>{ b.style.border="1px solid "+(a?LIME:C.border); b.style.background=a?"rgba(240,255,65,.12)":C.bg2; b.style.color=a?LIME:C.muted; };
  return b;
}

function _pf(v){ return parseFloat(String(v).replace(",",".")); }
function NI(val,min,max,step,onChange,width="64px"){
  const inp=mk("input",{width,textAlign:"center",background:C.bg2,border:"1px solid "+C.border,borderRadius:"6px",color:LIME,fontSize:"11px",fontWeight:"700",padding:"5px 0",outline:"none"},{type:"number",value:String(val)});
  if(step!=null)inp.step=String(step); if(min!=null)inp.min=String(min); if(max!=null)inp.max=String(max);
  const commit=()=>{ let v=_pf(inp.value); if(isNaN(v))v=min!=null?min:0; if(min!=null)v=Math.max(min,v); if(max!=null)v=Math.min(max,v); inp.value=String(v); onChange(v); };
  inp.addEventListener("change",commit);
  inp.addEventListener("wheel",e=>e.stopPropagation(),{passive:true});
  const w={_inp:inp,set:(v)=>{inp.value=String(v);}};
  return w;
}

function Slider(val,min,max,step,onInput){
  const inp=mk("input",{width:"100%",accentColor:LIME,cursor:"pointer"},{type:"range",min:String(min),max:String(max),step:String(step),value:String(val)});
  inp.addEventListener("input",()=>onInput(_pf(inp.value)));
  inp.addEventListener("wheel",e=>e.stopPropagation(),{passive:true});
  const w={_inp:inp,set:(v)=>{inp.value=String(v);}};
  return w;
}

function sectionTitle(t){
  return tx(mk("div",{fontSize:"10px",fontWeight:"800",letterSpacing:".12em",textTransform:"uppercase",color:LIME,margin:"0 0 8px",borderBottom:"1px solid "+C.border,paddingBottom:"6px"}),t);
}

// ── file upload slots ─────────────────────────────────────────────────────────
// Generic uploader: posts to /upload/image (overwrite=true => raw bytes, no image
// validation), works for images, audio and video alike. Returns "subfolder/name".
async function uploadFile(file){
  const fd=new FormData(); fd.append("image",file,file.name); fd.append("overwrite","true");
  const r=await api.fetchApi("/upload/image",{method:"POST",body:fd});
  const d=await r.json();
  return d.subfolder?`${d.subfolder}/${d.name}`:d.name;
}

// Large image slot (first/last frame). onName(name|null).
function ImgSlot(hintTxt,onName){
  const wrap=mk("div",{position:"relative",width:"100%",minHeight:"110px",border:"1px dashed "+C.border,borderRadius:"9px",background:C.bg2,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",overflow:"hidden"});
  const hint=tx(mk("div",{fontSize:"10px",color:C.muted,textAlign:"center",padding:"14px"}),hintTxt);
  const img=mk("img",{maxWidth:"100%",maxHeight:"200px",display:"none",objectFit:"contain"});
  const clr=tx(mk("div",{position:"absolute",top:"4px",right:"6px",fontSize:"14px",color:"#ff6b6b",cursor:"pointer",display:"none",background:"rgba(0,0,0,.5)",borderRadius:"4px",padding:"0 5px",lineHeight:"18px"}),"×");
  const fileInput=mk("input",{display:"none"},{type:"file",accept:"image/*"});
  wrap.append(hint,img,clr,fileInput);
  let storedName=null;
  const upload=async(file)=>{
    try{ storedName=await uploadFile(file); img.src=URL.createObjectURL(file); img.style.display="block"; hint.style.display="none"; clr.style.display="block"; onName(storedName); }
    catch(e){ console.warn("[MMH3] upload:",e); }
  };
  wrap.onclick=(e)=>{ if(e.target===clr)return; fileInput.click(); };
  clr.onclick=(e)=>{ e.stopPropagation(); wrap.clear(); };
  fileInput.onchange=()=>{ if(fileInput.files[0])upload(fileInput.files[0]); };
  wrap.addEventListener("dragover",e=>{e.preventDefault();wrap.style.borderColor=LIME;});
  wrap.addEventListener("dragleave",()=>wrap.style.borderColor=C.border);
  wrap.addEventListener("drop",e=>{ e.preventDefault(); wrap.style.borderColor=C.border; const f=e.dataTransfer.files[0]; if(f)upload(f); });
  wrap.hasFile=()=>!!storedName;
  wrap.getName=()=>storedName;
  wrap.setName=(n)=>{ storedName=n||null; if(n){ img.style.display="none"; hint.textContent=n.split("/").pop(); hint.style.display="block"; clr.style.display="block"; } };
  wrap.clear=()=>{ storedName=null; img.style.display="none"; hint.textContent=hintTxt; hint.style.display="block"; clr.style.display="none"; onName(null); };
  return wrap;
}

// Compact square image slot (reference grid). tagLabel like "P1".
function RefImgSlot(tagLabel,onName){
  const wrap=mk("div",{position:"relative",width:"100%",aspectRatio:"1/1",border:"1px dashed "+C.border,borderRadius:"8px",background:C.bg2,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",overflow:"hidden"});
  const plus=tx(mk("div",{fontSize:"20px",color:C.muted}),"+");
  const img=mk("img",{width:"100%",height:"100%",display:"none",objectFit:"cover"});
  const tag=tx(mk("div",{position:"absolute",bottom:"2px",left:"3px",fontSize:"9px",fontWeight:"800",color:"#000",background:LIME,borderRadius:"3px",padding:"0 4px"}),tagLabel);
  const clr=tx(mk("div",{position:"absolute",top:"2px",right:"3px",fontSize:"12px",color:"#fff",cursor:"pointer",display:"none",background:"rgba(0,0,0,.55)",borderRadius:"3px",padding:"0 4px",lineHeight:"16px"}),"×");
  const fileInput=mk("input",{display:"none"},{type:"file",accept:"image/*"});
  wrap.append(plus,img,tag,clr,fileInput);
  let storedName=null;
  const upload=async(file)=>{
    try{ storedName=await uploadFile(file); img.src=URL.createObjectURL(file); img.style.display="block"; plus.style.display="none"; clr.style.display="block"; onName(storedName); }
    catch(e){ console.warn("[MMH3] ref upload:",e); }
  };
  wrap.onclick=(e)=>{ if(e.target===clr)return; fileInput.click(); };
  clr.onclick=(e)=>{ e.stopPropagation(); wrap.clear(); };
  fileInput.onchange=()=>{ if(fileInput.files[0])upload(fileInput.files[0]); };
  wrap.addEventListener("dragover",e=>{e.preventDefault();wrap.style.borderColor=LIME;});
  wrap.addEventListener("dragleave",()=>wrap.style.borderColor=C.border);
  wrap.addEventListener("drop",e=>{ e.preventDefault(); wrap.style.borderColor=C.border; const f=e.dataTransfer.files[0]; if(f)upload(f); });
  wrap.hasFile=()=>!!storedName;
  wrap.getName=()=>storedName;
  wrap.setTag=(t)=>{ tag.textContent=t; };
  wrap.setName=(n)=>{ storedName=n||null; if(n){ plus.style.display="none"; img.style.display="none"; clr.style.display="block"; } };
  wrap.clear=()=>{ storedName=null; img.style.display="none"; img.src=""; plus.style.display="block"; clr.style.display="none"; onName(null); };
  return wrap;
}

// Thin file-name slot for audio / video refs.
function FileRow(hintTxt,accept,onName){
  const wrap=mk("div",{position:"relative",display:"flex",alignItems:"center",gap:"6px",padding:"7px 9px",border:"1px dashed "+C.border,borderRadius:"7px",background:C.bg2,cursor:"pointer",fontSize:"10px",color:C.muted,minHeight:"20px"});
  const label=tx(mk("span",{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",flex:"1"}),hintTxt);
  const clr=tx(mk("span",{color:"#ff6b6b",cursor:"pointer",display:"none",fontSize:"13px"}),"×");
  const fileInput=mk("input",{display:"none"},{type:"file",accept});
  wrap.append(label,clr,fileInput);
  let storedName=null;
  const upload=async(file)=>{
    try{ storedName=await uploadFile(file); label.textContent=file.name; label.style.color=C.text; clr.style.display="inline"; onName(storedName); }
    catch(e){ console.warn("[MMH3] file upload:",e); }
  };
  wrap.onclick=(e)=>{ if(e.target===clr)return; fileInput.click(); };
  clr.onclick=(e)=>{ e.stopPropagation(); wrap.clear(); };
  fileInput.onchange=()=>{ if(fileInput.files[0])upload(fileInput.files[0]); };
  wrap.addEventListener("dragover",e=>{e.preventDefault();wrap.style.borderColor=LIME;});
  wrap.addEventListener("dragleave",()=>wrap.style.borderColor=C.border);
  wrap.addEventListener("drop",e=>{ e.preventDefault(); wrap.style.borderColor=C.border; const f=e.dataTransfer.files[0]; if(f)upload(f); });
  wrap.hasFile=()=>!!storedName;
  wrap.getName=()=>storedName;
  wrap.setName=(n)=>{ storedName=n||null; if(n){ label.textContent=n.split("/").pop(); label.style.color=C.text; clr.style.display="inline"; } };
  wrap.clear=()=>{ storedName=null; label.textContent=hintTxt; label.style.color=C.muted; clr.style.display="none"; onName(null); };
  return wrap;
}

// ── state ─────────────────────────────────────────────────────────────────────
function loadState(){ try{ return JSON.parse(localStorage.getItem(LS_KEY)||"{}"); }catch(e){ return {}; } }
function saveState(s){ try{ localStorage.setItem(LS_KEY,JSON.stringify(s)); }catch(e){} }

// ── active refs for API events ────────────────────────────────────────────────
let _activeSetProgress=()=>{};
let _activeShowVideo=()=>{};
let _activeShowError=()=>{};
let _activeReset=()=>{};
let _activeRefreshGallery=()=>{};
let _activePromptId=null;
// true only between submitting our /prompt and its completion — so the shared
// "queue idle" signals only reset THIS node's button when it was actually running.
let _activeRunning=false;

// treat this prompt as done: re-enable the button, stop the timer, refresh the gallery.
function _finishActive(){ if(!_activeRunning) return; _activeRunning=false; _activeReset(); _activeRefreshGallery(); }

api.addEventListener("progress",(evt)=>{
  const d=evt.detail||{}; if(d.value!=null&&d.max){ _activeSetProgress(d.value/d.max, d.value, d.max); }
});
api.addEventListener("executed",(evt)=>{
  const d=evt.detail||{};
  // ignore other graphs' outputs once we know our own prompt id
  if(_activePromptId && d.prompt_id && d.prompt_id!==_activePromptId) return;
  const out=d.output||{};
  const pick=out.images||out.video||out.videos||out.gifs||out.animated||null;
  let item=null;
  if(Array.isArray(pick)&&pick.length) item=pick[0];
  else if(pick&&pick.filename) item=pick;
  if(item&&item.filename){
    _activeShowVideo(item);   // shows in the preview + drops it into the gallery
    _finishActive();          // SaveVideo is the terminal node → we're done, re-enable now
  }
});
api.addEventListener("execution_success",()=>{ _finishActive(); });
api.addEventListener("execution_interrupted",()=>{ _finishActive(); });
api.addEventListener("execution_error",(evt)=>{
  const d=evt.detail||{};
  if(_activePromptId && d.prompt_id && d.prompt_id!==_activePromptId) return;
  _activeShowError(fmtErr(d.exception_message||d.exception_type||d)); _activeRunning=false; _activeReset();
});

// ──────────────────────────────────────────────────────────────────────────────
app.registerExtension({
  name:"MiniMaxH3OneNode.v1",
  async beforeRegisterNodeDef(nodeType,nodeData){
    if(nodeData.name!=="MiniMaxH3OneNode") return;

    nodeType.prototype.onNodeCreated=function(){
      this.color=C.bg0; this.bgcolor=C.bg0; this.resizable=true;  // user-resizable
      this.outputs=[]; if(this.widgets)this.widgets=[];
      if(!window.__mmh3_nodes) window.__mmh3_nodes={};
      const cached=window.__mmh3_nodes[this.id];
      if(cached){
        const _w=this.addDOMWidget("mmh3_ui","div",cached.root,{getValue(){return null;},setValue(){},serialize:false});
        // computeSize must be set ON the widget (options.computeSize is ignored by this
        // ComfyUI frontend). It returns the PERSISTED target size (floored at the min) so
        // the node holds its size; onResize updates that target when the user drags.
        _w.computeSize=function(){ const t=(cached.S&&cached.S.nodeSize)||[NODE_W,NODE_H]; return [Math.max(MIN_W,t[0]),Math.max(MIN_H-TITLE_H,t[1]-TITLE_H)]; };
        this.setSize((cached.S&&cached.S.nodeSize)?cached.S.nodeSize.slice():[NODE_W,NODE_H]);
        _bindActive(cached);
        return;
      }
      this._buildUI();
    };
    // clamp to the usable floor and remember the size the user drags to
    nodeType.prototype.onResize=function(size){
      const s=size||this.size;
      if(s[0]<MIN_W)s[0]=MIN_W;
      if(s[1]<MIN_H)s[1]=MIN_H;
      // Only persist genuine user drags. ComfyUI fires onResize during the initial add/
      // layout pass; the time-guard (>700ms after build) drops that noise so it can't
      // clobber the default target size stored in S.nodeSize.
      const c=window.__mmh3_nodes&&window.__mmh3_nodes[this.id];
      if(c&&c.S&&(Date.now()-(c._t0||0)>700)){ c.S.nodeSize=[s[0],s[1]]; if(c.fns&&c.fns.persist)c.fns.persist(); }
    };
    nodeType.prototype.getSlotMenuOptions=function(){ return []; };

    nodeType.prototype._buildUI=function(){
      const self=this;
      const saved=loadState();
      const S=self._mmh3_S||(self._mmh3_S={
        mode:        saved.mode||"t2v",          // "t2v" | "i2v" | "r2v"
        // models (auto-detected, overridable)
        unetFl:      saved.unetFl||"", unetRef:saved.unetRef||"",
        textEncoder: saved.textEncoder||"", videoVae:saved.videoVae||"", audioVae:saved.audioVae||"",
        // prompt
        prompt:      saved.prompt||"",
        // resolution / duration
        aspect:      saved.aspect||"16:9 (Widescreen)",
        megapixels:  saved.megapixels!==undefined?saved.megapixels:0.4,
        duration:    saved.duration!==undefined?saved.duration:5.0,
        // two-pass HD: T2V/I2V = draft(stage1Mp)→refine to megapixels (SPEED);
        // R2V = generate at megapixels (identity)→RTX-VSR upscale to stage2Mp→refine (QUALITY).
        twoPass:     saved.twoPass||false,
        stage1Mp:    saved.stage1Mp!==undefined?saved.stage1Mp:0.4,
        stage2Mp:    saved.stage2Mp!==undefined?saved.stage2Mp:1.2,
        stage2Steps: saved.stage2Steps!==undefined?saved.stage2Steps:4,
        stage2Denoise: saved.stage2Denoise!==undefined?saved.stage2Denoise:0.2,
        // sampling
        steps:       saved.steps||20,
        sampler:     saved.sampler||"res_multistep",
        scheduler:   saved.scheduler||"simple",
        seed:        saved.seed||0, randomizeSeed:saved.randomizeSeed!==undefined?saved.randomizeSeed:true,
        // advanced: sigma shift (model has good internal defaults 12 / 3)
        sigmaShiftOn:saved.sigmaShiftOn||false, shiftVideo:saved.shiftVideo!==undefined?saved.shiftVideo:12.0, shiftAudio:saved.shiftAudio!==undefined?saved.shiftAudio:3.0,
        // speed: sage attention (KJNodes, experimental) + Blackwell fast-fp8 load
        sageAttn:    saved.sageAttn||false, fastFp8:saved.fastFp8||false, solAttn: saved.solAttn||false,
        // cache accelerator (step reuse) — mutually exclusive: "off"|"teacache"|"spectrum"|"fbc"
        cacheEngine: saved.cacheEngine||"off",
        teaThresh:   saved.teaThresh!==undefined?saved.teaThresh:0.15,
        spectrumBlend: saved.spectrumBlend!==undefined?saved.spectrumBlend:0.5,
        fbcMode:     saved.fbcMode||"H3 Fast — 0.10 / max 2",
        // turbo 4-step LoRA (larryvrh) — ~5x faster; works on pruned bases
        turboOn:     saved.turboOn||false, turboSteps: saved.turboSteps||6, turboLora: saved.turboLora||"", turboStrength: saved.turboStrength!==undefined?saved.turboStrength:1.0, turboLowVram: saved.turboLowVram||false,
        styleOn: saved.styleOn||false, styleLora: saved.styleLora||"", styleStrength: saved.styleStrength!==undefined?saved.styleStrength:1.0, styleLowVram: saved.styleLowVram||false,
        lxTurbo: saved.lxTurbo||"off",   // distilled-turbo preset: "off" | "fl2v" | "r2v" (lightx2v LoRAs, locked recipe)
        // upscale tab
        upscaleEngine: (saved.upscaleEngine==="ltx"?"model":saved.upscaleEngine)||"model",   // "model" (ESRGAN) | "seedvr2" | "flashvsr"
        upscaleModel: saved.upscaleModel||"", upscaleScale: saved.upscaleScale||2,
        upscaleSource: saved.upscaleSource||null,   // {filename,subfolder,type}
        svrRes: saved.svrRes||1080, svrBlockSwap: (saved.svrBlockSwap===undefined||saved.svrBlockSwap===16)?0:saved.svrBlockSwap,
        svrDitModel: saved.svrDitModel||"seedvr2_ema_3b_fp8_e4m3fn.safetensors",
        svrCompile: saved.svrCompile||false, svrBatch: saved.svrBatch||5,
        // FlashVSR (fast diffusion upscaler)
        fvsrMode: saved.fvsrMode||"tiny", fvsrScale: saved.fvsrScale||2, fvsrVae: saved.fvsrVae||(saved.fvsrLightVae?"LightVAE_W2.1":"Wan2.1"),
        // RTX Video Super Resolution (NVIDIA hardware upscaler)
        rtxScale: saved.rtxScale||2, rtxQuality: saved.rtxQuality||"ULTRA",
        // node size (user-resizable)
        nodeSize:    saved.nodeSize||[NODE_W,NODE_H],
        // I2V frames
        firstFrame:  saved.firstFrame||null, lastFrame:saved.lastFrame||null, useLastFrame:saved.useLastFrame||false, reframe: saved.reframe||"match",
        // R2V references
        refImages:   saved.refImages||new Array(MAX_REF_IMAGES).fill(null),
        allow9:      saved.allow9||false,
        refVideos:   saved.refVideos||[{file:null,useAudio:true},{file:null,useAudio:true},{file:null,useAudio:true}],
        refAudios:   saved.refAudios||new Array(MAX_REF_AUDIOS).fill(null),
        refAudioTrim: saved.refAudioTrim||new Array(MAX_REF_AUDIOS).fill(null),  // parallel {start,end} per audio slot
        refImageSize:saved.refImageSize||"match",
        // low-VRAM: cap how many seconds of each reference VIDEO are decoded/encoded (heavy on 16 GB).
        // Toggle off (or raise) on 24 GB+ cards. Off still caps to output length (never decodes waste).
        refVidCap:   saved.refVidCap!==undefined?saved.refVidCap:true,
        refVidCapSec:saved.refVidCapSec!==undefined?saved.refVidCapSec:4,
        generating:false,
      });
      // migrate arrays to fixed length (in case an older state was shorter)
      while(S.refImages.length<MAX_REF_IMAGES)S.refImages.push(null);
      while(S.refAudios.length<MAX_REF_AUDIOS)S.refAudios.push(null);
      while(S.refVideos.length<MAX_REF_VIDEOS)S.refVideos.push({file:null,useAudio:true});
      // trim (start/end seconds): videos inline, audios in a parallel array — default 0/0 = full clip
      while(S.refAudioTrim.length<MAX_REF_AUDIOS)S.refAudioTrim.push(null);
      S.refAudioTrim=S.refAudioTrim.map(t=>t||{start:0,end:0});
      S.refVideos.forEach(v=>{ if(v.start===undefined)v.start=0; if(v.end===undefined)v.end=0; });

      const persist=()=>saveState({
        mode:S.mode,unetFl:S.unetFl,unetRef:S.unetRef,textEncoder:S.textEncoder,videoVae:S.videoVae,audioVae:S.audioVae,
        prompt:S.prompt,aspect:S.aspect,megapixels:S.megapixels,duration:S.duration,
        twoPass:S.twoPass,stage1Mp:S.stage1Mp,stage2Mp:S.stage2Mp,stage2Steps:S.stage2Steps,stage2Denoise:S.stage2Denoise,
        steps:S.steps,sampler:S.sampler,scheduler:S.scheduler,seed:S.seed,randomizeSeed:S.randomizeSeed,
        sigmaShiftOn:S.sigmaShiftOn,shiftVideo:S.shiftVideo,shiftAudio:S.shiftAudio,
        sageAttn:S.sageAttn,fastFp8:S.fastFp8,solAttn:S.solAttn,nodeSize:S.nodeSize,
        cacheEngine:S.cacheEngine,teaThresh:S.teaThresh,spectrumBlend:S.spectrumBlend,fbcMode:S.fbcMode,
        turboOn:S.turboOn,turboSteps:S.turboSteps,turboLora:S.turboLora,turboStrength:S.turboStrength,turboLowVram:S.turboLowVram,
        styleOn:S.styleOn,styleLora:S.styleLora,styleStrength:S.styleStrength,styleLowVram:S.styleLowVram,lxTurbo:S.lxTurbo,
        upscaleEngine:S.upscaleEngine,upscaleModel:S.upscaleModel,upscaleScale:S.upscaleScale,upscaleSource:S.upscaleSource,
        svrRes:S.svrRes,svrBlockSwap:S.svrBlockSwap,svrDitModel:S.svrDitModel,svrCompile:S.svrCompile,svrBatch:S.svrBatch,
        fvsrMode:S.fvsrMode,fvsrScale:S.fvsrScale,fvsrVae:S.fvsrVae,rtxScale:S.rtxScale,rtxQuality:S.rtxQuality,
        firstFrame:S.firstFrame,lastFrame:S.lastFrame,useLastFrame:S.useLastFrame,reframe:S.reframe,
        refImages:S.refImages,allow9:S.allow9,refVideos:S.refVideos,refAudios:S.refAudios,refAudioTrim:S.refAudioTrim,refImageSize:S.refImageSize,
        refVidCap:S.refVidCap,refVidCapSec:S.refVidCapSec,
      });

      let _sigmaShiftAvailable=true; // MiniMaxH3SigmaShift ships with the H3 nodes
      let _sageAvailable=false;      // MiniMaxH3MemoryEfficientSageAttentionPatch (KJNodes) — probed on init
      let _solAvailable=false;       // MiniMaxH3MemoryEfficientSolAttentionPatch (ComfyUI-sol-attn) — probed on init
      let _svrAvailable=false;       // SeedVR2VideoUpscaler — probed on init
      let _fvsrAvailable=false;      // FlashVSRNode (ComfyUI-FlashVSR_Stable) — probed on init
      let _rtxAvailable=false;       // RTXVideoSuperResolution (Comfy-Org Nvidia_RTX_Nodes) — probed on init
      let _turboNode=false;          // MiniMaxH3TurboSampler present — probed on init
      let _teaAvailable=false;       // MiniMaxH3TeaCache (Icyoung) — probed on init
      let _spectrumAvailable=false;  // SpectrumApplyMiniMaxH3 (xmarre) — probed on init
      let _fbcAvailable=false;       // ApplyMiniMaxH3FirstBlockCache (duckyshell) — probed on init
      let _ptConcatAvail=false;      // PT_H3ConcatAVLatent (ptmaster) — two-pass, probed on init
      let _t8DecodeAvail=false;      // MiniMaxH3AVDecodeT8 (T8mars) — two-pass, probed on init
      let _lxFl2vLora="";            // lightx2v FL2V Turbo v1.0 768p (4-step) — detected in the loras scan
      let _lxR2vLora="";             // lightx2v Ref2V Turbo v0.1 (4-step, keeps audio) — detected in the loras scan

      // ── style ─────────────────────────────────────────────────────────────
      if(!document.getElementById("mmh3-style")){
        const st=mk("style",{},{id:"mmh3-style"});
        st.textContent=`@keyframes mmh3-grad{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
        @keyframes mmh3-spin{to{transform:rotate(360deg)}}
        .mmh3-scroll::-webkit-scrollbar{width:8px;height:8px}.mmh3-scroll::-webkit-scrollbar-thumb{background:#333;border-radius:4px}`;
        document.head.appendChild(st);
      }

      const root=mk("div",{width:"100%",height:"100%",boxSizing:"border-box",background:C.bg0,color:C.text,position:"relative",
        borderRadius:"12px",overflow:"hidden",display:"flex",flexDirection:"column",
        fontFamily:"system-ui,-apple-system,Segoe UI,Roboto,sans-serif",border:"1px solid "+C.border});

      // ── header ────────────────────────────────────────────────────────────
      const header=mk("div",{display:"flex",alignItems:"center",gap:"10px",padding:"10px 14px",borderBottom:"1px solid "+C.border,background:C.bg1});
      const dot=mk("div",{width:"10px",height:"10px",borderRadius:"50%",background:LIME,boxShadow:"0 0 8px "+LIME});
      const title=tx(mk("div",{fontSize:"13px",fontWeight:"800",letterSpacing:".04em"}),"ONE NODE · MINIMAX H3");
      const subtitle=tx(mk("div",{fontSize:"10px",color:C.muted}),"video + native audio");
      const titleWrap=mk("div",{display:"flex",flexDirection:"column"}); titleWrap.append(title,subtitle);
      const verBadge=tx(mk("div",{fontSize:"9px",fontWeight:"800",color:"#000",background:LIME,borderRadius:"4px",padding:"1px 6px"}),VERSION);
      const pillT2V=Pill("T2V",false,()=>setMode("t2v"));
      const pillI2V=Pill("I2V",false,()=>setMode("i2v"));
      const pillR2V=Pill("R2V",false,()=>setMode("r2v"));
      const pillUp=Pill("UPSCALE",false,()=>setMode("upscale"));
      // ── node-level fullscreen (whole panel, like Krea2) ──
      const _fsExpandIco=`<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>`;
      const _fsCollapseIco=`<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M8 3v5H3M16 3v5h5M8 21v-5H3M16 21v-5h5"/></svg>`;
      const fsNodeBtn=mk("button",{background:"transparent",border:"1.5px solid "+C.border,borderRadius:"6px",padding:"3px 7px",cursor:"pointer",color:C.muted,display:"flex",alignItems:"center",flexShrink:"0",outline:"none",transition:"border-color .15s,color .15s"});
      fsNodeBtn.title="Fullscreen (F)"; fsNodeBtn.innerHTML=_fsExpandIco;
      fsNodeBtn.onmouseenter=()=>{fsNodeBtn.style.borderColor=LIME;fsNodeBtn.style.color=LIME;};
      fsNodeBtn.onmouseleave=()=>{fsNodeBtn.style.borderColor=C.border;fsNodeBtn.style.color=C.muted;};
      let _nodeFS=false,_fsNodeOverlay=null,_rootOrigParent=null,_rootOrigNext=null;
      const _enterNodeFS=()=>{
        if(_nodeFS) return;
        if(!_fsNodeOverlay){ _fsNodeOverlay=mk("div",{position:"fixed",inset:"0",zIndex:"99990",background:"rgba(6,6,8,.97)",display:"none",alignItems:"center",justifyContent:"center",boxSizing:"border-box",overflow:"hidden"}); document.body.appendChild(_fsNodeOverlay); }
        _rootOrigParent=root.parentNode; _rootOrigNext=root.nextSibling;
        const vw=window.innerWidth,vh=window.innerHeight, sc=Math.min(vw/NODE_W,vh/NODE_H)*0.97;
        root.style.width=NODE_W+"px"; root.style.height=NODE_H+"px"; root.style.borderRadius="0"; root.style.transformOrigin="top left"; root.style.transform="scale("+sc+")";
        const wrap=mk("div",{width:Math.round(NODE_W*sc)+"px",height:Math.round(NODE_H*sc)+"px",position:"relative",flexShrink:"0",overflow:"hidden"});
        wrap.appendChild(root); _fsNodeOverlay.appendChild(wrap); _fsNodeOverlay._wrap=wrap;
        _fsNodeOverlay.style.display="flex"; fsNodeBtn.innerHTML=_fsCollapseIco; _nodeFS=true;
      };
      const _exitNodeFS=()=>{
        if(!_nodeFS) return;
        if(_rootOrigParent){ if(_rootOrigNext)_rootOrigParent.insertBefore(root,_rootOrigNext); else _rootOrigParent.appendChild(root); }
        root.style.width="100%"; root.style.height="100%"; root.style.borderRadius="12px"; root.style.transform=""; root.style.transformOrigin="";
        if(_fsNodeOverlay&&_fsNodeOverlay._wrap){_fsNodeOverlay._wrap.remove();_fsNodeOverlay._wrap=null;}
        if(_fsNodeOverlay)_fsNodeOverlay.style.display="none"; fsNodeBtn.innerHTML=_fsExpandIco; _nodeFS=false;
      };
      const _toggleNodeFS=()=>{ _nodeFS?_exitNodeFS():_enterNodeFS(); };
      fsNodeBtn.onclick=_toggleNodeFS;
      const pillRow=mk("div",{display:"flex",gap:"6px",marginLeft:"auto",alignItems:"center"}); pillRow.append(pillT2V,pillI2V,pillR2V,pillUp,fsNodeBtn);
      header.append(dot,titleWrap,verBadge,pillRow);

      // ── body: two columns ─────────────────────────────────────────────────
      const body=mk("div",{flex:"1",display:"flex",minHeight:"0"});
      const left=mk("div",{width:"440px",flex:"0 0 440px",borderRight:"1px solid "+C.border,overflowY:"auto",padding:"12px"},{className:"mmh3-scroll"});
      const right=mk("div",{flex:"1",display:"flex",flexDirection:"column",padding:"12px",minWidth:"0"});
      body.append(left,right);

      // ===== LEFT: PROMPT =====
      const promptHdr=mk("div",{display:"flex",alignItems:"center",justifyContent:"space-between",margin:"0 0 8px"});
      promptHdr.append(sectionTitle("Prompt"));
      const tmplDD=mk("div",{width:"150px"}); const tmplSel=DD(["Load example…"],"Load example…",v=>applyTemplate(v)); tmplDD.appendChild(tmplSel);
      promptHdr.appendChild(tmplDD); promptHdr.lastChild.style.marginBottom="0";
      left.appendChild(promptHdr);

      const modeHint=tx(mk("div",{fontSize:"9.5px",color:C.muted,margin:"0 0 6px",lineHeight:"1.45"}),"");
      left.appendChild(modeHint);

      const posTA=mk("textarea",{width:"100%",minHeight:"96px",resize:"vertical",background:C.bg2,border:"1px solid "+C.border,borderRadius:"8px",color:C.text,fontSize:"12px",padding:"8px",outline:"none",boxSizing:"border-box",fontFamily:"inherit"},{placeholder:"Describe the shots, camera moves, AND the audio (dialogue, SFX, music) in one block. H3 renders sound jointly with the picture.",value:S.prompt});
      posTA.addEventListener("input",()=>{S.prompt=posTA.value;persist();});
      posTA.addEventListener("wheel",e=>e.stopPropagation(),{passive:true});
      left.appendChild(posTA);

      // R2V tag helper (insert <Picture N> / <Video N> / <Audio N> at cursor)
      const tagRow=mk("div",{display:"none",flexWrap:"wrap",gap:"4px",marginTop:"6px"});
      const insertTag=(t)=>{ const el=posTA; const s=el.selectionStart??el.value.length; const e=el.selectionEnd??el.value.length;
        el.value=el.value.slice(0,s)+t+el.value.slice(e); S.prompt=el.value; persist(); el.focus(); const p=s+t.length; el.selectionStart=el.selectionEnd=p; };
      const tagChip=(t)=>{ const b=tx(mk("button",{padding:"3px 7px",borderRadius:"5px",border:"1px solid "+C.border,background:C.bg2,color:LIME,fontSize:"9px",fontWeight:"700",cursor:"pointer"}),t); b.onclick=()=>insertTag(t+" "); return b; };
      const rebuildTagRow=()=>{
        tagRow.innerHTML="";
        const lim=S.allow9?MAX_REF_IMAGES:REF_IMAGES_SAFE;
        for(let i=0;i<lim;i++) if(S.refImages[i]) tagRow.appendChild(tagChip(`<Picture ${i+1}>`));
        S.refVideos.forEach((v,i)=>{ if(v.file) tagRow.appendChild(tagChip(`<Video ${i+1}>`)); });
        // audio ordinals count video soundtracks (that are enabled) then standalone audios
        let a=1;
        S.refVideos.forEach((v)=>{ if(v.file&&v.useAudio){ tagRow.appendChild(tagChip(`<Audio ${a}>`)); a++; } });
        S.refAudios.forEach((f)=>{ if(f){ tagRow.appendChild(tagChip(`<Audio ${a}>`)); a++; } });
        if(!tagRow.children.length) tagRow.appendChild(tx(mk("span",{fontSize:"9px",color:C.muted}),"Add references below to get insertable tags."));
      };
      left.appendChild(tagRow);

      // ===== LEFT: mode inputs (I2V frames / R2V references) =====
      const inputsWrap=mk("div",{marginTop:"16px"});
      left.appendChild(inputsWrap);

      // Reframe control (shared across panels): center-crop (match) / stretch / off — applied to
      // the first, last, and all reference images so they match the first frame's aspect (output canvas).
      let reframeDDiv=null, reframeDDr2v=null;
      const _setReframe=v=>{ S.reframe=v; try{reframeDDiv&&reframeDDiv.set(v);}catch(_e){} try{reframeDDr2v&&reframeDDr2v.set(v);}catch(_e){} persist(); };

      // -- I2V frame panel --
      const ivPanel=mk("div",{display:"none"});
      ivPanel.appendChild(sectionTitle("Frames"));
      ivPanel.appendChild(cap("First frame — the animation starts here"));
      const firstSlot=ImgSlot("Click or drop the FIRST frame",n=>{S.firstFrame=n;persist();});
      ivPanel.appendChild(firstSlot);
      const flfTgl=Toggle("Add an end frame (first→last bridge)",S.useLastFrame,v=>{S.useLastFrame=v;lastWrap.style.display=v?"block":"none";persist();},LIME);
      const flfRow=mk("div",{margin:"9px 0 0"}); flfRow.appendChild(flfTgl); ivPanel.appendChild(flfRow);
      const lastWrap=mk("div",{display:S.useLastFrame?"block":"none",marginTop:"8px"});
      lastWrap.appendChild(cap("Last frame — the model animates toward this"));
      const lastSlot=ImgSlot("Click or drop the LAST frame",n=>{S.lastFrame=n;persist();});
      lastWrap.appendChild(lastSlot);
      ivPanel.appendChild(lastWrap);
      const ivNote=tx(mk("div",{fontSize:"9px",color:C.muted,marginTop:"8px",lineHeight:"1.45"}),"With Reframe = match (default) every input is center-cropped to your output size, so the last frame perfectly matches the first — set your size to the first frame's aspect (9:16 or 16:9). Leave frames empty on T2V.");
      ivPanel.appendChild(ivNote);
      const rfRowIv=mk("div",{margin:"9px 0 0"});
      rfRowIv.appendChild(cap("Reframe last frame → match first (center-crop)"));
      reframeDDiv=DD(["match","stretch","off"],S.reframe,_setReframe);
      rfRowIv.appendChild(reframeDDiv); ivPanel.appendChild(rfRowIv);
      inputsWrap.appendChild(ivPanel);

      // -- R2V reference editor --
      const r2vPanel=mk("div",{display:"none"});
      r2vPanel.appendChild(sectionTitle("Reference editor"));
      const refIntro=mk("div",{fontSize:"9.5px",color:C.muted,lineHeight:"1.45",marginBottom:"8px"});
      refIntro.innerHTML="Lock a <b>character</b>, <b>style</b>, <b>motion/camera</b>, or <b>voice</b> from references, then describe the target scene. Tag each reference in the prompt in the order shown (<code>&lt;Picture 1&gt;</code>, <code>&lt;Video 1&gt;</code>, <code>&lt;Audio 1&gt;</code>).";
      r2vPanel.appendChild(refIntro);

      // images
      const imgHdr=mk("div",{display:"flex",alignItems:"center",justifyContent:"space-between",margin:"4px 0 6px"});
      imgHdr.append(cap("Reference images"));
      const allow9Tgl=Toggle("up to 9",S.allow9,v=>{S.allow9=v;renderRefImages();warnRefImages();rebuildTagRow();persist();},"#ff9f43");
      allow9Tgl.style.fontSize="9px"; imgHdr.appendChild(allow9Tgl);
      r2vPanel.appendChild(imgHdr);
      const imgGrid=mk("div",{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:"6px"});
      const _refImgSlots=[];
      r2vPanel.appendChild(imgGrid);
      const refImgWarn=tx(mk("div",{fontSize:"9px",color:"#ff9f43",margin:"6px 0 0",lineHeight:"1.4",display:"none"}),"");
      r2vPanel.appendChild(refImgWarn);
      const rfRowR2v=mk("div",{margin:"9px 0 4px"});
      rfRowR2v.appendChild(cap("Reframe references → match first frame (center-crop)"));
      reframeDDr2v=DD(["match","stretch","off"],S.reframe,_setReframe);
      rfRowR2v.appendChild(reframeDDr2v); r2vPanel.appendChild(rfRowR2v);
      const renderRefImages=()=>{
        imgGrid.innerHTML=""; _refImgSlots.length=0;
        const lim=S.allow9?MAX_REF_IMAGES:REF_IMAGES_SAFE;
        for(let i=0;i<lim;i++){
          const slot=RefImgSlot("P"+(i+1),(n)=>{S.refImages[i]=n;warnRefImages();rebuildTagRow();persist();});
          if(S.refImages[i]) slot.setName(S.refImages[i]);
          imgGrid.appendChild(slot); _refImgSlots.push(slot);
        }
        // clear any hidden slots (6-9) when collapsing back to 5
        if(!S.allow9){ for(let i=REF_IMAGES_SAFE;i<MAX_REF_IMAGES;i++) S.refImages[i]=null; }
      };
      const warnRefImages=()=>{
        const n=S.refImages.filter((x,i)=>x&&(S.allow9||i<REF_IMAGES_SAFE)).length;
        if(n>REF_IMAGES_SAFE){ refImgWarn.style.display="block"; refImgWarn.textContent=`⚠ ${n} reference images — MiniMax recommends ≤${REF_IMAGES_SAFE}. More than ${REF_IMAGES_SAFE} tends to dilute identity/quality and slows generation (every ref rides through all sampling steps).`; }
        else refImgWarn.style.display="none";
      };

      // ref image size
      const risRow=mk("div",{display:"flex",alignItems:"center",gap:"8px",margin:"10px 0 4px"});
      risRow.append(cap("Reference detail")); risRow.lastChild.style.margin="0";
      const risDD=mk("div",{width:"150px"}); const risSel=DD(["match","max"],S.refImageSize,v=>{S.refImageSize=v;persist();risNote.textContent=risHint();});
      risDD.appendChild(risSel); risRow.appendChild(risDD);
      r2vPanel.appendChild(risRow);
      const risHint=()=>S.refImageSize==="match"?"match — scale refs down to the output resolution (faster).":"max — keep up to a 2048px short edge for stronger identity, several× slower.";
      const risNote=tx(mk("div",{fontSize:"9px",color:C.muted,margin:"0 0 6px",lineHeight:"1.4"}),risHint());
      r2vPanel.appendChild(risNote);

      // start/end trim sub-row (seconds) — shared by ref videos + audios
      const trimRow=(gs,ge,ss,se)=>{
        const r=mk("div",{display:"flex",alignItems:"center",gap:"5px",margin:"3px 0 0 4px"});
        r.append(tx(mk("span",{fontSize:"9px",color:C.muted}),"trim ⏱ start"));
        const s=NI(gs(),0,3600,0.5,ss,"46px"); r.appendChild(s._inp);
        r.append(tx(mk("span",{fontSize:"9px",color:C.muted}),"end"));
        const e=NI(ge(),0,3600,0.5,se,"46px"); r.appendChild(e._inp);
        r.append(tx(mk("span",{fontSize:"9px",color:C.muted}),"s · 0 end = to finish"));
        return r;
      };
      // videos
      r2vPanel.appendChild(cap("Reference videos (motion / camera · optional)"));
      // Low-VRAM cap: only the first N seconds of each reference video are decoded/encoded.
      // Reference videos are the heaviest input (every frame is VAE-encoded up front + rides
      // all sampling steps), so on 16 GB a full 10–15s ref can overflow to shared memory and
      // crawl. Default ON @ 4s (plenty for motion). Turn off / raise it on 24 GB+ cards.
      const refCapRow=mk("div",{display:"flex",alignItems:"center",gap:"8px",flexWrap:"wrap",margin:"2px 0 4px"});
      const refCapSecWrap=mk("div",{display:"flex",alignItems:"center",gap:"4px"});
      const refCapTgl=Toggle("Cap reference length (low VRAM)",S.refVidCap,(on)=>{S.refVidCap=on;refCapSecWrap.style.opacity=on?"1":".4";refCapNote.textContent=refCapHintTxt();persist();},"#ff9f43");
      refCapTgl.style.fontSize="9px";
      const refCapSec=NI(S.refVidCapSec,1,15,0.5,(val)=>{S.refVidCapSec=val;refCapNote.textContent=refCapHintTxt();persist();},"48px");
      refCapSecWrap.append(tx(mk("span",{fontSize:"9px",color:C.muted}),"max"),refCapSec._inp,tx(mk("span",{fontSize:"9px",color:C.muted}),"s / ref"));
      refCapSecWrap.style.opacity=S.refVidCap?"1":".4";
      refCapRow.append(refCapTgl,refCapSecWrap);
      r2vPanel.appendChild(refCapRow);
      const refCapHintTxt=()=>S.refVidCap
        ? `On — each reference video uses its first ~${(+S.refVidCapSec||4)}s (enough for motion; keeps 16 GB safe). Trims to fewer frames, never changes your output length.`
        : "Off — reference videos use up to the full output length (for 24 GB+ cards). Heaviest setting.";
      const refCapNote=tx(mk("div",{fontSize:"9px",color:C.muted,margin:"0 0 8px",lineHeight:"1.4"}),refCapHintTxt());
      r2vPanel.appendChild(refCapNote);
      const _refVidRows=[];
      const vidHost=mk("div"); r2vPanel.appendChild(vidHost);
      const renderRefVideos=()=>{
        vidHost.innerHTML=""; _refVidRows.length=0;
        S.refVideos.forEach((v,i)=>{
          const wrap=mk("div",{marginBottom:"7px"});
          const row=mk("div",{display:"flex",alignItems:"center",gap:"6px"});
          const fr=FileRow(`Video ${i+1} — click or drop (mp4/webm/mov, 2–15s)`,"video/*",(n)=>{S.refVideos[i].file=n;rebuildTagRow();persist();});
          if(v.file) fr.setName(v.file);
          const frBox=mk("div",{flex:"1"}); frBox.appendChild(fr);
          const aud=Toggle("+sound",v.useAudio,(on)=>{S.refVideos[i].useAudio=on;rebuildTagRow();persist();},LIME);
          aud.style.fontSize="9px";
          row.append(frBox,aud);
          wrap.appendChild(row);
          wrap.appendChild(trimRow(()=>v.start||0,()=>v.end||0,(val)=>{S.refVideos[i].start=val;persist();},(val)=>{S.refVideos[i].end=val;persist();}));
          vidHost.appendChild(wrap); _refVidRows.push(fr);
        });
      };
      const vidNote=mk("div",{fontSize:"9px",color:C.muted,margin:"2px 0 8px",lineHeight:"1.4"});
      vidNote.innerHTML="Read at 24 fps, ≥5 frames. Reference videos are the <b>heaviest</b> input — every frame is VAE-encoded up front and rides all sampling steps (the cap above keeps that in check on limited VRAM). Prefer <b>one</b> strong ref over several. “+sound” feeds its soundtrack as a paired &lt;Audio&gt; reference — turn off if you don't want it shaping the output audio (and note <b>Turbo can't use audio refs</b>).";
      r2vPanel.appendChild(vidNote);

      // audios
      r2vPanel.appendChild(cap("Reference audio (voice / music · optional)"));
      const _refAudRows=[];
      const audHost=mk("div"); r2vPanel.appendChild(audHost);
      const renderRefAudios=()=>{
        audHost.innerHTML=""; _refAudRows.length=0;
        for(let i=0;i<MAX_REF_AUDIOS;i++){
          const wrap=mk("div",{marginBottom:"7px"});
          const fr=FileRow(`Audio ${i+1} — click or drop (wav/mp3/m4a)`,"audio/*",(n)=>{S.refAudios[i]=n;rebuildTagRow();persist();});
          if(S.refAudios[i]) fr.setName(S.refAudios[i]);
          wrap.appendChild(fr);
          const t=S.refAudioTrim[i]||(S.refAudioTrim[i]={start:0,end:0});
          wrap.appendChild(trimRow(()=>t.start||0,()=>t.end||0,(val)=>{t.start=val;persist();},(val)=>{t.end=val;persist();}));
          audHost.appendChild(wrap); _refAudRows.push(fr);
        }
      };
      const audNote=tx(mk("div",{fontSize:"9px",color:C.muted,margin:"2px 0 2px",lineHeight:"1.4"}),"Standalone clips are resampled to 32 kHz. Clone a voice or set a musical style; reference the clip as <Audio N> in the prompt.");
      r2vPanel.appendChild(audNote);
      inputsWrap.appendChild(r2vPanel);

      // -- UPSCALE panel (render fast/low-res, then enlarge the finished video) --
      const upPanel=mk("div",{display:"none"});
      upPanel.appendChild(sectionTitle("Upscaler · Enhancer Pro"));
      const upIntro=mk("div",{fontSize:"9.5px",color:C.muted,lineHeight:"1.45",marginBottom:"10px"});
      upIntro.innerHTML="Render fast at a low resolution, then enlarge the finished clip here — the <b>original audio</b> is re-muxed back, no re-generation.";
      upPanel.appendChild(upIntro);
      // engine selector
      upPanel.appendChild(cap("Engine"));
      const upEngRow=mk("div",{display:"flex",gap:"6px",marginBottom:"4px",flexWrap:"wrap"});
      const upEngModel=Pill("Model (fast)",S.upscaleEngine==="model",()=>setUpEngine("model"));
      const upEngRTX=Pill("RTX VSR (hardware) ⚡",S.upscaleEngine==="rtxvsr",()=>setUpEngine("rtxvsr"));
      const upEngSVR=Pill("SeedVR2 (max quality)",S.upscaleEngine==="seedvr2",()=>setUpEngine("seedvr2"));
      const upEngFVSR=Pill("FlashVSR (fast AI)",S.upscaleEngine==="flashvsr",()=>setUpEngine("flashvsr"));
      upEngRow.append(upEngModel,upEngRTX,upEngSVR,upEngFVSR); upPanel.appendChild(upEngRow);
      const upEngHint=tx(mk("div",{fontSize:"9px",color:C.muted,margin:"0 0 10px",lineHeight:"1.4"}),"");
      upPanel.appendChild(upEngHint);
      // source picker
      upPanel.appendChild(cap("Source video"));
      const upSrcBox=mk("div",{display:"flex",gap:"8px",alignItems:"stretch",marginBottom:"4px"});
      const upSrcInfo=mk("div",{flex:"1",minHeight:"66px",border:"1px dashed "+C.border,borderRadius:"8px",background:C.bg2,display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",position:"relative"});
      const upSrcThumb=mk("video",{width:"100%",height:"66px",objectFit:"cover",display:"none"},{muted:true,preload:"metadata"});
      const upSrcHint=tx(mk("div",{fontSize:"10px",color:C.muted,textAlign:"center",padding:"8px"}),"No video chosen");
      upSrcInfo.append(upSrcThumb,upSrcHint);
      const upPickBtn=tx(mk("button",{width:"120px",padding:"8px",borderRadius:"8px",border:"1px solid "+C.border,background:C.bg2,color:LIME,fontSize:"10px",fontWeight:"700",cursor:"pointer"}),"⤢ From gallery");
      upSrcBox.append(upSrcInfo,upPickBtn);
      upPanel.appendChild(upSrcBox);
      const upUpload=FileRow("…or click / drop a video file to upscale","video/*",(n)=>{ if(n){ S.upscaleSource={filename:n.split("/").pop(),subfolder:n.indexOf("/")>=0?n.slice(0,n.lastIndexOf("/")):"",type:"input",_input:true,_raw:n}; refreshUpSource(); persist(); } });
      upUpload.style.marginTop="6px"; upPanel.appendChild(upUpload);
      const refreshUpSource=()=>{
        const s=S.upscaleSource;
        if(s&&s.filename){ upSrcHint.style.display="none"; upSrcThumb.style.display="block";
          upSrcThumb.src=(s._input? `/view?filename=${encodeURIComponent(s._raw||s.filename)}&type=input` : _viewUrl(s))+"#t=0.12"; _thumbFrame(upSrcThumb);
          upSrcHint.textContent=s.filename; }
        else { upSrcThumb.style.display="none"; upSrcThumb.removeAttribute("src"); upSrcHint.style.display="block"; upSrcHint.textContent="No video chosen"; }
      };
      upPickBtn.onclick=()=>openGalleryModal((it)=>{ S.upscaleSource={filename:it.filename,subfolder:it.subfolder||"",type:it.type||"output"}; refreshUpSource(); persist(); });
      // ===== Model-engine controls (ESRGAN) =====
      const upModelBox=mk("div");
      const upModRow=mk("div",{marginTop:"12px"}); upModRow.appendChild(cap("Upscale model (models/upscale_models)"));
      const upModDD=DD(["none"],"none",v=>{S.upscaleModel=v==="none"?"":v;persist();}); upModRow.appendChild(upModDD);
      upModelBox.appendChild(upModRow);
      const upScaleRow=mk("div",{marginTop:"12px"}); upScaleRow.appendChild(cap("Target scale"));
      const upScaleBtns=mk("div",{display:"flex",gap:"6px"});
      const _upScalePills=[2,3,4].map(x=>{ const p=Pill(x+"×",S.upscaleScale===x,()=>{ S.upscaleScale=x; _upScalePills.forEach((pp,i)=>pp._set([2,3,4][i]===x)); persist(); }); return p; });
      upScaleBtns.append(..._upScalePills); upScaleRow.appendChild(upScaleBtns);
      upModelBox.appendChild(upScaleRow);
      upPanel.appendChild(upModelBox);

      // ===== SeedVR2 controls (diffusion AI upscaler) =====
      const upSvrBox=mk("div",{display:"none"});
      const svrBanner=mk("div",{display:"none",margin:"6px 0 0",padding:"7px",borderRadius:"6px",border:"1px solid #cc7a00",background:"rgba(255,150,0,.08)",fontSize:"9px",color:"#ffb84d",lineHeight:"1.4"});
      svrBanner.innerHTML="<b>SeedVR2</b> is installed but not detected yet — <b>restart ComfyUI</b> so its nodes register. First run auto-downloads the chosen model to <code>models/SEEDVR2/</code>.";
      upSvrBox.appendChild(svrBanner);
      // model quality (lower = less VRAM → the OOM escape hatch on 16 GB)
      const SVR_DITS=[
        {label:"3B · GGUF Q4 — fastest / lowest VRAM", file:"seedvr2_ema_3b-Q4_K_M.gguf"},
        {label:"3B · GGUF Q8 — low VRAM", file:"seedvr2_ema_3b-Q8_0.gguf"},
        {label:"3B · FP8 — default (fast)", file:"seedvr2_ema_3b_fp8_e4m3fn.safetensors"},
        {label:"3B · FP16 — best 3B (heavy)", file:"seedvr2_ema_3b_fp16.safetensors"},
        {label:"7B Sharp · GGUF Q4 — ★ MAX detail, fits 16 GB", file:"seedvr2_ema_7b_sharp-Q4_K_M.gguf"},
        {label:"7B · GGUF Q4 — 7B quality, fits 16 GB", file:"seedvr2_ema_7b-Q4_K_M.gguf"},
        {label:"7B Sharp · FP8 — max detail (heavier)", file:"seedvr2_ema_7b_sharp_fp8_e4m3fn_mixed_block35_fp16.safetensors"},
        {label:"7B · FP16 — absolute best (heavy offload)", file:"seedvr2_ema_7b_fp16.safetensors"},
      ];
      const _svrLabel=(f)=>(SVR_DITS.find(m=>m.file===f)||SVR_DITS[2]).label;
      const svrModRow=mk("div",{marginTop:"12px"}); svrModRow.appendChild(cap("Model quality (3B = fast · 7B = max detail)"));
      // picking a 7B model auto-raises block-swap (7B won't fit 16 GB at swap 0) so it can't OOM out of the box.
      const svrModDD=DD(SVR_DITS.map(m=>m.label),_svrLabel(S.svrDitModel),(lbl)=>{ const m=SVR_DITS.find(x=>x.label===lbl); if(m){ S.svrDitModel=m.file; if(/7b/i.test(m.file)&&(+S.svrBlockSwap||0)<8){ S.svrBlockSwap=20; try{svrSwapIn.set(20);}catch(_e){} } persist(); } });
      svrModRow.appendChild(svrModDD); upSvrBox.appendChild(svrModRow);
      const svrResRow=mk("div",{marginTop:"12px"}); svrResRow.appendChild(cap("Target resolution (short edge)"));
      const svrResBtns=mk("div",{display:"flex",gap:"6px"});
      const _svrResPills=[720,1080,1440,2160].map(x=>{ const p=Pill(x+"p",S.svrRes===x,()=>{ S.svrRes=x; _svrResPills.forEach((pp,i)=>pp._set([720,1080,1440,2160][i]===x)); persist(); }); return p; });
      svrResBtns.append(..._svrResPills); svrResRow.appendChild(svrResBtns);
      upSvrBox.appendChild(svrResRow);
      const svrSwapRow=mk("div",{display:"flex",alignItems:"center",gap:"8px",marginTop:"12px",flexWrap:"wrap"});
      svrSwapRow.append(cap("Block swap (0 = fastest)")); svrSwapRow.lastChild.style.margin="0";
      const svrSwapIn=NI(S.svrBlockSwap,0,36,1,v=>{S.svrBlockSwap=v;persist();},"52px"); svrSwapRow.appendChild(svrSwapIn._inp);
      svrSwapRow.append(cap("Batch (higher = faster)")); svrSwapRow.lastChild.style.margin="0 0 0 8px";
      const svrBatchIn=NI(S.svrBatch,5,25,1,v=>{S.svrBatch=v;persist();},"52px"); svrSwapRow.appendChild(svrBatchIn._inp);
      upSvrBox.appendChild(svrSwapRow);
      const svrCompileTgl=Toggle("torch.compile — faster runs (first run warms up ~1–3 min)",S.svrCompile,v=>{S.svrCompile=v;persist();},"#5fd0ff");
      svrCompileTgl.style.marginTop="10px"; upSvrBox.appendChild(svrCompileTgl);
      const svrNote=mk("div",{fontSize:"9px",color:C.muted,margin:"7px 0 0",lineHeight:"1.45"});
      svrNote.innerHTML="Diffusion upscaler (best quality, temporally stable), <b>SageAttention 2</b> on your 5070 Ti. <b>3B</b> = fast (keep <b>block swap 0</b>). <b>7B / 7B-Sharp</b> = the 'insane detail' tier — heavier, so block swap auto-raises to ~20 for 16 GB; models <b>auto-download</b> on first use (big; first run is slow). Push <b>Batch</b> to <b>9–13</b> (5/9/13 = 4n+1) if VRAM holds, and flip <b>torch.compile</b> on for +20–40% after a one-time warmup. VAE decode auto-tiled.";
      upSvrBox.appendChild(svrNote);
      upPanel.appendChild(upSvrBox);

      // ===== FlashVSR controls (fast diffusion upscaler) =====
      const upFvsrBox=mk("div",{display:"none"});
      const fvsrBanner=mk("div",{display:"none",margin:"6px 0 0",padding:"7px",borderRadius:"6px",border:"1px solid #cc7a00",background:"rgba(255,150,0,.08)",fontSize:"9px",color:"#ffb84d",lineHeight:"1.4"});
      fvsrBanner.innerHTML="<b>FlashVSR</b> is installed but not detected — <b>restart ComfyUI</b> so its nodes register. First run auto-downloads its models.";
      upFvsrBox.appendChild(fvsrBanner);
      const fvsrModeRow=mk("div",{marginTop:"12px"}); fvsrModeRow.appendChild(cap("Mode (VRAM ↔ quality)"));
      const fvsrModeBtns=mk("div",{display:"flex",gap:"6px",flexWrap:"wrap"});
      const _fvsrModes=[["tiny","Tiny (16 GB)"],["tiny-long","Tiny-long (long clips)"],["full","Full (max, heavy)"]];
      const _fvsrModePills=_fvsrModes.map(([v,lbl])=>{ const p=Pill(lbl,S.fvsrMode===v,()=>{ S.fvsrMode=v; _fvsrModePills.forEach((pp,i)=>pp._set(_fvsrModes[i][0]===v)); persist(); }); return p; });
      fvsrModeBtns.append(..._fvsrModePills); fvsrModeRow.appendChild(fvsrModeBtns); upFvsrBox.appendChild(fvsrModeRow);
      const fvsrScaleRow=mk("div",{marginTop:"12px"}); fvsrScaleRow.appendChild(cap("Scale"));
      const fvsrScaleBtns=mk("div",{display:"flex",gap:"6px"});
      const _fvsrScalePills=[2,4].map(x=>{ const p=Pill(x+"×",S.fvsrScale===x,()=>{ S.fvsrScale=x; _fvsrScalePills.forEach((pp,i)=>pp._set([2,4][i]===x)); persist(); }); return p; });
      fvsrScaleBtns.append(..._fvsrScalePills); fvsrScaleRow.appendChild(fvsrScaleBtns); upFvsrBox.appendChild(fvsrScaleRow);
      const fvsrVaeRow=mk("div",{marginTop:"12px"}); fvsrVaeRow.appendChild(cap("VAE (quality ↔ VRAM)"));
      const _fvsrVaes=[["Wan2.2","Wan2.2 — best quality"],["Wan2.1","Wan2.1 — balanced (default)"],["LightVAE_W2.1","LightVAE — ≈50% less VRAM"]];
      const _fvsrVaeLbl=(f)=>(_fvsrVaes.find(m=>m[0]===f)||_fvsrVaes[1])[1];
      const fvsrVaeDD=DD(_fvsrVaes.map(m=>m[1]),_fvsrVaeLbl(S.fvsrVae),(lbl)=>{ const m=_fvsrVaes.find(x=>x[1]===lbl); if(m){S.fvsrVae=m[0];persist();} });
      fvsrVaeRow.appendChild(fvsrVaeDD); upFvsrBox.appendChild(fvsrVaeRow);
      const fvsrNote=mk("div",{fontSize:"9px",color:C.muted,margin:"7px 0 0",lineHeight:"1.45"});
      fvsrNote.innerHTML="<b>FlashVSR</b> — fast diffusion upscaler, best on <b>real footage</b>. On stylized / AI-generated clips <b>SeedVR2 usually looks better</b> — use that for H3 output. <b>16 GB:</b> use <b>Tiny / Tiny-long</b> and <b>avoid Full</b> (it spills to shared memory and crawls). Models auto-download on first use; audio re-muxed automatically.";
      upFvsrBox.appendChild(fvsrNote);
      upPanel.appendChild(upFvsrBox);

      // ===== RTX Video Super Resolution (NVIDIA hardware upscaler) =====
      const upRtxBox=mk("div",{display:"none"});
      const rtxBanner=mk("div",{display:"none",margin:"6px 0 0",padding:"7px",borderRadius:"6px",border:"1px solid #cc7a00",background:"rgba(255,150,0,.08)",fontSize:"9px",color:"#ffb84d",lineHeight:"1.4"});
      rtxBanner.innerHTML="<b>RTX VSR</b> isn't detected — install <b>Comfy-Org/Nvidia_RTX_Nodes_ComfyUI</b> into custom_nodes and <b>restart ComfyUI</b>. NVIDIA RTX GPU only (your 5070 Ti qualifies).";
      upRtxBox.appendChild(rtxBanner);
      const rtxScaleRow=mk("div",{marginTop:"12px"}); rtxScaleRow.appendChild(cap("Scale"));
      const rtxScaleBtns=mk("div",{display:"flex",gap:"6px"});
      const _rtxScalePills=[2,3,4].map(x=>{ const p=Pill(x+"×",S.rtxScale===x,()=>{ S.rtxScale=x; _rtxScalePills.forEach((pp,i)=>pp._set([2,3,4][i]===x)); persist(); }); return p; });
      rtxScaleBtns.append(..._rtxScalePills); rtxScaleRow.appendChild(rtxScaleBtns); upRtxBox.appendChild(rtxScaleRow);
      const rtxQRow=mk("div",{marginTop:"12px"}); rtxQRow.appendChild(cap("Quality"));
      const rtxQBtns=mk("div",{display:"flex",gap:"6px",flexWrap:"wrap"});
      const _rtxQ=["LOW","MEDIUM","HIGH","ULTRA"];
      const _rtxQPills=_rtxQ.map(q=>{ const p=Pill(q==="MEDIUM"?"MED":q,S.rtxQuality===q,()=>{ S.rtxQuality=q; _rtxQPills.forEach((pp,i)=>pp._set(_rtxQ[i]===q)); persist(); }); return p; });
      rtxQBtns.append(..._rtxQPills); rtxQRow.appendChild(rtxQBtns); upRtxBox.appendChild(rtxQRow);
      const rtxNote=mk("div",{fontSize:"9px",color:C.muted,margin:"7px 0 0",lineHeight:"1.45"});
      rtxNote.innerHTML="<b>RTX Video Super Resolution</b> — NVIDIA <b>hardware</b> upscaler on your RTX card: <b>very fast (up to ~30×), low VRAM</b>, great for a quick 4K finish. It <b>cleans &amp; sharpens</b> (kills compression artifacts) but <b>doesn't invent new detail</b> — for stylized H3 output that's usually exactly right; use <b>SeedVR2</b> when you need hallucinated detail. Audio re-muxed automatically.";
      upRtxBox.appendChild(rtxNote);
      upPanel.appendChild(upRtxBox);

      const setUpEngine=(e)=>{
        S.upscaleEngine=e; upEngModel._set(e==="model"); upEngRTX._set(e==="rtxvsr"); upEngSVR._set(e==="seedvr2"); upEngFVSR._set(e==="flashvsr");
        upModelBox.style.display=e==="model"?"block":"none";
        upRtxBox.style.display=e==="rtxvsr"?"block":"none";
        upSvrBox.style.display=e==="seedvr2"?"block":"none";
        upFvsrBox.style.display=e==="flashvsr"?"block":"none";
        svrBanner.style.display=(e==="seedvr2"&&!_svrAvailable)?"block":"none";
        fvsrBanner.style.display=(e==="flashvsr"&&!_fvsrAvailable)?"block":"none";
        rtxBanner.style.display=(e==="rtxvsr"&&!_rtxAvailable)?"block":"none";
        upEngHint.innerHTML=e==="model"
          ? "ESRGAN — fast, per-frame. It holds every frame in RAM, so <b>4× on a 10s+ clip can run out of memory</b> — prefer <b>2×</b> for long clips."
          : e==="rtxvsr"
          ? "RTX VSR — NVIDIA <b>hardware</b> upscaler. The <b>fastest</b> path to 4K, low VRAM; cleans &amp; sharpens without inventing detail. Great for a quick finish on H3 clips."
          : e==="seedvr2"
          ? "SeedVR2 — AI diffusion, <b>max quality</b> &amp; temporal stability (try the 7B models). Batched; handles long clips but slower."
          : "FlashVSR — AI diffusion, <b>~2× faster</b> than SeedVR2 at near-equal quality. Best speed/quality balance for most clips.";
        genBtn.textContent=S.mode==="upscale"?"▶ Upscale video":genBtn.textContent;
        persist();
      };
      inputsWrap.appendChild(upPanel);

      // ===== LEFT: VIDEO (resolution + duration) =====
      const vidWrap=mk("div",{marginTop:"18px"});
      vidWrap.appendChild(sectionTitle("Video"));
      // aspect
      vidWrap.appendChild(cap("Aspect ratio"));
      const aspectSel=DD(ASPECT_KEYS,S.aspect,v=>{S.aspect=v;updateRes();persist();});
      vidWrap.appendChild(aspectSel);
      // megapixels
      const mpRow=mk("div",{display:"flex",alignItems:"center",gap:"8px",margin:"10px 0 0"});
      mpRow.append(cap("Resolution")); mpRow.lastChild.style.margin="0";
      const mpVal=NI(S.megapixels,0.1,2.0,0.05,v=>{S.megapixels=v;mpSlider.set(v);updateRes();persist();},"56px");
      mpRow.appendChild(tx(mk("span",{fontSize:"9px",color:C.muted}),"MP")); mpRow.appendChild(mpVal._inp);
      vidWrap.appendChild(mpRow);
      const mpSlider=Slider(S.megapixels,0.1,2.0,0.05,v=>{S.megapixels=v;mpVal.set(v);updateRes();persist();});
      vidWrap.appendChild(mpSlider._inp);
      const resReadout=tx(mk("div",{fontSize:"10px",fontWeight:"700",color:LIME,margin:"5px 0 0"}),"");
      vidWrap.appendChild(resReadout);
      const resWarn=tx(mk("div",{fontSize:"9px",color:"#ff9f43",margin:"3px 0 0",lineHeight:"1.4",display:"none"}),"");
      vidWrap.appendChild(resWarn);
      // live size-reference table (mirrors the official workflow note): megapixels →
      // exact output for the CHOSEN aspect ratio. Highlights the current pick; click to set.
      const resTblWrap=mk("div",{marginTop:"8px",border:"1px solid "+C.border,borderRadius:"7px",overflow:"hidden"});
      const resTblHdr=tx(mk("div",{fontSize:"9px",fontWeight:"700",letterSpacing:".06em",color:C.muted,cursor:"pointer",padding:"6px 8px",background:C.bg1}),"▸ Size table  (megapixels → output)");
      const resTbl=mk("div",{display:"none",maxHeight:"172px",overflowY:"auto"},{className:"mmh3-scroll"});
      let _resTblOpen=false;
      resTblHdr.onclick=()=>{ _resTblOpen=!_resTblOpen; resTbl.style.display=_resTblOpen?"block":"none"; resTblHdr.textContent=(_resTblOpen?"▾":"▸")+" Size table  (megapixels → output)"; if(_resTblOpen)renderResTbl(); };
      resTblWrap.append(resTblHdr,resTbl);
      vidWrap.appendChild(resTblWrap);
      const renderResTbl=()=>{
        if(!_resTblOpen)return;
        resTbl.innerHTML="";
        const cur=calcRes(S.aspect,S.megapixels,MULTIPLE);
        MP_STEPS.forEach(mp=>{
          const {w,h}=calcRes(S.aspect,mp,MULTIPLE);
          const isCur=(w===cur.w&&h===cur.h);
          const over=(w*h>MAX_PIXELS||Math.min(w,h)>BASE_SHORT_EDGE);
          const row=mk("div",{display:"flex",justifyContent:"space-between",padding:"4px 9px",fontSize:"9.5px",cursor:"pointer",
            background:isCur?"rgba(240,255,65,.14)":"transparent",color:isCur?LIME:(over?"#c9a06a":C.text),borderLeft:"2px solid "+(isCur?LIME:"transparent")});
          row.append(tx(mk("span"),mp.toFixed(2)+" MP"),tx(mk("span",{fontWeight:"700"}),`${w} × ${h}`+(over?"  ⚠":"")));
          row.onmouseenter=()=>{ if(!isCur)row.style.background=C.bg3; };
          row.onmouseleave=()=>{ if(!isCur)row.style.background="transparent"; };
          row.onclick=()=>{ S.megapixels=mp; mpVal.set(mp); mpSlider.set(mp); updateRes(); persist(); };
          resTbl.appendChild(row);
        });
      };
      const updateRes=()=>{
        const {w,h}=calcRes(S.aspect,S.megapixels,MULTIPLE);
        resReadout.textContent=`→ ${w} × ${h}  ·  ${(w*h/1048576).toFixed(2)} MP`;
        if(w*h>MAX_PIXELS||Math.min(w,h)>BASE_SHORT_EDGE){ resWarn.style.display="block"; resWarn.textContent="⚠ Above H3's trained 768-short-edge canvas (≤1344×768). Higher is possible but slower and less stable."; }
        else resWarn.style.display="none";
        renderResTbl();
        try{ tpUpdateNote(); }catch(_e){}   // keep the two-pass res note in sync (defined later)
      };
      // duration
      const durRow=mk("div",{display:"flex",alignItems:"center",gap:"8px",margin:"12px 0 0"});
      durRow.append(cap("Duration")); durRow.lastChild.style.margin="0";
      const durVal=NI(S.duration,1,20,0.5,v=>{S.duration=v;durSlider.set(v);updateDur();persist();},"56px");
      durRow.append(tx(mk("span",{fontSize:"9px",color:C.muted}),"sec"),durVal._inp);
      vidWrap.appendChild(durRow);
      const durSlider=Slider(S.duration,1,20,0.5,v=>{S.duration=v;durVal.set(v);updateDur();persist();});
      vidWrap.appendChild(durSlider._inp);
      const durReadout=tx(mk("div",{fontSize:"10px",fontWeight:"700",color:LIME,margin:"5px 0 0"}),"");
      vidWrap.appendChild(durReadout);
      const durWarn=tx(mk("div",{fontSize:"9px",color:"#ff9f43",margin:"3px 0 0",lineHeight:"1.4",display:"none"}),"");
      vidWrap.appendChild(durWarn);
      const updateDur=()=>{
        const len=durToLen(S.duration); const sec=(len/FPS);
        durReadout.textContent=`≈ ${sec.toFixed(1)}s  ·  ${len} frames @ ${FPS} fps  (snaps to a 17k+5 grid)`;
        if(len<LEN_MIN){ durWarn.style.display="block"; durWarn.textContent="⚠ Below H3's trained range (~5s min). Very short clips can be unstable."; }
        else if(len>LEN_MAX){ durWarn.style.display="block"; durWarn.textContent="⚠ Above H3's trained range (~15s max, 362 frames). Longer is untested."; }
        else durWarn.style.display="none";
      };
      // ── Two-pass HD (hires-fix): generate small → refine to the resolution above ──
      const tpWrap=mk("div",{marginTop:"12px",border:"1px solid "+C.border,borderRadius:"8px",padding:"9px 10px",background:C.bg1});
      const tpTgl=Toggle("⚡ Two-pass HD",S.twoPass,v=>{S.twoPass=v;tpBody.style.display=v?"block":"none";updateTwoPassUI();persist();},"#7fd0a0");
      tpWrap.appendChild(tpTgl);
      const tpBody=mk("div",{display:S.twoPass?"block":"none",marginTop:"8px"});
      const tpRow=mk("div",{display:"flex",alignItems:"center",gap:"8px",flexWrap:"wrap"});
      const tpMpLbl=cap("Draft"); tpMpLbl.style.margin="0"; tpRow.append(tpMpLbl);
      // draft-MP (i2v/t2v, ≤ target) vs refine-MP (r2v, ≥ target) — only the mode-relevant one shows
      const tpS1=NI(S.stage1Mp,0.1,1.0,0.05,v=>{S.stage1Mp=v;persist();tpUpdateNote();},"56px");
      const tpS2=NI(S.stage2Mp,0.6,2.0,0.05,v=>{S.stage2Mp=v;persist();tpUpdateNote();},"56px");
      tpRow.append(tpS1._inp,tpS2._inp,tx(mk("span",{fontSize:"9px",color:C.muted}),"MP · refine"));
      const tpSteps=NI(S.stage2Steps,1,12,1,v=>{S.stage2Steps=v;persist();},"46px");
      tpRow.append(tpSteps._inp,tx(mk("span",{fontSize:"9px",color:C.muted}),"steps · denoise"));
      const tpDen=NI(S.stage2Denoise,0.05,0.6,0.05,v=>{S.stage2Denoise=v;persist();},"52px");
      tpRow.append(tpDen._inp);
      tpBody.appendChild(tpRow);
      const tpBanner=mk("div",{display:"none",margin:"7px 0 0",padding:"7px",borderRadius:"6px",border:"1px solid #cc7a00",background:"rgba(255,150,0,.08)",fontSize:"9px",color:"#ffb84d",lineHeight:"1.4"});
      tpBody.appendChild(tpBanner);
      const tpNote=mk("div",{fontSize:"9px",color:C.muted,margin:"7px 0 0",lineHeight:"1.45"});
      tpBody.appendChild(tpNote);
      tpWrap.appendChild(tpBody);
      vidWrap.appendChild(tpWrap);
      const tpUpdateNote=()=>{
        const r2vm=(S.mode==="r2v");
        tpS1._inp.style.display=r2vm?"none":""; tpS2._inp.style.display=r2vm?"":"none";
        tpMpLbl.textContent=r2vm?"Refine →":"Draft";
        const tgt=calcRes(S.aspect,S.megapixels,MULTIPLE);
        if(r2vm){ const s2=calcRes(S.aspect,Math.max(+S.stage2Mp||1.2,S.megapixels),MULTIPLE);
          tpNote.innerHTML="Generates at <b>"+tgt.w+"×"+tgt.h+"</b> (references intact — identity untouched), then <b>RTX-VSR upscales</b> to <b>"+s2.w+"×"+s2.h+"</b> and does a light <b>"+(+S.stage2Steps||4)+"-step · "+(+S.stage2Denoise||0.2)+" denoise</b> refine. A <b>quality</b> pass, not a speed trick. Set the generate res with <b>Resolution</b> above.";
        } else { const s1=calcRes(S.aspect,Math.min(+S.stage1Mp||0.4,S.megapixels),MULTIPLE);
          tpNote.innerHTML="Renders at <b>"+s1.w+"×"+s1.h+"</b> (fast draft), then re-samples up to <b>"+tgt.w+"×"+tgt.h+"</b> at <b>"+(+S.stage2Steps||4)+" steps · denoise "+(+S.stage2Denoise||0.2)+"</b> — a latent hires-fix that adds real detail cheaper than full-res. Set your target with the <b>Resolution</b> slider above."; }
      };
      const updateTwoPassUI=()=>{ const ready=_ptConcatAvail&&_t8DecodeAvail; const skip=S.twoPass&&(S.mode==="upscale"); const rtxWant=S.twoPass&&S.mode==="r2v"&&!_rtxAvailable;
        tpBanner.style.display=(S.twoPass&&(!ready||skip||rtxWant))?"block":"none";
        tpBanner.innerHTML=skip?"Two-pass is skipped in <b>Upscale</b> mode (that tab already upscales)."
          :(!ready?"Two-pass needs <b>ComfyUI-PT_H3ConcatAVLatent</b> + <b>comfyui-minimax-h3-audio-T8</b> — install both + <b>restart ComfyUI</b>."
          :(rtxWant?"R2V two-pass upscales with <b>RTX VSR</b> — install it for the cleanest result (otherwise it falls back to Lanczos, still fine).":""));
        tpUpdateNote(); };
      left.appendChild(vidWrap);

      // ===== LEFT: SAMPLING =====
      const sampWrap=mk("div",{marginTop:"18px"});
      sampWrap.appendChild(sectionTitle("Sampling"));
      const sRow=mk("div",{display:"flex",gap:"6px",alignItems:"center",flexWrap:"wrap",marginBottom:"10px"});
      const stepsIn=NI(S.steps,1,100,1,v=>{S.steps=v;persist();});
      sRow.append(tx(mk("span",{fontSize:"10px",color:C.muted}),"steps"),stepsIn._inp);
      sampWrap.appendChild(sRow);
      const ddSampWrap=mk("div",{display:"flex",gap:"6px",marginBottom:"6px"});
      const sW=mk("div",{flex:"1"}); const samplerDD=DD(SAMPLERS,S.sampler,v=>{S.sampler=v;persist();}); sW.append(cap("Sampler"),samplerDD);
      const cW=mk("div",{flex:"1"}); const schedDD=DD(SCHEDULERS,S.scheduler,v=>{S.scheduler=v;persist();}); cW.append(cap("Scheduler"),schedDD);
      ddSampWrap.append(sW,cW); sampWrap.appendChild(ddSampWrap);
      const schedHint=tx(mk("div",{fontSize:"9px",color:C.muted,margin:"0 0 10px",lineHeight:"1.4"}),"");
      sampWrap.appendChild(schedHint);
      // seed
      const seedRow=mk("div",{display:"flex",gap:"10px",alignItems:"center",flexWrap:"wrap"});
      const seedTgl=Toggle("Randomize seed",S.randomizeSeed,v=>{S.randomizeSeed=v;seedIn._inp.style.opacity=v?".4":"1";persist();},LIME);
      const seedIn=NI(S.seed,0,9e15,1,v=>{S.seed=v;persist();},"120px"); seedIn._inp.style.opacity=S.randomizeSeed?".4":"1";
      seedRow.append(seedTgl,tx(mk("span",{fontSize:"10px",color:C.muted}),"seed"),seedIn._inp);
      sampWrap.appendChild(seedRow);
      const guideNote=tx(mk("div",{fontSize:"9px",color:C.muted,margin:"8px 0 0",lineHeight:"1.45"}),"MiniMax H3 is guidance-distilled: positive-only (no CFG, no negative prompt). Put everything — including what you DON'T want, phrased positively — in the prompt.");
      sampWrap.appendChild(guideNote);
      left.appendChild(sampWrap);

      // ===== LEFT: ADVANCED (collapsible) =====
      const advWrap=mk("div",{marginTop:"18px"});
      const advHdr=tx(mk("div",{fontSize:"10px",fontWeight:"800",letterSpacing:".12em",textTransform:"uppercase",color:LIME,cursor:"pointer",borderBottom:"1px solid "+C.border,paddingBottom:"6px"}),"▸ Advanced");
      const advBody=mk("div",{display:"none",marginTop:"10px"});
      advHdr.onclick=()=>{ const open=advBody.style.display==="none"; advBody.style.display=open?"block":"none"; advHdr.textContent=(open?"▾":"▸")+" Advanced"; };
      advWrap.append(advHdr,advBody);
      // sigma shift
      const shiftTgl=Toggle("Custom sigma shift (video / audio flow)",S.sigmaShiftOn,v=>{S.sigmaShiftOn=v;shiftRows.style.display=v?"flex":"none";persist();},LIME);
      advBody.appendChild(shiftTgl);
      const shiftRows=mk("div",{display:S.sigmaShiftOn?"flex":"none",gap:"10px",alignItems:"center",flexWrap:"wrap",margin:"8px 0 0"});
      const shVid=NI(S.shiftVideo,0.01,100,0.5,v=>{S.shiftVideo=v;persist();},"60px");
      const shAud=NI(S.shiftAudio,0.01,100,0.5,v=>{S.shiftAudio=v;persist();},"60px");
      shiftRows.append(tx(mk("span",{fontSize:"10px",color:C.muted}),"video"),shVid._inp,tx(mk("span",{fontSize:"10px",color:C.muted}),"audio"),shAud._inp);
      advBody.appendChild(shiftRows);
      const shiftHint=tx(mk("div",{fontSize:"9px",color:C.muted,margin:"6px 0 0",lineHeight:"1.4"}),"Off = the model's built-in shifts (video 12 / audio 3). Higher video shift = more motion/structure change; only touch if you know what you're doing.");
      advBody.appendChild(shiftHint);
      // speed (experimental) — sage attention + Blackwell fast fp8, applied to ALL modes
      const spTitle=tx(mk("div",{fontSize:"9px",fontWeight:"800",letterSpacing:".1em",textTransform:"uppercase",color:LIME,margin:"14px 0 8px",borderTop:"1px solid "+C.border,paddingTop:"10px"}),"Speed (experimental)");
      advBody.appendChild(spTitle);
      // ── Distilled Turbo PRESETS (lightx2v) — ONE-CLICK, LOCKED recipes. Pick one and only the
      //    render-quality dial stays yours; everything else (LoRA, sigma shift, sampler, steps) is
      //    forced to the exact trained values in generate(). These ride the H3 applicator + sigma
      //    shift with a NORMAL euler sampler (NOT the TurboSampler, which these LoRAs don't use).
      const ptRow=mk("div",{display:"flex",gap:"6px",flexWrap:"wrap",margin:"2px 0 0",alignItems:"center"});
      ptRow.append(tx(mk("span",{fontSize:"10px",color:C.muted,marginRight:"2px"}),"⚡ 1-click Turbo:"));
      const ptOffP=Pill("Off",S.lxTurbo==="off",()=>setPreset("off"));
      const ptFlP=Pill("FL2V 768p",S.lxTurbo==="fl2v",()=>setPreset("fl2v"));
      const ptR2P=Pill("R2V lip-sync",S.lxTurbo==="r2v",()=>setPreset("r2v"));
      ptRow.append(ptOffP,ptFlP,ptR2P); advBody.appendChild(ptRow);
      const ptNote=mk("div",{fontSize:"9px",color:C.muted,margin:"6px 0 11px",lineHeight:"1.5"}); advBody.appendChild(ptNote);
      function setPreset(m){ S.lxTurbo=m; if(m!=="off"&&S.turboOn){ S.turboOn=false; try{applyTurboUI();}catch(_e){} } ptOffP._set(m==="off"); ptFlP._set(m==="fl2v"); ptR2P._set(m==="r2v"); persist(); refreshPreset(); try{updateSpeedNotes();}catch(_e){} }
      function refreshPreset(){
        const m=S.lxTurbo;
        if(m==="off"){ ptNote.innerHTML="Pick a preset for a <b>locked, correct-by-construction</b> turbo (4-step): it auto-wires the LoRA, sigma shift, euler sampler and steps — you only set <b>render quality</b> (megapixel + 2-pass). Or use the manual Turbo / shift controls below."; return; }
        const fl=(m==="fl2v"), lora=fl?_lxFl2vLora:_lxR2vLora, okMode=fl?(S.mode!=="r2v"):(S.mode==="r2v");
        let s="🔒 <b>"+(fl?"FL2V Turbo 768p":"R2V Turbo (lip-sync)")+"</b> — locked: <b>4 steps · shift "+(fl?"6/3":"12/3")+" · euler/simple · strength 1.0</b>. ";
        s+= fl ? "For <b>first→last-frame</b> keyframe / storyboard animation — render near <b>768p</b>. "
               : "For <b>R2V lip-sync</b> (idol / character) — keeps audio refs; render near <b>0.5&nbsp;MP</b>. ⚠ your <b>first run confirms</b> the lip-sync holds at 4 steps. ";
        if(!_turboNode) s+="<br><span style='color:#ff9a5a'>⚠ Turbo node not registered — RESTART ComfyUI.</span>";
        else if(!lora) s+="<br><span style='color:#ff9a5a'>⚠ LoRA not found in models/loras — hit ↻ Rescan.</span>";
        else if(!okMode) s+="<br><span style='color:#ff9a5a'>⚠ Switch to <b>"+(fl?"T2V / I2V":"R2V")+"</b> mode to use this preset.</span>";
        else s+="<br><span style='color:"+LIME+"'>✓ Ready.</span>";
        ptNote.innerHTML=s;
      }
      refreshPreset();
      // Turbo 4-step LoRA — the biggest speed win (~5×), applies to T2V / I2V / R2V
      const turboTgl=Toggle("Turbo 4-step LoRA (~5× faster)",S.turboOn,v=>{S.turboOn=v;if(v)setPreset("off");applyTurboUI();persist();updateSpeedNotes();},"#ff5fa2");
      advBody.appendChild(turboTgl);
      const turboRow=mk("div",{display:S.turboOn?"flex":"none",alignItems:"center",gap:"8px",margin:"7px 0 0"});
      turboRow.append(cap("Turbo steps")); turboRow.lastChild.style.margin="0";
      const turboStepsIn=NI(S.turboSteps,4,16,1,v=>{S.turboSteps=v;persist();},"52px"); turboRow.appendChild(turboStepsIn._inp);
      turboRow.append(tx(mk("span",{fontSize:"9px",color:C.muted}),"(6–8 = sharp)"));
      advBody.appendChild(turboRow);
      // Turbo LoRA selector (SAFEGUARD) — pick the exact H3 turbo LoRA so a wrong/krea2 LoRA can't
      // auto-load onto H3. Auto-detect just sets the default (v4); this lets you confirm/override + A/B.
      const turboLoraRow=mk("div",{display:S.turboOn?"block":"none",margin:"8px 0 0"});
      turboLoraRow.appendChild(cap("Turbo LoRA (H3)")); turboLoraRow.lastChild.style.margin="0 0 4px";
      const turboLoraDD=DD(["…"],S.turboLora||"…",v=>{ if(v&&v!=="…"&&v!=="(none found)"){ S.turboLora=v; persist(); updateSpeedNotes(); } });
      turboLoraRow.appendChild(turboLoraDD);
      advBody.appendChild(turboLoraRow);
      const turboHint=mk("div",{fontSize:"9px",color:C.muted,margin:"5px 0 11px",lineHeight:"1.45"});
      advBody.appendChild(turboHint);
      const applyTurboUI=()=>{ const on=S.turboOn; turboRow.style.display=on?"flex":"none"; turboLoraRow.style.display=on?"block":"none"; };
      // Style / character LoRA — any H3-format LoRA (a look, a character). Recommends the latest
      // available by default; the dropdown always lets you change it. Applied via the H3 applicator.
      const styleTgl=Toggle("Style LoRA (character / look)",S.styleOn,v=>{S.styleOn=v;applyStyleUI();persist();},"#8b5cf6");
      advBody.appendChild(styleTgl);
      const styleLoraRow=mk("div",{display:S.styleOn?"block":"none",margin:"8px 0 0"});
      styleLoraRow.appendChild(cap("Style LoRA (H3)")); styleLoraRow.lastChild.style.margin="0 0 4px";
      const styleLoraDD=DD(["…"],S.styleLora||"…",v=>{ if(v&&v!=="…"&&v!=="(none found)"){ S.styleLora=v; persist(); } });
      styleLoraRow.appendChild(styleLoraDD);
      advBody.appendChild(styleLoraRow);
      const styleStrRow=mk("div",{display:S.styleOn?"flex":"none",alignItems:"center",gap:"8px",margin:"7px 0 0"});
      styleStrRow.append(cap("Strength")); styleStrRow.lastChild.style.margin="0";
      const styleStrIn=NI(S.styleStrength,0,2,0.05,v=>{S.styleStrength=v;persist();},"58px"); styleStrRow.appendChild(styleStrIn._inp);
      advBody.appendChild(styleStrRow);
      const styleHint=mk("div",{fontSize:"9px",color:C.muted,margin:"5px 0 11px",lineHeight:"1.45"});
      styleHint.innerHTML="Any H3 <b>style / character</b> LoRA — drop it in <b>models/loras</b>, hit <b>↻ Rescan</b>. Uses the H3 applicator (standard loaders don't match H3 keys). With <b>Turbo</b> on it applies in <b>merge</b> mode for compatibility. <i>H3 style LoRAs are just emerging — the list may be empty for now.</i>";
      advBody.appendChild(styleHint);
      const applyStyleUI=()=>{ const on=S.styleOn; styleLoraRow.style.display=on?"block":"none"; styleStrRow.style.display=on?"flex":"none"; };
      const sageTgl=Toggle("Sage attention — mem-efficient (KJNodes)",S.sageAttn,v=>{S.sageAttn=v;if(v)S.solAttn=false;persist();updateSpeedNotes();},"#5fd0ff");
      advBody.appendChild(sageTgl);
      const sageHint=mk("div",{fontSize:"9px",color:C.muted,margin:"5px 0 11px",lineHeight:"1.45"});
      advBody.appendChild(sageHint);
      const solTgl=Toggle("Sol-Attn — sparse (Blackwell: faster + less VRAM)",S.solAttn,v=>{S.solAttn=v;if(v)S.sageAttn=false;persist();updateSpeedNotes();},"#8f7fff");
      advBody.appendChild(solTgl);
      const solHint=mk("div",{fontSize:"9px",color:C.muted,margin:"5px 0 11px",lineHeight:"1.45"});
      advBody.appendChild(solHint);
      const fastTgl=Toggle("Blackwell fast FP8 (RTX 50-series)",S.fastFp8,v=>{S.fastFp8=v;persist();updateSpeedNotes();},"#5fd0ff");
      advBody.appendChild(fastTgl);
      const fastHint=mk("div",{fontSize:"9px",color:C.muted,margin:"5px 0 0",lineHeight:"1.45"});
      advBody.appendChild(fastHint);

      // ── cache accelerator (step reuse) — mutually exclusive; biggest win on full-quality runs ──
      const cacheTitle=tx(mk("div",{fontSize:"9px",fontWeight:"800",letterSpacing:".1em",textTransform:"uppercase",color:LIME,margin:"14px 0 8px",borderTop:"1px solid "+C.border,paddingTop:"10px"}),"Cache accelerator (step reuse)");
      advBody.appendChild(cacheTitle);
      const cacheRow=mk("div",{display:"flex",gap:"6px",flexWrap:"wrap",marginBottom:"6px"});
      const _cacheDefs=[["off","Off"],["teacache","TeaCache ⭐"],["spectrum","Spectrum"],["fbc","FirstBlockCache"]];
      const _cachePills=_cacheDefs.map(([v,lbl])=>Pill(lbl,S.cacheEngine===v,()=>setCacheEngine(v)));
      cacheRow.append(..._cachePills); advBody.appendChild(cacheRow);
      const cacheKnob=mk("div",{display:"flex",alignItems:"center",gap:"10px",flexWrap:"wrap",margin:"2px 0 0"});
      const teaKnobWrap=mk("div",{display:"none",alignItems:"center",gap:"5px"});
      const teaKnob=NI(S.teaThresh,0.0,0.5,0.01,v=>{S.teaThresh=v;persist();},"56px");
      teaKnobWrap.append(tx(mk("span",{fontSize:"9px",color:C.muted}),"threshold"),teaKnob._inp,tx(mk("span",{fontSize:"9px",color:C.muted}),"↑ = faster / more drift"));
      const specKnobWrap=mk("div",{display:"none",alignItems:"center",gap:"5px"});
      const specKnob=NI(S.spectrumBlend,0.1,1.0,0.05,v=>{S.spectrumBlend=v;persist();},"56px");
      specKnobWrap.append(tx(mk("span",{fontSize:"9px",color:C.muted}),"blend"),specKnob._inp,tx(mk("span",{fontSize:"9px",color:C.muted}),"↑ = faster / more drift"));
      const fbcKnobWrap=mk("div",{display:"none",alignItems:"center",gap:"6px",flexWrap:"wrap"});
      const _fbcDefs=[["H3 Safe — 0.08 / max 2","Safe"],["H3 Fast — 0.10 / max 2","Fast"],["H3 Aggressive — 0.12 / max 2","Aggressive"]];
      const _fbcPills=_fbcDefs.map(([v,lbl])=>Pill(lbl,S.fbcMode===v,()=>{ S.fbcMode=v; _fbcPills.forEach((p,i)=>p._set(_fbcDefs[i][0]===v)); persist(); }));
      fbcKnobWrap.append(tx(mk("span",{fontSize:"9px",color:C.muted}),"preset"),..._fbcPills);
      cacheKnob.append(teaKnobWrap,specKnobWrap,fbcKnobWrap); advBody.appendChild(cacheKnob);
      const cacheBanner=mk("div",{display:"none",margin:"6px 0 0",padding:"7px",borderRadius:"6px",border:"1px solid #cc7a00",background:"rgba(255,150,0,.08)",fontSize:"9px",color:"#ffb84d",lineHeight:"1.4"});
      advBody.appendChild(cacheBanner);
      const cacheHint=mk("div",{fontSize:"9px",color:C.muted,margin:"6px 0 0",lineHeight:"1.45"});
      advBody.appendChild(cacheHint);
      const _cacheAvail=(e)=>e==="teacache"?_teaAvailable:e==="spectrum"?_spectrumAvailable:e==="fbc"?_fbcAvailable:true;
      const _cacheNodeName=(e)=>e==="teacache"?"ComfyUI-MiniMaxH3-TeaCache":e==="spectrum"?"ComfyUI-Spectrum-MiniMax-H3":"ComfyUI-MiniMaxH3-FirstBlockCache";
      const updateCacheUI=()=>{
        _cachePills.forEach((p,i)=>p._set(_cacheDefs[i][0]===S.cacheEngine));
        teaKnobWrap.style.display=S.cacheEngine==="teacache"?"flex":"none";
        specKnobWrap.style.display=S.cacheEngine==="spectrum"?"flex":"none";
        fbcKnobWrap.style.display=S.cacheEngine==="fbc"?"flex":"none";
        const e=S.cacheEngine, avail=_cacheAvail(e);
        cacheBanner.style.display=(e!=="off"&&!avail)?"block":"none";
        if(e!=="off"&&!avail) cacheBanner.innerHTML="<b>"+_cacheNodeName(e)+"</b> isn't detected — clone it into <code>custom_nodes</code> and <b>restart ComfyUI</b> so it registers.";
        cacheHint.innerHTML = e==="off"
          ? "Reuses transformer output across near-identical steps to skip redundant compute. <b>Pick one</b> — biggest win on <b>full-quality</b> (higher-step) runs; little benefit with Turbo's few steps. Not lossless, so <b>A/B it</b>."
          : e==="teacache"
          ? "<b>TeaCache</b> — reuses a forward pass while the input barely changes. <b>~3× measured</b>, quality A/B-matches around <b>0.15</b>; higher = faster / more drift. First & last steps stay real. <b>The recommended one.</b>"
          : e==="spectrum"
          ? "<b>Spectrum</b> — forecasts features (Chebyshev regression) to skip steps. ~1.3×, conservative; <b>audio kept native</b> for fidelity. Not lossless (can shift some seeds) — <b>A/B it</b>. History in system RAM (16 GB-safe)."
          : "<b>FirstBlockCache</b> — runs block 1 each step, reuses the rest when the change is small. <b>Safe / Fast / Aggressive</b> = 0.08 / 0.10 / 0.12. Lightweight, VRAM-neutral.";
      };
      const setCacheEngine=(v)=>{ S.cacheEngine=v; updateCacheUI(); persist(); };

      const updateSpeedNotes=()=>{
        sageTgl._set(S.sageAttn); solTgl._set(S.solAttn); fastTgl._set(S.fastFp8); turboTgl._set(S.turboOn); applyTurboUI();
        styleTgl._set(S.styleOn); applyStyleUI();
        const turboReady=_turboNode && !!S.turboLora;
        turboHint.innerHTML = turboReady
          ? "larryvrh's <b>4-step Turbo LoRA</b> + its dual-schedule sampler — <b>~5× faster</b> (works on your pruned fp8 base). 4 = fastest/softer, <b>6–8 = sharp</b>. Overrides steps &amp; sampler, and turns off custom sigma shift. <b>R2V note:</b> Turbo can't condition on <b>audio references</b> (video soundtracks / ref audio) — to use reference audio, turn Turbo <b>off</b>; image / video refs work with Turbo. LoRA: <code>"+(S.turboLora||"—")+"</code>."
          : "<span style='color:#c9a06a'>Turbo LoRA is installed — <b>restart ComfyUI</b> so the MiniMax-H3-Turbo node registers, then toggle on. (Needs the node + a turbo LoRA in models/loras.)</span>";
        sageHint.innerHTML = _sageAvailable
          ? "Patches H3 self-attention to a memory-efficient SageAttention kernel — benchmarks show <b>~7% faster + lower peak VRAM</b>, output near-identical. Uses your <code>--use-sage-attention</code> launch."
          : "<span style='color:#c9a06a'>Needs ComfyUI-KJNodes + a recent <code>sageattention</code> (not detected). Install KJNodes and restart, then toggle on.</span>";
        solHint.innerHTML = _solAvailable
          ? "NVIDIA <b>Sol-Attn</b> sparse attention + FFN chunking, H3-specific for your Blackwell card — benchmarks show <b>~1.15–1.4× faster and ~37% less MLP VRAM</b>. Keeps prompt/reference/audio KV exact, so sync holds; the rest is approximate (not bit-identical), so <b>A/B it</b>. <b>Replaces Sage</b> when on."
          : "<span style='color:#c9a06a'>Sol-Attn is installed — <b>restart ComfyUI</b> so its H3 nodes register, then toggle on. (Needs Blackwell SM120 + Triton TMA — you have both.)</span>";
        // int8/NVFP4/convrot models carry their quantization in the file — ComfyUI runs the right
        // kernels automatically, so the fp8 toggle doesn't apply. Show that instead of misleading.
        const _actUnet=((S.mode==="r2v"?S.unetRef:S.unetFl)||"");
        const _int8Model=/int8|w8a8|convrot|nvfp4|fp4/i.test(_actUnet);
        fastTgl.style.opacity=_int8Model?".4":"1";
        fastHint.innerHTML = _int8Model
          ? "<span style='color:#7fd0a0'>A <b>quantized model</b> is selected (<code>"+_actUnet.split("/").pop()+"</code>). It's <b>already quantized in the file</b> (int8/convrot or NVFP4) — ComfyUI runs its native kernels automatically, so this fp8 toggle is <b>ignored</b>. No extra switch needed: picking the model <i>is</i> the switch.</span>"
          : "Loads the fp8 model with fast fp8 matmul (<code>fp8_e4m3fn_fast</code>) — Blackwell/50-series tensor-core acceleration on your <b>existing</b> weights. Small speed win; can very slightly shift quality, so A/B it. For a bigger jump, use an <b>int8/convrot</b> or <b>NVFP4</b> model (just select it — no toggle).";
      };
      left.appendChild(advWrap);

      // ===== LEFT: MODELS (collapsible, auto-detected) =====
      const modWrap=mk("div",{marginTop:"18px"});
      const modHdrRow=mk("div",{display:"flex",alignItems:"center",justifyContent:"space-between",borderBottom:"1px solid "+C.border,paddingBottom:"6px",cursor:"pointer"});
      const modHdr=tx(mk("div",{fontSize:"10px",fontWeight:"800",letterSpacing:".12em",textTransform:"uppercase",color:LIME}),"▸ Models");
      const modStatus=tx(mk("span",{fontSize:"9px",fontWeight:"700"}),"");
      modHdrRow.append(modHdr,modStatus);
      const modBody=mk("div",{display:"none",marginTop:"10px"});
      modHdrRow.onclick=()=>{ const open=modBody.style.display==="none"; modBody.style.display=open?"block":"none"; modHdr.textContent=(open?"▾":"▸")+" Models"; };
      modWrap.append(modHdrRow,modBody);
      const ddRow=(label)=>{ const r=mk("div",{marginBottom:"8px"}); r.appendChild(cap(label)); const dd=DD(["none"],"none",()=>{}); r.appendChild(dd); r._dd=dd; return r; };
      const mFl=ddRow("Diffusion · fl2va (T2V / I2V)");
      const mRef=ddRow("Diffusion · ref2va (R2V)");
      const mTE=ddRow("Text encoder (Qwen3-VL · minimax)");
      const mVVae=ddRow("VAE · video");
      const mAVae=ddRow("VAE · audio");
      mFl._dd=DD(["none"],"none",v=>{S.unetFl=v==="none"?"":v;persist();updateModStatus();updateSpeedNotes();}); mFl.replaceChild(mFl._dd,mFl.lastChild);
      mRef._dd=DD(["none"],"none",v=>{S.unetRef=v==="none"?"":v;persist();updateModStatus();updateSpeedNotes();}); mRef.replaceChild(mRef._dd,mRef.lastChild);
      mTE._dd=DD(["none"],"none",v=>{S.textEncoder=v==="none"?"":v;persist();updateModStatus();}); mTE.replaceChild(mTE._dd,mTE.lastChild);
      mVVae._dd=DD(["none"],"none",v=>{S.videoVae=v==="none"?"":v;persist();updateModStatus();}); mVVae.replaceChild(mVVae._dd,mVVae.lastChild);
      mAVae._dd=DD(["none"],"none",v=>{S.audioVae=v==="none"?"":v;persist();updateModStatus();}); mAVae.replaceChild(mAVae._dd,mAVae.lastChild);
      [mFl,mRef,mTE,mVVae,mAVae].forEach(r=>modBody.appendChild(r));
      const rescanBtn=tx(mk("button",{marginTop:"2px",padding:"5px 10px",fontSize:"10px",fontWeight:"700",background:C.bg2,border:"1px solid "+C.border,borderRadius:"6px",color:LIME,cursor:"pointer"}),"↻ Rescan models");
      rescanBtn.onclick=()=>_loadModels();
      modBody.appendChild(rescanBtn);
      left.appendChild(modWrap);
      const updateModStatus=()=>{
        const need=(S.mode==="r2v")?[S.unetRef,S.textEncoder,S.videoVae,S.audioVae]:[S.unetFl,S.textEncoder,S.videoVae,S.audioVae];
        const ok=need.every(v=>v&&v!=="none");
        modStatus.textContent=ok?"✓ detected":"⚠ missing";
        modStatus.style.color=ok?LIME:"#ff9f43";
      };

      // ===== LEFT: DOWNLOAD DOCS (collapsible, default collapsed) =====
      const dl=mk("div",{marginTop:"18px"});
      const dlHdr=tx(mk("div",{fontSize:"10px",fontWeight:"800",letterSpacing:".12em",textTransform:"uppercase",color:LIME,cursor:"pointer",borderBottom:"1px solid "+C.border,paddingBottom:"6px"}),"▸ Models — where to download");
      const dlBody=mk("div",{display:"none",marginTop:"10px"});
      dlHdr.onclick=()=>{ const open=dlBody.style.display==="none"; dlBody.style.display=open?"block":"none"; dlHdr.textContent=(open?"▾":"▸")+" Models — where to download"; };
      dl.append(dlHdr,dlBody);
      const dlBox=mk("div",{fontSize:"10px",color:C.text,lineHeight:"1.55"});
      const HF="https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main";
      dlBox.innerHTML=
        "All files from "+link("🤗 Comfy-Org/MiniMax-H3","https://huggingface.co/Comfy-Org/MiniMax-H3")+" (pick ONE quant per model — fp8 or int8 ≈ 21GB, best for a 16–24GB card).<br>"+
        "<b style='color:"+LIME+"'>Diffusion</b> → <code>models/diffusion_models/</code><br>"+
        link("minimax_h3_fl2va_pruned_fp8_scaled.safetensors",HF+"/diffusion_models/minimax_h3_fl2va_pruned_fp8_scaled.safetensors")+" &nbsp;(T2V / I2V)<br>"+
        link("minimax_h3_ref2va_pruned_fp8_scaled.safetensors",HF+"/diffusion_models/minimax_h3_ref2va_pruned_fp8_scaled.safetensors")+" &nbsp;(R2V)<br>"+
        "<b style='color:"+LIME+"'>Text encoder</b> → <code>models/text_encoders/</code><br>"+
        link("qwen3vl_32b_minimax_h3_int8_convrot.safetensors",HF+"/text_encoders/qwen3vl_32b_minimax_h3_int8_convrot.safetensors")+" &nbsp;(or the <code>nvfp4_awq</code> variant on 50-series)<br>"+
        "<b style='color:"+LIME+"'>VAE</b> → <code>models/vae/</code><br>"+
        link("minimax_h3_video_vae_fp16.safetensors",HF+"/vae/minimax_h3_video_vae_fp16.safetensors")+"<br>"+
        link("minimax_h3_audio_vae_fp32.safetensors",HF+"/vae/minimax_h3_audio_vae_fp32.safetensors")+"<br>"+
        "<b style='color:#5fd0ff'>⚡ Faster on Blackwell (RTX 50-series): NVFP4 weights</b> → <code>models/diffusion_models/</code><br>"+
        link("MiniMax-H3 pruned NVFP4 (browse)","https://huggingface.co/models?search=minimax-h3%20nvfp4")+" — native FP4 tensor cores, ~half size &amp; fast; 4-bit trades a little motion fidelity vs int8/fp8. Select it in Models like any other diffusion file.<br>"+
        "<span style='color:"+C.muted+"'>After copying files, hit ↻ Rescan models (Models panel). Needs a current ComfyUI with the native MiniMax H3 nodes (PR #15224).</span>";
      dlBody.appendChild(dlBox);
      left.appendChild(dl);

      // ===== RIGHT: preview + generate =====
      const preview=mk("div",{flex:"1",borderRadius:"10px",border:"1px solid "+C.border,background:C.bg1,display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",position:"relative",minHeight:"0"});
      const placeholder=tx(mk("div",{color:C.muted,fontSize:"12px",textAlign:"center",padding:"24px"}),"Your video (with sound) will appear here.");
      // muted autoplay is the only reliable autoplay; the note tells users to unmute.
      const videoEl=mk("video",{maxWidth:"100%",maxHeight:"100%",display:"none"},{controls:true,autoplay:true,loop:true,muted:true});
      // fullscreen button (top-right of the preview) — only shown once a video is loaded
      const fsBtn=tx(mk("button",{position:"absolute",top:"8px",right:"8px",zIndex:"4",width:"30px",height:"30px",borderRadius:"7px",border:"1px solid "+C.border,background:"rgba(0,0,0,.6)",color:LIME,cursor:"pointer",fontSize:"14px",display:"none",alignItems:"center",justifyContent:"center",lineHeight:"1"}),"⛶");
      fsBtn.title="Fullscreen (Esc to close)";
      fsBtn.onclick=()=>openFullscreen();
      preview.append(placeholder,videoEl,fsBtn);

      // ── node-local fullscreen overlay (covers the whole panel; like Krea2) ──
      const fsOverlay=mk("div",{position:"absolute",inset:"0",zIndex:"60",background:"rgba(8,8,10,.98)",display:"none",flexDirection:"column",borderRadius:"12px"});
      const fsTop=mk("div",{position:"absolute",top:"0",left:"0",right:"0",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 14px",zIndex:"2",background:"linear-gradient(to bottom,rgba(0,0,0,.6),rgba(0,0,0,0))"});
      const fsName=tx(mk("div",{fontSize:"11px",fontWeight:"700",color:"#fff",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",flex:"1",padding:"0 10px 0 2px"}),"");
      const fsClose=tx(mk("button",{width:"30px",height:"30px",borderRadius:"50%",background:"rgba(255,255,255,.1)",border:"1px solid rgba(255,255,255,.2)",color:"#fff",fontSize:"14px",cursor:"pointer",flex:"0 0 auto",lineHeight:"1"}),"✕");
      fsClose.title="Close (Esc)"; fsClose.onclick=()=>closeFullscreen();
      fsTop.append(fsName,fsClose);
      const fsMedia=mk("div",{flex:"1",display:"flex",alignItems:"center",justifyContent:"center",padding:"52px 18px 18px",boxSizing:"border-box",minHeight:"0"});
      const fsVideo=mk("video",{maxWidth:"100%",maxHeight:"100%",borderRadius:"8px",boxShadow:"0 6px 30px rgba(0,0,0,.6)"},{controls:true,autoplay:true,loop:true});
      fsMedia.appendChild(fsVideo);
      fsOverlay.append(fsMedia,fsTop);
      root.appendChild(fsOverlay);
      let _fsFilename="";
      const openFullscreen=()=>{
        if(!videoEl.src||videoEl.style.display==="none") return;
        fsVideo.src=videoEl.src; fsVideo.muted=false; fsVideo.currentTime=videoEl.currentTime||0;
        fsName.textContent=_fsFilename||"";
        fsOverlay.style.display="flex"; try{ fsVideo.play&&fsVideo.play().catch(()=>{}); }catch(e){}
        fsOverlay.focus&&fsOverlay.focus();
      };
      const closeFullscreen=()=>{ try{ fsVideo.pause&&fsVideo.pause(); }catch(e){} fsVideo.src=""; fsOverlay.style.display="none"; };
      fsOverlay.setAttribute("tabindex","-1");
      fsOverlay.addEventListener("keydown",e=>{ if(e.key==="Escape")closeFullscreen(); });

      const audioNote=tx(mk("div",{fontSize:"9px",color:C.muted,textAlign:"center",margin:"6px 0 0"}),"🔊 H3 renders native stereo audio — unmute the player to hear it.");

      // ── progress (percent · step · elapsed) ──
      const progLabel=tx(mk("div",{marginTop:"10px",fontSize:"11px",fontWeight:"700",color:LIME,display:"none"}),"");
      const progWrap=mk("div",{marginTop:"5px",height:"10px",borderRadius:"5px",background:C.bg3,overflow:"hidden",display:"none"});
      const progBar=mk("div",{height:"100%",width:"0%",background:"linear-gradient(90deg,"+LIME+",#9be15d)",transition:"width .2s"});
      progWrap.appendChild(progBar);

      const errBox=mk("div",{marginTop:"8px",display:"none",fontSize:"10px",color:"#ff6b6b",background:"rgba(255,80,80,.08)",border:"1px solid rgba(255,80,80,.3)",borderRadius:"6px",padding:"7px",whiteSpace:"pre-wrap"});

      const btnRow=mk("div",{marginTop:"10px",display:"flex",gap:"8px"});
      const genBtn=tx(mk("button",{flex:"1",padding:"13px",borderRadius:"10px",border:"2px solid "+LIME,background:"rgba(240,255,65,.1)",color:LIME,fontSize:"13px",fontWeight:"800",letterSpacing:".06em",cursor:"pointer",textTransform:"uppercase"}),"▶ Generate");
      const folderBtn=tx(mk("button",{padding:"13px 14px",borderRadius:"10px",border:"1px solid "+C.border,background:C.bg2,color:C.text,fontSize:"11px",cursor:"pointer"}),"📁");
      folderBtn.title="Open output folder";
      folderBtn.onclick=()=>api.fetchApi("/minimaxh3/open_folder",{method:"POST",body:JSON.stringify({}),headers:{"Content-Type":"application/json"}});
      btnRow.append(genBtn,folderBtn);

      // ── gallery (recent renders) ──
      const galWrap=mk("div",{marginTop:"12px"});
      const galHdr=mk("div",{display:"flex",alignItems:"center",justifyContent:"space-between",gap:"6px",margin:"0 0 6px"});
      const galTitle=tx(mk("div",{fontSize:"9px",fontWeight:"800",letterSpacing:".1em",textTransform:"uppercase",color:C.muted}),"Gallery · recent renders");
      const galBtns=mk("div",{display:"flex",gap:"5px"});
      const galAllBtn=tx(mk("button",{fontSize:"9px",fontWeight:"700",background:C.bg2,border:"1px solid "+C.border,borderRadius:"5px",color:LIME,cursor:"pointer",padding:"2px 9px"}),"⤢ view all");
      const galRefresh=tx(mk("button",{fontSize:"9px",fontWeight:"700",background:C.bg2,border:"1px solid "+C.border,borderRadius:"5px",color:LIME,cursor:"pointer",padding:"2px 9px"}),"↻");
      galRefresh.title="Rescan output folder";
      galRefresh.onclick=()=>_loadGallery();
      galAllBtn.onclick=()=>openGalleryModal();
      galBtns.append(galAllBtn,galRefresh);
      galHdr.append(galTitle,galBtns);
      galWrap.appendChild(galHdr);
      const galStrip=mk("div",{display:"flex",gap:"6px",overflowX:"auto",paddingBottom:"5px"},{className:"mmh3-scroll"});
      const galEmpty=tx(mk("div",{fontSize:"9px",color:C.muted}),"Finished videos collect here — click one to see its settings.");
      galWrap.append(galStrip,galEmpty);

      right.append(preview,audioNote,progLabel,progWrap,errBox,btnRow,galWrap);

      // heart icon (fill follows currentColor so the button/badge colour controls it)
      const _mkHeart=(size)=>{ const s=document.createElementNS("http://www.w3.org/2000/svg","svg"); s.setAttribute("viewBox","0 0 24 24"); s.setAttribute("width",size); s.setAttribute("height",size); s.style.display="block"; const p=document.createElementNS("http://www.w3.org/2000/svg","path"); p.setAttribute("d","M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"); p.setAttribute("fill","currentColor"); s.appendChild(p); return s; };

      // ── full-panel "view all" grid (browse renders + favorites filter) ──
      const galModal=mk("div",{position:"absolute",inset:"0",background:"rgba(8,8,8,.97)",zIndex:"50",display:"none",flexDirection:"column",borderRadius:"12px"});
      const gmHdr=mk("div",{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 14px",borderBottom:"1px solid "+C.border});
      const gmTitle=tx(mk("div",{fontSize:"12px",fontWeight:"800",letterSpacing:".04em",color:LIME}),"Gallery");
      const gmBtns=mk("div",{display:"flex",gap:"8px",alignItems:"center"});
      const gmFav=mk("button",{fontSize:"10px",fontWeight:"700",background:C.bg2,border:"1px solid "+C.border,borderRadius:"6px",color:C.muted,cursor:"pointer",padding:"5px 11px",display:"flex",alignItems:"center",gap:"5px"});
      const _gmFavIco=_mkHeart("12px"); gmFav.append(_gmFavIco,tx(mk("span"),"Favorites"));
      const gmRefresh=tx(mk("button",{fontSize:"10px",fontWeight:"700",background:C.bg2,border:"1px solid "+C.border,borderRadius:"6px",color:LIME,cursor:"pointer",padding:"5px 11px"}),"↻ refresh");
      const gmClose=tx(mk("button",{fontSize:"12px",fontWeight:"800",background:C.bg2,border:"1px solid "+C.border,borderRadius:"6px",color:C.text,cursor:"pointer",padding:"4px 12px"}),"✕ close");
      const _styleGmFav=()=>{ gmFav.style.color=_favOnly?LIME:C.muted; gmFav.style.borderColor=_favOnly?LIME:C.border; gmFav.style.background=_favOnly?"rgba(240,255,65,.12)":C.bg2; };
      gmFav.onclick=()=>{ _favOnly=!_favOnly; _styleGmFav(); renderGalleryModal(); };
      gmRefresh.onclick=()=>_loadGallery();
      gmClose.onclick=()=>{ _galSelectCb=null; galModal.style.display="none"; };
      gmBtns.append(gmFav,gmRefresh,gmClose); gmHdr.append(gmTitle,gmBtns);
      const gmGrid=mk("div",{flex:"1",overflowY:"auto",padding:"12px",display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:"10px",alignContent:"start"},{className:"mmh3-scroll"});
      galModal.append(gmHdr,gmGrid);
      root.appendChild(galModal);

      // ══ gallery detail lightbox (settings · player · restore · favorite) ══════
      const lb=mk("div",{position:"absolute",inset:"0",background:"#0a0a0a",zIndex:"60",display:"none",flexDirection:"column",borderRadius:"12px",boxSizing:"border-box"});
      const lbTop=mk("div",{display:"flex",alignItems:"center",gap:"8px",padding:"10px 12px 6px",flexShrink:"0"});
      const lbName=mk("div",{flex:"1",fontSize:"11px",color:C.muted,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"});
      const lbCloseBtn=tx(mk("button",{background:"transparent",border:"1px solid #e05555",borderRadius:"6px",padding:"3px 12px",fontSize:"11px",color:"#e05555",cursor:"pointer",outline:"none"}),"✕");
      lbTop.append(lbName,lbCloseBtn);
      const lbBody=mk("div",{display:"flex",alignItems:"center",flex:"1",minHeight:"0",gap:"8px",padding:"0 8px"});
      const _lbArrow=(t)=>{ const b=tx(mk("button",{background:"rgba(255,255,255,.08)",border:"none",borderRadius:"6px",width:"38px",flexShrink:"0",alignSelf:"stretch",cursor:"pointer",fontSize:"20px",color:C.text,outline:"none"}),t); b.onmouseenter=()=>b.style.background="rgba(255,255,255,.16)"; b.onmouseleave=()=>b.style.background="rgba(255,255,255,.08)"; return b; };
      const lbPrev=_lbArrow("‹"), lbNext=_lbArrow("›");
      const lbVidWrap=mk("div",{flex:"1",minWidth:"0",display:"flex",alignItems:"center",justifyContent:"center",height:"100%",minHeight:"0"});
      const lbVid=mk("video",{maxWidth:"100%",maxHeight:"100%",borderRadius:"8px",background:"#000",display:"block"},{controls:true,loop:true,preload:"metadata"});
      lbVidWrap.appendChild(lbVid);
      lbBody.append(lbPrev,lbVidWrap,lbNext);
      // meta panel
      const lbMeta=mk("div",{flexShrink:"0",margin:"6px 8px",background:"linear-gradient(180deg,rgba(240,255,65,.07),rgba(240,255,65,.02))",border:"1px solid rgba(240,255,65,.2)",borderRadius:"10px",padding:"9px 12px",display:"none",flexDirection:"column",gap:"7px",maxHeight:"48%",overflowY:"auto"},{className:"mmh3-scroll"});
      const lbPromptWrap=mk("div",{display:"flex",flexDirection:"column",gap:"3px"});
      lbPromptWrap.appendChild(tx(mk("div",{fontSize:"8px",color:C.muted,fontWeight:"700",letterSpacing:".08em",textTransform:"uppercase"}),"Prompt"));
      const lbPrompt=mk("div",{fontSize:"10px",color:C.text,lineHeight:"1.5",maxHeight:"66px",overflowY:"auto",whiteSpace:"pre-wrap"},{className:"mmh3-scroll"});
      lbPromptWrap.appendChild(lbPrompt);
      const lbChips=mk("div",{display:"flex",gap:"6px",flexWrap:"wrap"});
      const lbRefs=mk("div",{display:"none",gap:"6px",flexWrap:"wrap",alignItems:"flex-end"});
      const lbActions=mk("div",{display:"flex",gap:"6px",alignItems:"stretch",flexWrap:"wrap",marginTop:"1px"});
      const lbRestore=tx(mk("button",{background:LIME,color:"#111",border:"none",borderRadius:"6px",padding:"6px 14px",fontSize:"11px",fontWeight:"800",cursor:"pointer",outline:"none",display:"none",alignItems:"center",whiteSpace:"nowrap"}),"Load settings into UI");
      lbRestore.onmouseenter=()=>lbRestore.style.opacity=".85"; lbRestore.onmouseleave=()=>lbRestore.style.opacity="1";
      const lbFav=mk("button",{background:"rgba(20,20,30,.85)",border:"1px solid rgba(240,255,65,.25)",borderRadius:"6px",width:"38px",flexShrink:"0",cursor:"pointer",outline:"none",display:"flex",alignItems:"center",justifyContent:"center",color:"rgba(240,255,65,.4)"});
      lbFav.title="Favorite (♥)"; lbFav.appendChild(_mkHeart("15px"));
      const lbFolder=tx(mk("button",{background:"transparent",border:"1px solid "+C.border,borderRadius:"6px",padding:"6px 11px",fontSize:"10px",color:C.muted,cursor:"pointer",outline:"none",whiteSpace:"nowrap"}),"📁 Show in folder");
      lbFolder.onmouseenter=()=>{lbFolder.style.borderColor=C.text;lbFolder.style.color=C.text;}; lbFolder.onmouseleave=()=>{lbFolder.style.borderColor=C.border;lbFolder.style.color=C.muted;};
      const lbDel=tx(mk("button",{background:"rgba(160,25,25,.6)",border:"1px solid rgba(255,80,80,.3)",borderRadius:"6px",padding:"6px 11px",fontSize:"10px",fontWeight:"700",color:"rgba(255,190,190,.95)",cursor:"pointer",outline:"none",whiteSpace:"nowrap",marginLeft:"auto"}),"🗑 Delete");
      lbActions.append(lbRestore,lbFav,lbFolder,lbDel);
      lbMeta.append(lbPromptWrap,lbChips,lbRefs,lbActions);
      const lbBottom=mk("div",{display:"flex",justifyContent:"center",alignItems:"center",padding:"4px 10px 8px",flexShrink:"0"});
      const lbCounter=mk("div",{fontSize:"10px",color:C.muted}); lbBottom.appendChild(lbCounter);
      lb.append(lbTop,lbBody,lbMeta,lbBottom);
      root.appendChild(lb);

      // small labelled chip + tag helpers for the meta panel
      const _lbChip=(label,val)=>{ const c=mk("div",{display:"flex",flexDirection:"column",gap:"1px",background:C.bg3,borderRadius:"5px",padding:"4px 8px",minWidth:"42px"}); c.append(tx(mk("div",{fontSize:"7.5px",color:C.muted,fontWeight:"700",letterSpacing:".06em",textTransform:"uppercase"}),label),tx(mk("div",{fontSize:"10px",color:C.text,fontWeight:"600"}),val==null||val===""?"—":String(val))); return c; };
      const _lbTag=(t,col)=>tx(mk("span",{fontSize:"9px",color:col||C.muted,background:C.bg3,borderRadius:"4px",padding:"3px 7px",border:"1px solid "+C.border,whiteSpace:"nowrap",alignSelf:"center"}),t);
      const _lbRefThumb=(name,type,label)=>{ const wrap=mk("div",{display:"flex",flexDirection:"column",alignItems:"center",gap:"2px"}); const url="/view?filename="+encodeURIComponent(name)+"&type=input"; let el;
        if(type==="video"){ el=mk("video",{width:"48px",height:"48px",objectFit:"cover",borderRadius:"5px",border:"1px solid "+C.border,background:"#000"},{src:url+"#t=0.1",muted:true,preload:"metadata"}); _thumbFrame(el); }
        else { el=mk("img",{width:"48px",height:"48px",objectFit:"cover",borderRadius:"5px",border:"1px solid "+C.border,background:"#000"},{src:url}); }
        el.title=name; wrap.append(el,tx(mk("div",{fontSize:"7.5px",color:C.muted}),label)); return wrap; };

      // ── gallery data + rendering ──
      const _galItems=[];       // {filename,subfolder,type,mtime,favorite,has_meta}
      const _galMetaCache={};   // filename -> meta object (or null when none saved)
      let _favOnly=false;       // modal filter: show only favorited clips
      let _galSelectCb=null;    // when set, clicking a modal item selects it instead of opening details
      const _viewUrl=(it)=>{ const sub=it.subfolder?`&subfolder=${encodeURIComponent(it.subfolder)}`:""; return `/view?filename=${encodeURIComponent(it.filename)}&type=${encodeURIComponent(it.type||"output")}${sub}`; };
      // force a still frame for the thumbnail (preload=metadata alone paints black in most
      // browsers) by seeking a touch into the clip once it has data.
      const _thumbFrame=(v)=>{ v.addEventListener("loadeddata",()=>{ try{ if(v.currentTime<0.05)v.currentTime=0.12; }catch(e){} },{once:true}); };
      const _playInPreview=(it)=>{ _showVideoUrl(_viewUrl(it)+"&rand="+Math.random(), it.filename); };
      const _fetchMeta=async(it,force)=>{ const k=it.filename; if(!force&&_galMetaCache[k]!==undefined)return _galMetaCache[k];
        try{ const r=await api.fetchApi("/minimaxh3/meta?filename="+encodeURIComponent(it.filename)+"&subfolder="+encodeURIComponent(it.subfolder||"")); const d=await r.json(); _galMetaCache[k]=d.ok?d.meta:null; if(d&&typeof d.favorite==="boolean")it.favorite=d.favorite; }
        catch(e){ _galMetaCache[k]=null; } return _galMetaCache[k]; };

      // small favorite-heart badge for a thumbnail cell
      const _favBadge=()=>{ const b=mk("div",{position:"absolute",top:"4px",right:"4px",color:LIME,filter:"drop-shadow(0 1px 2px rgba(0,0,0,.9))",pointerEvents:"none"}); b.appendChild(_mkHeart("13px")); return b; };

      const renderGallery=()=>{
        galTitle.textContent="Gallery · "+(_galItems.length?_galItems.length+" render"+(_galItems.length>1?"s":""):"recent renders");
        galStrip.innerHTML="";
        if(!_galItems.length){ galEmpty.style.display="block"; return; }
        galEmpty.style.display="none";
        // quick strip = the 30 most recent (scrolls horizontally); "view all" shows the rest
        _galItems.slice(0,30).forEach((it,i)=>{
          const cell=mk("div",{position:"relative",flex:"0 0 auto",width:"108px",height:"62px",borderRadius:"6px",overflow:"hidden",border:"1px solid "+C.border,cursor:"pointer",background:"#000"});
          const v=mk("video",{width:"100%",height:"100%",objectFit:"cover",pointerEvents:"none"},{src:_viewUrl(it)+"#t=0.12",muted:true,preload:"metadata"});
          _thumbFrame(v);
          const info=tx(mk("div",{position:"absolute",inset:"0",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"15px",color:"rgba(255,255,255,.85)",textShadow:"0 0 4px #000"}),"ⓘ");
          cell.append(v,info); if(it.favorite)cell.appendChild(_favBadge()); cell.title=it.filename;
          cell.onclick=()=>_lbShow(it,i,_galItems);
          galStrip.appendChild(cell);
        });
        if(galModal.style.display!=="none") renderGalleryModal();
      };
      const renderGalleryModal=()=>{
        const selecting=!!_galSelectCb;
        const list=(!selecting&&_favOnly)?_galItems.filter(it=>it.favorite):_galItems;
        gmTitle.textContent=(selecting?"Pick a video to upscale — ":(_favOnly?"Favorites — ":"Gallery — "))+list.length+" render"+(list.length===1?"":"s");
        gmGrid.innerHTML="";
        if(!list.length){ gmGrid.appendChild(tx(mk("div",{color:C.muted,fontSize:"11px"}),_favOnly&&!selecting?"No favorites yet — open a clip and tap the ♥.":"No renders yet.")); return; }
        list.forEach((it,i)=>{
          const cell=mk("div",{display:"flex",flexDirection:"column",gap:"3px",cursor:"pointer"});
          const thumbWrap=mk("div",{position:"relative",width:"100%",aspectRatio:"16/9",borderRadius:"7px",overflow:"hidden",border:"1px solid "+C.border,background:"#000"});
          const v=mk("video",{width:"100%",height:"100%",objectFit:"cover"},{src:_viewUrl(it)+"#t=0.12",muted:true,preload:"metadata",controls:false});
          _thumbFrame(v);
          const info=tx(mk("div",{position:"absolute",inset:"0",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"22px",color:selecting?LIME:"rgba(255,255,255,.9)",textShadow:"0 0 5px #000",pointerEvents:"none"}),selecting?"＋":"ⓘ");
          thumbWrap.append(v,info); if(it.favorite)thumbWrap.appendChild(_favBadge());
          const name=tx(mk("div",{fontSize:"9px",color:C.muted,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}),it.filename);
          cell.append(thumbWrap,name);
          cell.title=selecting?"Click to pick for upscaling":"Click to open details";
          cell.onclick=()=>{ if(_galSelectCb){ const cb=_galSelectCb; _galSelectCb=null; galModal.style.display="none"; cb(it); } else { _lbShow(it,i,list); } };
          gmGrid.appendChild(cell);
        });
      };
      const openGalleryModal=(selectCb)=>{ _galSelectCb=selectCb||null; if(selectCb)_favOnly=false; _styleGmFav(); galModal.style.display="flex"; renderGalleryModal(); _loadGallery(); };
      const _galAdd=(it)=>{ if(!it||!it.filename)return; const k=(x)=>x.filename+"|"+(x.subfolder||""); const key=k(it);
        for(let i=_galItems.length-1;i>=0;i--) if(k(_galItems[i])===key) _galItems.splice(i,1);
        _galItems.unshift(it); renderGallery(); };
      const _loadGallery=()=>api.fetchApi("/minimaxh3/outputs").then(r=>r.json()).then(d=>{
        _galItems.length=0; (d.videos||[]).forEach(v=>_galItems.push(v)); renderGallery();
        // Reliable settings-save: the `executed` event that carries the finished clip is flaky in
        // this frontend (completion is really detected by the queue poll → _finishActive → here),
        // so if a just-finished generation left its settings snapshot unsaved, attach it to the
        // newest clip now. Guarded by !S.generating so a manual refresh mid-run can't mis-tag the
        // previous clip; _activeShowVideo clears _pendingMeta first when its event DID fire.
        if(S._pendingMeta && !S.generating && _galItems.length){
          const it=_galItems[0], meta=S._pendingMeta; S._pendingMeta=null;
          _galMetaCache[it.filename]=meta; it.has_meta=true; renderGallery();
          api.fetchApi("/minimaxh3/save_meta",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({filename:it.filename,subfolder:it.subfolder||"",meta})}).catch(e=>console.warn("[MMH3] save_meta:",e));
        }
      }).catch(()=>{});
      _activeRefreshGallery=_loadGallery;   // completion handlers pull the newest render in

      // ── lightbox behaviour ────────────────────────────────────────────────
      let _lbList=[], _lbIdx=0, _lbItem=null, _lbFavOn=false;
      const _lbIsOpen=()=>lb.style.display==="flex";
      const _lbClose=()=>{ try{lbVid.pause();}catch(_e){} lb.style.display="none"; _lbItem=null; };
      lbCloseBtn.onclick=_lbClose;
      const _setLbFav=(on)=>{ _lbFavOn=on; lbFav.style.color=on?LIME:"rgba(240,255,65,.4)"; lbFav.style.borderColor=on?LIME:"rgba(240,255,65,.25)"; lbFav.style.background=on?"rgba(240,255,65,.15)":"rgba(20,20,30,.85)";
        lb.style.background=on?"linear-gradient(180deg,rgba(240,255,65,.12) 0%,rgba(240,255,65,.03) 42%,#0a0a0a 100%)":"#0a0a0a"; };
      const _renderMeta=(m)=>{
        lbPrompt.textContent=m.prompt||"(no prompt saved)";
        lbChips.innerHTML=""; lbRefs.innerHTML="";
        const modeLbl=({t2v:"T2V",i2v:"I2V",r2v:"R2V",upscale:"Upscale"})[m.mode]||(m.mode||"").toUpperCase();
        lbChips.appendChild(_lbChip("Mode",modeLbl));
        if(m.mode==="upscale"){
          lbChips.appendChild(_lbChip("Engine",({model:"ESRGAN",seedvr2:"SeedVR2",flashvsr:"FlashVSR",rtxvsr:"RTX VSR"})[m.upEngine]||m.upEngine));
          if(m.upScale)lbChips.appendChild(_lbChip("Target",String(m.upScale)+(m.upEngine==="seedvr2"?"p":"×")));
          if(m.upModel)lbChips.appendChild(_lbChip("Model",String(m.upModel).split("/").pop().replace(/\.(safetensors|pth|gguf)$/i,"")));
          if(m.sourceName)lbChips.appendChild(_lbChip("Source",String(m.sourceName)));
          lbRefs.style.display="none"; return;
        }
        if(m.w&&m.h)lbChips.appendChild(_lbChip("Size",m.w+"×"+m.h));
        if(m.duration!=null)lbChips.appendChild(_lbChip("Length",(+m.duration).toFixed((+m.duration)%1?1:0)+"s"));
        if(m.seed!=null)lbChips.appendChild(_lbChip("Seed",m.seed));
        const steps=m.turboOn?(m.turboSteps||6):(m.steps||20);
        lbChips.appendChild(_lbChip("Steps",steps+(m.turboOn?" ⚡":"")));
        lbChips.appendChild(_lbChip("Sampler",m.turboOn?"Turbo":(m.sampler||"—")));
        if(m.scheduler)lbChips.appendChild(_lbChip("Sched",m.scheduler));
        if(m.turboOn&&m.turboLora)lbChips.appendChild(_lbTag("Turbo: "+String(m.turboLora).split("/").pop().replace(/\.safetensors$/i,""),"#ff8fbf"));
        if(m.sigmaShiftOn)lbChips.appendChild(_lbTag("σ "+(m.shiftVideo??12)+"/"+(m.shiftAudio??3)));
        if(m.sageAttn)lbChips.appendChild(_lbTag("Sage","#8fd8ff"));
        if(m.solAttn)lbChips.appendChild(_lbTag("Sol-Attn","#b9a8ff"));
        if(m.fastFp8)lbChips.appendChild(_lbTag("FP8-fast","#8fd8ff"));
        if(m.cacheEngine&&m.cacheEngine!=="off")lbChips.appendChild(_lbTag("Cache: "+(({teacache:"TeaCache",spectrum:"Spectrum",fbc:"FBC"})[m.cacheEngine]||m.cacheEngine),"#7fd0a0"));
        if(m.twoPass)lbChips.appendChild(_lbTag("2-pass HD","#7fd0a0"));
        // reference thumbnails (input files that fed the generation)
        let hasRef=false;
        if(m.mode==="i2v"){
          if(m.firstFrame){ lbRefs.appendChild(_lbRefThumb(m.firstFrame,"image","First")); hasRef=true; }
          if(m.lastFrame){ lbRefs.appendChild(_lbRefThumb(m.lastFrame,"image","Last")); hasRef=true; }
        } else if(m.mode==="r2v"){
          (m.refImages||[]).forEach((n,i)=>{ if(n){ lbRefs.appendChild(_lbRefThumb(n,"image","P"+(i+1))); hasRef=true; } });
          (m.refVideos||[]).forEach((v,i)=>{ if(v&&v.file){ lbRefs.appendChild(_lbRefThumb(v.file,"video","V"+(i+1))); hasRef=true; } });
          (m.refAudios||[]).forEach((a,i)=>{ if(a){ lbRefs.appendChild(_lbTag("🔊 Audio "+(i+1))); hasRef=true; } });
        }
        lbRefs.style.display=hasRef?"flex":"none";
      };
      const _lbShow=async(it,idx,list)=>{
        _lbItem=it; if(list)_lbList=list; _lbIdx=(idx==null?_lbList.indexOf(it):idx); if(_lbIdx<0)_lbIdx=0;
        tx(lbName,it.filename);
        try{ lbVid.pause(); }catch(_e){}
        lbVid.src=_viewUrl(it); try{ lbVid.load(); lbVid.play().catch(()=>{}); }catch(_e){}
        lb.style.display="flex";
        const total=_lbList.length||1;
        tx(lbCounter,(_lbIdx+1)+" / "+total);
        lbPrev.style.opacity=_lbIdx>0?"1":".25"; lbNext.style.opacity=_lbIdx<total-1?"1":".25";
        lbChips.innerHTML=""; lbRefs.innerHTML=""; lbRefs.style.display="none"; lbPrompt.textContent="Loading settings…";
        lbMeta.style.display="flex"; lbRestore.style.display="none"; lbDel._armed=null; lbDel.textContent="🗑 Delete";
        _setLbFav(it.favorite===true);
        const meta=await _fetchMeta(it);
        if(_lbItem!==it) return;   // user navigated away while the fetch was in flight
        _setLbFav(it.favorite===true||(meta&&meta.favorite===true));
        if(!meta){ lbPrompt.textContent="⚠ No saved settings for this clip — it was rendered before the gallery upgrade (or imported). Newer generations store their full settings here."; lbChips.innerHTML=""; return; }
        _renderMeta(meta);
        lbRestore.style.display="flex"; lbRestore.onclick=()=>_applyMeta(meta);
      };
      const _lbNav=(delta)=>{ if(!_lbList.length)return; const ni=Math.max(0,Math.min(_lbList.length-1,_lbIdx+delta)); if(ni===_lbIdx)return; _lbShow(_lbList[ni],ni,_lbList); };
      lbPrev.onclick=()=>_lbNav(-1); lbNext.onclick=()=>_lbNav(1);
      lbFav.onclick=async()=>{ const it=_lbItem; if(!it)return; const nf=!_lbFavOn;
        try{ const r=await api.fetchApi("/minimaxh3/update_meta",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({filename:it.filename,subfolder:it.subfolder||"",patch:{favorite:nf}})}); const d=await r.json();
          if(d.ok){ it.favorite=nf; if(_galMetaCache[it.filename])_galMetaCache[it.filename].favorite=nf; _setLbFav(nf); renderGallery(); if(galModal.style.display!=="none")renderGalleryModal(); }
        }catch(e){ console.warn("[MMH3] fav:",e); } };
      lbFolder.onclick=()=>{ const it=_lbItem; if(!it)return; api.fetchApi("/minimaxh3/open_folder",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({filename:it.filename,subfolder:it.subfolder||""})}).catch(()=>{}); };
      lbDel.onclick=async()=>{ const it=_lbItem; if(!it)return;
        if(lbDel._armed!==it){ lbDel._armed=it; lbDel.textContent="Click again to delete"; setTimeout(()=>{ if(lbDel._armed===it){ lbDel._armed=null; lbDel.textContent="🗑 Delete"; } },2600); return; }
        lbDel._armed=null; lbDel.textContent="🗑 Delete";
        try{ const r=await api.fetchApi("/minimaxh3/delete",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({filename:it.filename,subfolder:it.subfolder||""})}); const d=await r.json();
          if(d.ok){ const gi=_galItems.findIndex(x=>x.filename===it.filename); if(gi>=0)_galItems.splice(gi,1); delete _galMetaCache[it.filename];
            const li=_lbList.indexOf(it); if(li>=0)_lbList.splice(li,1);
            renderGallery(); if(galModal.style.display!=="none")renderGalleryModal();
            if(!_lbList.length)_lbClose(); else { const ni=Math.min(_lbIdx,_lbList.length-1); _lbShow(_lbList[ni],ni,_lbList); }
          }
        }catch(e){ console.warn("[MMH3] delete:",e); } };
      // lightbox keys (capture so ComfyUI's canvas doesn't swallow them)
      document.addEventListener("keydown",(e)=>{
        if(!_lbIsOpen())return;
        if(e.key==="Escape"){ e.preventDefault(); e.stopPropagation(); _lbClose(); }
        else if(e.key==="ArrowLeft"){ e.preventDefault(); e.stopPropagation(); _lbNav(-1); }
        else if(e.key==="ArrowRight"){ e.preventDefault(); e.stopPropagation(); _lbNav(1); }
        else if(e.key==="f"||e.key==="F"){ e.preventDefault(); e.stopPropagation(); try{ if(!document.fullscreenElement)lbVid.requestFullscreen&&lbVid.requestFullscreen().catch(()=>{}); else document.exitFullscreen().catch(()=>{}); }catch(_e){} }
      },{capture:true});

      // ── "Load settings into UI" — restore a saved generation's settings ───────
      const _applyMeta=(m)=>{
        _lbClose(); _galSelectCb=null; galModal.style.display="none";
        try{
          if(m.mode==="upscale"){
            setMode("upscale");
            if(m.upEngine)setUpEngine(m.upEngine);
            if(m.upEngine==="model"){
              if(m.upScale&&[2,3,4].indexOf(+m.upScale)>=0){ S.upscaleScale=+m.upScale; _upScalePills.forEach((pp,i)=>pp._set([2,3,4][i]===+m.upScale)); }
              if(m.upModel){ S.upscaleModel=m.upModel; try{upModDD.set(m.upModel);}catch(_e){} }
            }
            persist(); return;
          }
          const mode=(m.mode==="i2v"||m.mode==="r2v")?m.mode:"t2v";
          setMode(mode);
          if(m.prompt!=null){ S.prompt=m.prompt; posTA.value=m.prompt; }
          if(m.aspect&&ASPECT_KEYS.indexOf(m.aspect)>=0){ S.aspect=m.aspect; aspectSel.set(m.aspect); }
          if(m.megapixels!=null){ S.megapixels=m.megapixels; mpVal.set(m.megapixels); mpSlider.set(m.megapixels); }
          updateRes();
          if(m.duration!=null){ S.duration=m.duration; durVal.set(m.duration); durSlider.set(m.duration); updateDur(); }
          // sampler/scheduler/steps AFTER setMode (setMode nudges the r2v scheduler default)
          if(m.steps!=null){ S.steps=m.steps; stepsIn.set(m.steps); }
          if(m.sampler){ S.sampler=m.sampler; samplerDD.set(m.sampler); }
          if(m.scheduler){ S.scheduler=m.scheduler; schedDD.set(m.scheduler); }
          // seed — restore the exact seed used + turn randomize OFF so it reproduces
          if(m.seed!=null){ S.seed=m.seed; S.randomizeSeed=false; seedIn.set(m.seed); seedTgl._set(false); seedIn._inp.style.opacity="1"; }
          // sigma shift
          S.sigmaShiftOn=!!m.sigmaShiftOn; shiftTgl._set(S.sigmaShiftOn); shiftRows.style.display=S.sigmaShiftOn?"flex":"none";
          if(m.shiftVideo!=null){ S.shiftVideo=m.shiftVideo; shVid.set(m.shiftVideo); }
          if(m.shiftAudio!=null){ S.shiftAudio=m.shiftAudio; shAud.set(m.shiftAudio); }
          // turbo
          S.turboOn=!!m.turboOn; if(m.turboSteps!=null){ S.turboSteps=m.turboSteps; turboStepsIn.set(m.turboSteps); }
          if(m.turboLora){ S.turboLora=m.turboLora; try{turboLoraDD.set(m.turboLora);}catch(_e){} }
          if(m.turboStrength!=null)S.turboStrength=m.turboStrength;
          // speed toggles (updateSpeedNotes re-syncs the switches + turbo rows)
          S.sageAttn=!!m.sageAttn; S.solAttn=!!m.solAttn; S.fastFp8=!!m.fastFp8;
          updateSpeedNotes();
          if(m.cacheEngine){ setCacheEngine(m.cacheEngine); }
          // two-pass HD
          if(m.twoPass!=null){ S.twoPass=!!m.twoPass; tpTgl._set(S.twoPass); tpBody.style.display=S.twoPass?"block":"none"; }
          if(m.stage1Mp!=null){ S.stage1Mp=m.stage1Mp; tpS1.set(m.stage1Mp); }
          if(m.stage2Mp!=null){ S.stage2Mp=m.stage2Mp; tpS2.set(m.stage2Mp); }
          if(m.stage2Steps!=null){ S.stage2Steps=m.stage2Steps; tpSteps.set(m.stage2Steps); }
          if(m.stage2Denoise!=null){ S.stage2Denoise=m.stage2Denoise; tpDen.set(m.stage2Denoise); }
          updateTwoPassUI();
          // reference inputs
          if(mode==="i2v"){
            S.firstFrame=m.firstFrame||null; S.useLastFrame=!!m.useLastFrame; S.lastFrame=(m.useLastFrame?m.lastFrame:null)||null;
            if(S.firstFrame)firstSlot.setName(S.firstFrame); else firstSlot.clear();
            flfTgl._set(S.useLastFrame); lastWrap.style.display=S.useLastFrame?"block":"none";
            if(S.lastFrame)lastSlot.setName(S.lastFrame); else lastSlot.clear();
          } else if(mode==="r2v"){
            S.allow9=!!m.allow9; allow9Tgl._set(S.allow9);
            S.refImages=(m.refImages||[]).slice(); while(S.refImages.length<MAX_REF_IMAGES)S.refImages.push(null);
            S.refVideos=(m.refVideos||[]).map(v=>({file:(v&&v.file)||null,useAudio:v?!!v.useAudio:true,start:(v&&+v.start)||0,end:(v&&+v.end)||0})); while(S.refVideos.length<MAX_REF_VIDEOS)S.refVideos.push({file:null,useAudio:true,start:0,end:0});
            S.refAudios=(m.refAudios||[]).slice(); while(S.refAudios.length<MAX_REF_AUDIOS)S.refAudios.push(null);
            S.refAudioTrim=(m.refAudioTrim||[]).map(t=>({start:(t&&+t.start)||0,end:(t&&+t.end)||0})); while(S.refAudioTrim.length<MAX_REF_AUDIOS)S.refAudioTrim.push({start:0,end:0});
            if(m.refImageSize){ S.refImageSize=m.refImageSize; try{risSel.set(m.refImageSize);}catch(_e){} }
            renderRefImages(); warnRefImages(); renderRefVideos(); renderRefAudios(); rebuildTagRow();
          }
          persist();
        }catch(err){ console.warn("[MMH3] applyMeta:",err); }
      };

      // ── reactive: mode switch ─────────────────────────────────────────────
      // generation-only left sections — hidden in Upscale mode (which reuses the shared
      // preview / progress / gallery on the right but has its own inputs).
      const _genSections=[promptHdr,modeHint,posTA,vidWrap,sampWrap,advWrap,modWrap,dl];
      function setMode(m){
        S.mode=m;
        pillT2V._set(m==="t2v"); pillI2V._set(m==="i2v"); pillR2V._set(m==="r2v"); pillUp._set(m==="upscale");
        const isUp=(m==="upscale");
        _genSections.forEach(el=>{ if(el) el.style.display=isUp?"none":""; });
        ivPanel.style.display=(m==="i2v")?"block":"none";
        r2vPanel.style.display=(m==="r2v")?"block":"none";
        upPanel.style.display=isUp?"block":"none";
        tagRow.style.display=(m==="r2v")?"flex":"none";
        genBtn.textContent=isUp?"▶ Upscale video":"▶ Generate";
        if(isUp){ setUpEngine(S.upscaleEngine); refreshUpSource(); _loadModels(); updateModStatus(); updateTwoPassUI(); persist(); return; }
        // scheduler default per mode (beta for reference-heavy, simple otherwise)
        if(m==="r2v"&&S.scheduler==="simple"){ S.scheduler="beta"; schedDD.set("beta"); }
        else if(m!=="r2v"&&S.scheduler==="beta"){ S.scheduler="simple"; schedDD.set("simple"); }
        schedHint.textContent=(m==="r2v")?"R2V works best with beta or normal (simple can wash out reference-heavy prompts)."
                                         :"simple is the tuned default for T2V / I2V.";
        modeHint.textContent =(m==="t2v")?"Text → video + audio. Describe the shots, camera and sound; the model writes the picture and the soundtrack together."
                             :(m==="i2v")?"Animate a still (first frame), or bridge from a first to a last frame. Add the frames below."
                                         :"Reference-driven. Feed images / video / audio below, tag them in the prompt, and describe the target scene.";
        if(m==="r2v"){ renderRefImages(); warnRefImages(); renderRefVideos(); renderRefAudios(); rebuildTagRow(); }
        refreshTemplateDD(); updateModStatus(); updateSpeedNotes(); updateTwoPassUI(); persist();
      }

      // ── model scan ────────────────────────────────────────────────────────
      const _norm=(s)=>(s||"").replace(/\\/g,"/").toLowerCase();
      const pick=(list,saved,kws,excl)=>{
        if(!list||!list.length) return "";
        let r=list.find(i=>_norm(i)===_norm(saved)); if(r)return r;
        if(saved){ const b=_norm(saved).split("/").pop(); r=list.find(i=>_norm(i).split("/").pop()===b); if(r)return r; }
        const ks=(kws||[]).map(k=>k.toLowerCase());
        const cand=list.filter(f=>{ const n=_norm(f); return ks.every(k=>n.includes(k)) && (!excl||!excl.some(e=>n.includes(e))); });
        if(cand.length) return cand[0];
        return saved||"";
      };
      const _loadModels=()=>api.fetchApi("/minimaxh3/models").then(r=>r.json()).then(d=>{
        const diff=(d.diffusion_models||[]).filter(f=>f!=="none");
        const te=(d.text_encoders||[]).filter(f=>f!=="none");
        const vaes=(d.vaes||[]).filter(f=>f!=="none");
        const setDD=(f,list,val)=>{ const opts=["none",...list]; f._dd.updateItems(opts); f._dd.set(val||"none"); };
        S.unetFl=pick(diff,S.unetFl,["fl2va"]) || pick(diff,S.unetFl,["minimax","h3"],["ref2va"]);
        S.unetRef=pick(diff,S.unetRef,["ref2va"]);
        S.textEncoder=pick(te,S.textEncoder,["minimax"]) || pick(te,S.textEncoder,["qwen3vl"]);
        S.videoVae=pick(vaes,S.videoVae,["h3","video"]) || pick(vaes,S.videoVae,["minimax","video"]);
        S.audioVae=pick(vaes,S.audioVae,["h3","audio"]) || pick(vaes,S.audioVae,["minimax","audio"]);
        setDD(mFl,diff,S.unetFl); setDD(mRef,diff,S.unetRef); setDD(mTE,te,S.textEncoder);
        setDD(mVVae,vaes,S.videoVae); setDD(mAVae,vaes,S.audioVae);
        // upscale models (Upscale tab)
        const ups=(d.upscale_models||[]).filter(f=>f!=="none");
        S.upscaleModel=pick(ups,S.upscaleModel,[]) || (ups[0]||"");
        upModDD.updateItems(["none",...ups]); upModDD.set(S.upscaleModel||"none");
        // turbo LoRA auto-detect — H3-ONLY (must be minimax/h3 + turbo). The bare "turbo" keyword
        // used to match krea2_*_turbo LoRAs in the same folder, applying a Krea2 LoRA to the H3 model.
        // Prefer the newer v4-step600 checkpoint (EMA first): better micro-detail, no v1 "plastic" look.
        const loras=(d.loras||[]).filter(f=>f!=="none");
        const h3turbos=loras.filter(f=>/turbo/i.test(f) && /(minimax|h3)/i.test(f) && !/krea2/i.test(f));
        const _v4=h3turbos.find(f=>/v4[_-]?step600.*ema/i.test(f)) || h3turbos.find(f=>/v4[_-]?step600/i.test(f)) || h3turbos.find(f=>/\bv4\b/i.test(f));
        const _savedH3=h3turbos.find(f=>_norm(f)===_norm(S.turboLora));
        // respect a valid saved pick (from the selector); else default to the newer v4; else first H3 turbo.
        S.turboLora = _savedH3 || _v4 || h3turbos[0] || "";
        // distilled-turbo preset LoRAs (lightx2v) — auto-detected by name, wired by the preset branch
        _lxFl2vLora = loras.find(f=>/fl2v.*turbo/i.test(f) && /(minimax|h3)/i.test(f)) || "";
        _lxR2vLora  = loras.find(f=>/ref2v.*turbo/i.test(f) && /(minimax|h3)/i.test(f)) || "";
        try{ refreshPreset(); }catch(_e){}
        // populate the Turbo LoRA selector (H3 turbos; fall back to all loras if detection finds none)
        const _turboOpts = h3turbos.length ? h3turbos : (loras.length ? loras : ["(none found)"]);
        try{ turboLoraDD.updateItems(_turboOpts); turboLoraDD.set(S.turboLora||"(none found)"); }catch(_e){}
        // Style LoRA selector — H3 loras that aren't turbo/krea2. Recommend one by default
        // (respect a valid saved pick; else the first available), but always let the user change it.
        const _styleOpts = loras.filter(f=>!h3turbos.includes(f) && !/krea2/i.test(f));
        const _styleList = _styleOpts.length ? _styleOpts : ["(none found)"];
        if((!S.styleLora || !_styleOpts.includes(S.styleLora)) && _styleOpts.length){ S.styleLora=_styleOpts[0]; persist(); }
        try{ styleLoraDD.updateItems(_styleList); styleLoraDD.set(S.styleLora||"(none found)"); }catch(_e){}
        persist(); updateModStatus(); updateSpeedNotes();
      }).catch(e=>console.warn("[MMH3] models:",e));

      // ── templates ─────────────────────────────────────────────────────────
      let _tmplT2V=[], _tmplR2V=[];
      const applyTemplate=(name)=>{
        const pool=S.mode==="r2v"?_tmplR2V:_tmplT2V;
        const t=pool.find(x=>x.name===name); if(!t)return;
        S.prompt=t.prompt; posTA.value=t.prompt; persist(); tmplSel.set("Load example…");
      };
      const _loadTemplates=()=>api.fetchApi("/minimaxh3/config").then(r=>r.json()).then(d=>{
        _tmplT2V=d.prompt_templates||[]; _tmplR2V=d.r2v_prompt_templates||[];
        refreshTemplateDD();
      }).catch(()=>{});
      const refreshTemplateDD=()=>{
        const pool=S.mode==="r2v"?_tmplR2V:_tmplT2V;
        tmplSel.updateItems(["Load example…",...pool.map(t=>t.name)]); tmplSel.set("Load example…");
      };

      // ── generate ──────────────────────────────────────────────────────────
      let _genStart=0, _progTimer=null, _lastPct=0, _lastVal=null, _lastMax=null;
      // Bulletproof completion watch: poll /queue while running. The moment our prompt
      // leaves the running+pending queue it is done — this cannot be defeated by event
      // timing quirks (the reason the button used to stay stuck on "generating").
      let _completePoll=null, _sawQueued=false;
      const stopCompletionWatch=()=>{ if(_completePoll){clearInterval(_completePoll);_completePoll=null;} _sawQueued=false; };
      const startCompletionWatch=()=>{
        stopCompletionWatch(); _sawQueued=false;
        _completePoll=setInterval(async()=>{
          if(!_activeRunning||!_activePromptId){ stopCompletionWatch(); return; }
          try{
            const r=await api.fetchApi("/queue"); const q=await r.json();
            const inQ=[...(q.queue_running||[]),...(q.queue_pending||[])]
              .some(e=>(Array.isArray(e)?e[1]:(e&&e.prompt_id))===_activePromptId);
            if(inQ){ _sawQueued=true; }
            else if(_sawQueued){ _finishActive(); }   // was queued, now gone → finished
          }catch(e){ /* transient — keep polling */ }
        }, 1500);
      };
      const _elapsed=()=> _genStart? Math.round((Date.now()-_genStart)/1000)+"s":"";
      const renderProg=()=>{ progWrap.style.display="block"; progLabel.style.display="block"; progBar.style.width=Math.round(_lastPct*100)+"%";
        progLabel.textContent=(_lastPct>0?`⏳ generating — ${Math.round(_lastPct*100)}%`:"⏳ starting… (first run loads ~48 GB of weights)")+((_lastVal!=null&&_lastMax)?` · step ${_lastVal}/${_lastMax}`:"")+(_genStart?` · ${_elapsed()}`:""); };
      const reset=()=>{ S.generating=false; genBtn.disabled=false; genBtn.style.opacity="1"; genBtn.textContent=S.mode==="upscale"?"▶ Upscale video":"▶ Generate";
        progWrap.style.display="none"; progBar.style.width="0%"; progLabel.style.display="none";
        if(_progTimer){clearInterval(_progTimer);_progTimer=null;} stopCompletionWatch(); _genStart=0; _lastPct=0; _lastVal=null; _lastMax=null; };
      _activeReset=reset;
      _activeSetProgress=(f,val,max)=>{ _lastPct=f; if(val!=null){_lastVal=val;_lastMax=max;} renderProg(); };
      _activeShowError=(msg)=>{ errBox.style.display="block"; errBox.style.color="#ff6b6b"; errBox.style.borderColor="rgba(255,80,80,.3)"; errBox.style.background="rgba(255,80,80,.08)"; errBox.textContent=msg; };
      // non-fatal amber heads-up (generation still proceeds)
      const _showNotice=(msg)=>{ errBox.style.display="block"; errBox.style.color="#ffb84d"; errBox.style.borderColor="#cc7a00"; errBox.style.background="rgba(255,150,0,.08)"; errBox.textContent=msg; };
      const _showVideoUrl=(url,filename)=>{ videoEl.src=url; videoEl.style.display="block"; placeholder.style.display="none"; fsBtn.style.display="flex"; _fsFilename=filename||""; if(videoEl.play)videoEl.play().catch(()=>{}); };
      _activeShowVideo=(item)=>{
        if(/\.(mp4|webm|mov|mkv)$/i.test(item.filename)){ _showVideoUrl(_viewUrl(item)+"&rand="+Math.random(), item.filename); _galAdd(item);
          // persist the settings that produced this clip so the gallery detail view can
          // show them and "Load settings into UI" can reproduce the result.
          if(S._pendingMeta){ const meta=S._pendingMeta; S._pendingMeta=null; _galMetaCache[item.filename]=meta; item.has_meta=true;
            api.fetchApi("/minimaxh3/save_meta",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({filename:item.filename,subfolder:item.subfolder||"",meta})}).catch(e=>console.warn("[MMH3] save_meta:",e));
          }
        }
        else { videoEl.style.display="none"; placeholder.style.display="block"; placeholder.textContent="Saved: "+item.filename; }
      };

      const _startRun=()=>{
        S.generating=true; genBtn.disabled=true; genBtn.style.opacity=".6"; genBtn.textContent="… working"; errBox.style.display="none";
        _genStart=Date.now(); _lastPct=0; _lastVal=null; _lastMax=null; renderProg();
        if(_progTimer)clearInterval(_progTimer); _progTimer=setInterval(()=>{ if(S.generating)renderProg(); },1000);
      };
      const _submit=async(prompt)=>{
        try{
          const r=await api.fetchApi("/prompt",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});
          if(!r.ok){ const t=await r.text(); throw new Error(t); }
          const d=await r.json(); _activePromptId=d.prompt_id||null; _activeRunning=true; startCompletionWatch();
        }catch(e){ _activeShowError("ComfyUI rejected the graph:\n"+fmtErr(e)); _activeRunning=false; reset(); }
      };

      // ── UPSCALE: enlarge a finished video (ESRGAN model / SeedVR2 / FlashVSR) + keep audio ──
      const upscaleGenerate=async()=>{
        if(S.generating)return; errBox.style.display="none";
        const eng=S.upscaleEngine, svr=eng==="seedvr2", fvsr=eng==="flashvsr", rtx=eng==="rtxvsr";
        const src=S.upscaleSource;
        if(!src||!src.filename){ _activeShowError("Pick a source video first — choose one from the gallery or drop a file in the Upscale panel."); return; }
        if(eng==="model" && !S.upscaleModel){ _activeShowError("Select an upscale model (models/upscale_models). Put one there — e.g. 4x_foolhardy_Remacri.pth — and hit Rescan."); return; }
        if(svr && !_svrAvailable){ _activeShowError("SeedVR2 isn't detected yet. It's installed — RESTART ComfyUI so its nodes register (first run auto-downloads the model), or switch the engine to Model."); return; }
        if(fvsr && !_fvsrAvailable){ _activeShowError("FlashVSR isn't detected yet. It's installed — RESTART ComfyUI so its nodes register (first run auto-downloads its models), or switch the engine."); return; }
        if(rtx && !_rtxAvailable){ _activeShowError("RTX VSR isn't detected. Install Comfy-Org/Nvidia_RTX_Nodes_ComfyUI into custom_nodes + RESTART ComfyUI (NVIDIA RTX GPU only), or switch the engine."); return; }
        // snapshot upscale settings so the finished clip carries them in the gallery
        S._pendingMeta={v:1,mode:"upscale",upEngine:eng,
          upScale: svr?(+S.svrRes||1080) : fvsr?(+S.fvsrScale||2) : rtx?(+S.rtxScale||2) : (+S.upscaleScale||2),
          upModel: eng==="model"?S.upscaleModel : svr?S.svrDitModel : fvsr?S.fvsrVae : rtx?("RTX "+(S.rtxQuality||"ULTRA")) : "",
          sourceName: src.filename};
        _startRun();
        // stage the source into the input dir so LoadVideo can read it (unless it's already an upload)
        let inName=src._raw||src.filename;
        if(!src._input){
          try{
            const r=await api.fetchApi("/minimaxh3/stage",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({filename:src.filename,subfolder:src.subfolder||""})});
            const d=await r.json(); if(!d.ok) throw new Error(d.error||"stage failed"); inName=d.name;
          }catch(e){ _activeShowError("Couldn't stage the source video for upscaling:\n"+fmtErr(e)+"\n(Restart ComfyUI if the /minimaxh3/stage route is missing.)"); reset(); return; }
        }
        let g;
        if(fvsr){
          // FlashVSR — fast diffusion VSR. frames -> FlashVSRNode -> re-mux original audio. Models auto-download.
          const vae=S.fvsrVae||"Wan2.1";
          g={
            "U:load":{class_type:"LoadVideo",inputs:{file:inName},_meta:{title:"Load source video"}},
            "U:comp":{class_type:"GetVideoComponents",inputs:{video:["U:load",0]},_meta:{title:"Split frames + audio"}},
            "U:fvsr":{class_type:"FlashVSRNode",inputs:{frames:["U:comp",0],model:"FlashVSR-v1.1",mode:S.fvsrMode||"tiny",vae_model:vae,scale:+S.fvsrScale||2,tiled_vae:true,tiled_dit:true,unload_dit:true,seed:Math.floor(Math.random()*1e9),frame_chunk_size:33,attention_mode:"sparse_sage_attention",enable_debug:false,keep_models_on_cpu:false,resize_factor:1.0},_meta:{title:"FlashVSR upscale"}},
            "U:cvid":{class_type:"CreateVideo",inputs:{images:["U:fvsr",0],audio:["U:comp",1],fps:["U:comp",2],bit_depth:8},_meta:{title:"Re-mux with original audio"}},
            "U:save":{class_type:"SaveVideo",inputs:{video:["U:cvid",0],filename_prefix:"ComfyUI-MiniMaxH3-OneNode/MiniMax_H3_upscaled",format:"auto",codec:"auto"},_meta:{title:"Save upscaled video"}},
          };
          await _submit(g); return;
        }
        if(rtx){
          // RTX Video Super Resolution — NVIDIA hardware upscaler (per-frame), then re-mux the original audio.
          g={
            "U:load":{class_type:"LoadVideo",inputs:{file:inName},_meta:{title:"Load source video"}},
            "U:comp":{class_type:"GetVideoComponents",inputs:{video:["U:load",0]},_meta:{title:"Split frames + audio"}},
            // resize_type is a v3 DynamicCombo: the sub-input serializes as the dotted key
            // "resize_type.scale" (same pattern as H3's ref_images.ref_image_N), NOT a flat "scale".
            "U:rtx":{class_type:"RTXVideoSuperResolution",inputs:{images:["U:comp",0],resize_type:"scale by multiplier","resize_type.scale":+S.rtxScale||2,quality:S.rtxQuality||"ULTRA"},_meta:{title:"RTX Video Super Resolution"}},
            "U:cvid":{class_type:"CreateVideo",inputs:{images:["U:rtx",0],audio:["U:comp",1],fps:["U:comp",2],bit_depth:8},_meta:{title:"Re-mux with original audio"}},
            "U:save":{class_type:"SaveVideo",inputs:{video:["U:cvid",0],filename_prefix:"ComfyUI-MiniMaxH3-OneNode/MiniMax_H3_upscaled",format:"auto",codec:"auto"},_meta:{title:"Save upscaled video"}},
          };
          await _submit(g); return;
        }
        if(svr){
          // SeedVR2 diffusion upscaler (models auto-download to models/SEEDVR2 on first run)
          g={
            "U:load":{class_type:"LoadVideo",inputs:{file:inName},_meta:{title:"Load source video"}},
            "U:comp":{class_type:"GetVideoComponents",inputs:{video:["U:load",0]},_meta:{title:"Split frames + audio"}},
            "U:dit":{class_type:"SeedVR2LoadDiTModel",inputs:{model:S.svrDitModel||"seedvr2_ema_3b_fp8_e4m3fn.safetensors",device:"cuda:0",blocks_to_swap:+S.svrBlockSwap||0,swap_io_components:false,offload_device:((+S.svrBlockSwap||0)>0?"cpu":"none"),cache_model:((+S.svrBlockSwap||0)>0),attention_mode:_sageAvailable?"sageattn_2":"sdpa"},_meta:{title:"SeedVR2 DiT (3B)"}},
            "U:vae":{class_type:"SeedVR2LoadVAEModel",inputs:{model:"ema_vae_fp16.safetensors",device:"cuda:0",encode_tiled:false,decode_tiled:true,decode_tile_size:1024,decode_tile_overlap:128,offload_device:"cpu",cache_model:false},_meta:{title:"SeedVR2 VAE"}},
            "U:svr":{class_type:"SeedVR2VideoUpscaler",inputs:{image:["U:comp",0],dit:["U:dit",0],vae:["U:vae",0],seed:Math.floor(Math.random()*1e9),resolution:+S.svrRes||1080,max_resolution:0,batch_size:Math.max(5,+S.svrBatch||5),uniform_batch_size:!!S.svrCompile,temporal_overlap:0,prepend_frames:0,color_correction:"wavelet",input_noise_scale:0.0,latent_noise_scale:0.0,enable_debug:false},_meta:{title:"SeedVR2 upscale"}},
            "U:cvid":{class_type:"CreateVideo",inputs:{images:["U:svr",0],audio:["U:comp",1],fps:["U:comp",2],bit_depth:8},_meta:{title:"Re-mux with original audio"}},
            "U:save":{class_type:"SaveVideo",inputs:{video:["U:cvid",0],filename_prefix:"ComfyUI-MiniMaxH3-OneNode/MiniMax_H3_upscaled",format:"auto",codec:"auto"},_meta:{title:"Save upscaled video"}},
          };
          // torch.compile — big speedup for the many diffusion batches in a long clip (first run warms up).
          // uniform_batch_size (above) pads the ragged last batch so compile doesn't re-trace and stall.
          if(S.svrCompile){
            g["U:tc"]={class_type:"SeedVR2TorchCompileSettings",inputs:{backend:"inductor",mode:"default",fullgraph:false,dynamic:false,dynamo_cache_size_limit:64,dynamo_recompile_limit:128},_meta:{title:"torch.compile settings"}};
            g["U:dit"].inputs.torch_compile_args=["U:tc",0];
          }
        } else {
          // Memory-safe: shrink frames to (target/native) BEFORE the model so it outputs the
          // target directly, instead of always producing a full-native (4×) intermediate for
          // every frame (that intermediate is what OOMs a whole clip at once). preScale=1 for
          // a native-scale target is a harmless no-op.
          const nativeM=(String(S.upscaleModel).match(/(\d+)\s*x/i)||[])[1]; const native=nativeM?+nativeM:4;
          const preScale=Math.min(1,(+S.upscaleScale||2)/native);
          g={
            "U:load":{class_type:"LoadVideo",inputs:{file:inName},_meta:{title:"Load source video"}},
            "U:comp":{class_type:"GetVideoComponents",inputs:{video:["U:load",0]},_meta:{title:"Split frames + audio"}},
            "U:pre":{class_type:"ImageScaleBy",inputs:{image:["U:comp",0],upscale_method:"area",scale_by:preScale},_meta:{title:"Pre-scale (memory saver)"}},
            "U:model":{class_type:"UpscaleModelLoader",inputs:{model_name:S.upscaleModel},_meta:{title:"Upscale model"}},
            "U:up":{class_type:"ImageUpscaleWithModel",inputs:{upscale_model:["U:model",0],image:["U:pre",0]},_meta:{title:"Upscale frames → target"}},
            "U:cvid":{class_type:"CreateVideo",inputs:{images:["U:up",0],audio:["U:comp",1],fps:["U:comp",2],bit_depth:8},_meta:{title:"Re-mux with original audio"}},
            "U:save":{class_type:"SaveVideo",inputs:{video:["U:cvid",0],filename_prefix:"ComfyUI-MiniMaxH3-OneNode/MiniMax_H3_upscaled",format:"auto",codec:"auto"},_meta:{title:"Save upscaled video"}},
          };
        }
        await _submit(g);
      };

      const generate=async()=>{
        if(S.mode==="upscale") return upscaleGenerate();
        if(S.generating)return;
        errBox.style.display="none";
        const r2v=S.mode==="r2v";
        // model validation
        const unet=r2v?S.unetRef:S.unetFl;
        const need=[unet,S.textEncoder,S.videoVae,S.audioVae];
        if(need.some(v=>!v)){ _activeShowError("Some models aren't selected. Open the Models panel → ↻ Rescan, or pick them manually."); modBody.style.display="block"; modHdr.textContent="▾ Models"; return; }
        if(S.sageAttn&&!_sageAvailable){ _activeShowError("Sage attention is on but MiniMaxH3MemoryEfficientSageAttentionPatch (KJNodes) isn't detected. Install ComfyUI-KJNodes + a recent sageattention, or turn it off in Advanced → Speed."); return; }
        if(S.solAttn&&!_solAvailable){ _activeShowError("Sol-Attn is on but its H3 nodes aren't detected. RESTART ComfyUI so ComfyUI-sol-attn registers (needs Blackwell + Triton), or turn it off in Advanced → Speed."); return; }
        if(S.turboOn&&!(_turboNode&&S.turboLora)){ _activeShowError("Turbo 4-step is on but isn't ready: "+(!_turboNode?"the ComfyUI-MiniMax-H3-Turbo node isn't registered (RESTART ComfyUI).":"no turbo LoRA found in models/loras (hit ↻ Rescan).")+" Or turn Turbo off in Advanced → Speed."); return; }
        if(S.lxTurbo!=="off"){
          const _fl=S.lxTurbo==="fl2v", _lora=_fl?_lxFl2vLora:_lxR2vLora, _okMode=_fl?(S.mode!=="r2v"):(S.mode==="r2v");
          if(!_turboNode){ _activeShowError("The 1-click Turbo preset needs the ComfyUI-MiniMax-H3-Turbo node — RESTART ComfyUI, or set the preset to Off (Advanced → Speed)."); return; }
          if(!_lora){ _activeShowError("The "+(_fl?"FL2V":"R2V")+" Turbo preset LoRA isn't in models/loras — hit ↻ Rescan, or set the preset to Off (Advanced → Speed)."); return; }
          if(!_okMode){ _activeShowError("The "+(_fl?"FL2V":"R2V")+" Turbo preset only runs in "+(_fl?"T2V / I2V":"R2V")+" mode. Switch mode, or set the preset to Off (Advanced → Speed)."); return; }
        }
        if(S.cacheEngine!=="off"){ const _ca={teacache:_teaAvailable,spectrum:_spectrumAvailable,fbc:_fbcAvailable}[S.cacheEngine]; const _cn={teacache:"ComfyUI-MiniMaxH3-TeaCache",spectrum:"ComfyUI-Spectrum-MiniMax-H3",fbc:"ComfyUI-MiniMaxH3-FirstBlockCache"}[S.cacheEngine]; if(!_ca){ _activeShowError("The cache accelerator ("+S.cacheEngine+") isn't detected. Install "+_cn+" in custom_nodes + RESTART ComfyUI, or set Cache to Off in Advanced → Speed."); return; } }
        if(S.twoPass && (S.mode==="t2v"||S.mode==="i2v"||S.mode==="r2v") && !(_ptConcatAvail&&_t8DecodeAvail)){ _activeShowError("Two-pass HD needs ComfyUI-PT_H3ConcatAVLatent + comfyui-minimax-h3-audio-T8 — install both + RESTART ComfyUI, or turn Two-pass off (Video panel)."); return; }
        // mode-specific validation
        if(S.mode==="i2v"&&!S.firstFrame){ _activeShowError("I2V needs a first frame — drop an image in the Frames panel (or switch to T2V)."); return; }
        let refImgNames=[], refVids=[], refAuds=[];
        if(r2v){
          const lim=S.allow9?MAX_REF_IMAGES:REF_IMAGES_SAFE;
          for(let i=0;i<lim;i++){ if(S.refImages[i]) refImgNames.push(S.refImages[i]); }
          S.refVideos.forEach(v=>{ if(v.file) refVids.push({file:v.file,useAudio:!!v.useAudio,start:+v.start||0,end:+v.end||0}); });
          S.refAudios.forEach((a,idx)=>{ if(a){ const t=S.refAudioTrim[idx]||{}; refAuds.push({file:a,start:+t.start||0,end:+t.end||0}); } });
          if(!refImgNames.length&&!refVids.length&&!refAuds.length){ _activeShowError("R2V needs at least one reference (image, video, or audio) in the Reference editor."); return; }
        }

        S.generating=true; genBtn.disabled=true; genBtn.style.opacity=".6"; genBtn.textContent="… generating"; errBox.style.display="none";
        _genStart=Date.now(); _lastPct=0; _lastVal=null; _lastMax=null; renderProg();
        if(_progTimer)clearInterval(_progTimer); _progTimer=setInterval(()=>{ if(S.generating)renderProg(); },1000);

        const wfUrl=r2v?"/minimaxh3/workflow_r2v":"/minimaxh3/workflow_iv";
        let wf;
        try{ const r=await api.fetchApi(wfUrl); if(!r.ok)throw new Error("HTTP "+r.status); wf=await r.json(); }
        catch(e){ _activeShowError("Could not load workflow (404 = restart ComfyUI): "+fmtErr(e)); reset(); return; }
        const prompt=JSON.parse(JSON.stringify(wf));
        const set=(id,k,v)=>{ if(prompt[id])prompt[id].inputs[k]=v; };

        // resolution + length
        const {w,h}=calcRes(S.aspect,S.megapixels,MULTIPLE);
        const len=durToLen(S.duration);
        const seed=S.randomizeSeed?Math.floor(Math.random()*1e15):(+S.seed||0);

        // snapshot the settings behind this render (saved to the clip once it finishes,
        // so the gallery can display them + restore them). seed = the ACTUAL seed used.
        S._pendingMeta=(()=>{
          const _turbo=S.turboOn && _turboNode && !!S.turboLora;
          const mm={v:1,mode:S.mode,prompt:S.prompt||"",aspect:S.aspect,megapixels:S.megapixels,w,h,duration:S.duration,
            steps:(+S.steps||20),sampler:S.sampler,scheduler:S.scheduler,seed:seed,wasRandom:!!S.randomizeSeed,
            sigmaShiftOn:!!(S.sigmaShiftOn&&!_turbo),shiftVideo:S.shiftVideo,shiftAudio:S.shiftAudio,
            sageAttn:!!S.sageAttn,solAttn:!!S.solAttn,fastFp8:!!S.fastFp8,cacheEngine:S.cacheEngine||"off",
            turboOn:!!_turbo,turboSteps:+S.turboSteps||6,turboLora:S.turboLora||"",turboStrength:S.turboStrength,
            twoPass:!!(S.twoPass&&(S.mode==="t2v"||S.mode==="i2v"||S.mode==="r2v")&&_ptConcatAvail&&_t8DecodeAvail),stage1Mp:S.stage1Mp,stage2Mp:S.stage2Mp,stage2Steps:S.stage2Steps,stage2Denoise:S.stage2Denoise};
          if(S.mode==="i2v"){ mm.useLastFrame=!!(S.useLastFrame&&S.lastFrame); mm.firstFrame=S.firstFrame||null; mm.lastFrame=mm.useLastFrame?S.lastFrame:null; }
          if(r2v){ mm.allow9=!!S.allow9; mm.refImageSize=S.refImageSize;
            mm.refImages=S.refImages.slice(0,S.allow9?MAX_REF_IMAGES:REF_IMAGES_SAFE);
            mm.refVideos=S.refVideos.map(v=>({file:v.file||null,useAudio:!!v.useAudio,start:+v.start||0,end:+v.end||0}));
            mm.refAudios=S.refAudios.slice();
            mm.refAudioTrim=S.refAudioTrim.map(t=>({start:(t&&+t.start)||0,end:(t&&+t.end)||0})); }
          return mm;
        })();

        // loaders
        set("M:unet","unet_name",unet);
        // INT8 (W8A8 / convrot) checkpoints carry their own quantization in the file — ComfyUI reads
        // the quant_format and runs its native int8 kernels. Layering fp8 on top would conflict, so
        // force weight_dtype=default for int8 models (the fast-fp8 toggle only applies to fp16/bf16).
        const _int8Unet=/int8|w8a8|convrot/i.test(unet);
        set("M:unet","weight_dtype",(!_int8Unet && S.fastFp8)?"fp8_e4m3fn_fast":"default");
        set("M:clip","clip_name",S.textEncoder);
        set("M:vae","vae_name",S.videoVae);
        set("M:avae","vae_name",S.audioVae);
        // conditioning
        set("M:cond","prompt",S.prompt||"");
        set("M:cond","width",w); set("M:cond","height",h); set("M:cond","length",len);
        if(r2v) set("M:cond","ref_image_size",S.refImageSize);
        // distilled-turbo PRESET (lightx2v) — locked recipe; uses a NORMAL euler sampler + forced
        // sigma shift, NOT the TurboSampler. FL2V rides T2V/I2V; R2V rides R2V and keeps audio refs.
        const lxFl2v = S.lxTurbo==="fl2v" && _turboNode && !!_lxFl2vLora && S.mode!=="r2v";
        const lxR2v  = S.lxTurbo==="r2v"  && _turboNode && !!_lxR2vLora  && S.mode==="r2v";
        const lx = lxFl2v || lxR2v;
        const lxLora = lxFl2v ? _lxFl2vLora : (lxR2v ? _lxR2vLora : "");
        const lxShiftV = lxFl2v ? 6 : 12, lxShiftA = 3;
        // sampler / scheduler / seed / fps — Turbo overrides steps + sampler (preset wins over manual turbo)
        const turbo=S.turboOn && _turboNode && !!S.turboLora && !lx;
        // Turbo LoRA + audio references are incompatible: the H3 model adds a ref_audio
        // modulation-timestep row (AUDIO_COND_TIMESTEP=1.0) that the 4-step Turbo LoRA's
        // adaln injection doesn't account for → tensor-size mismatch (e.g. "a (3) must match
        // b (2)") on the first step. Visual refs are fine (VISUAL_COND_TIMESTEP=0.999 matches
        // the LoRA). So under Turbo we drop audio references (ref-video soundtracks + standalone
        // ref audio) — these are local copies, so the user's "+sound" toggles are untouched — and
        // flag it so we can tell them. Turn Turbo off to include reference audio.
        // Turbo LoRA + audio references are mutually exclusive: the H3 model adds a ref_audio
        // modulation-timestep row (AUDIO_COND_TIMESTEP=1.0) that the 4-step Turbo LoRA never
        // builds, so ANY audio reference crashes it ("tensor a (3) must match b (2)"). Visual
        // refs are fine (VISUAL_COND_TIMESTEP=0.999 matches the LoRA). Don't silently drop the
        // audio the user explicitly wants — stop with a clear either/or so they choose.
        if(turbo && r2v && (refVids.some(v=>v.useAudio) || refAuds.length)){
          _activeShowError("Turbo (4-step) can't use audio references — so R2V with reference-video “+sound” or reference audio can't run while Turbo is on.\n\n•  To USE the reference audio: turn Turbo OFF (Advanced → Speed), then generate.\n•  To KEEP Turbo: turn off “+sound” on the reference videos and clear reference audio (image / video references still work).");
          reset(); return;
        }
        if(turbo){ set("M:sched","scheduler","simple"); set("M:sched","steps",+S.turboSteps||6); }
        else if(lx){ set("M:sched","scheduler","simple"); set("M:sched","steps",4); }
        else { set("M:sched","scheduler",S.scheduler); set("M:sched","steps",+S.steps||20); }
        if(turbo) prompt["M:sampsel"]={class_type:"MiniMaxH3TurboSampler",inputs:{},_meta:{title:"MiniMax H3 Turbo Sampler (4-step)"}};
        else set("M:sampsel","sampler_name",lx?"euler":S.sampler);
        set("M:noise","noise_seed",seed);
        set("M:cvid","fps",FPS);

        // model-patch chain: UNETLoader → [sigma shift] → [sage] → [turbo LoRA] → scheduler/guider.
        // Turbo's sampler hardcodes the 12/3 flow shifts, so custom sigma shift is skipped when it's on.
        let modelSrc=["M:unet",0];
        // Style / character LoRA (any H3-format LoRA) via the H3 applicator, first in the chain.
        // Force merge mode when Turbo is also on: two bypass-LoRA nodes collide on the same
        // "bypass_lora" injection key (the 2nd would replace the 1st), so merge composes safely.
        if(S.styleOn && !!S.styleLora && S.styleLora!=="(none found)" && _turboNode){
          prompt["M:stylelora"]={class_type:"MiniMaxH3TurboLoRA",inputs:{model:modelSrc,lora_name:S.styleLora,strength:+S.styleStrength||1.0,low_vram:(!!S.styleLowVram||turbo)},_meta:{title:"Style LoRA (H3)"}};
          modelSrc=["M:stylelora",0];
        }
        if(lx){
          // preset forces its trained shift (FL2V 6/3, R2V 12/3), overriding any manual shift
          prompt["M:shift"]={class_type:"MiniMaxH3SigmaShift",inputs:{model:modelSrc,shift_video:lxShiftV,shift_audio:lxShiftA},_meta:{title:"MiniMax H3 Sigma Shift (preset)"}};
          modelSrc=["M:shift",0];
        } else if(S.sigmaShiftOn && !turbo){
          prompt["M:shift"]={class_type:"MiniMaxH3SigmaShift",inputs:{model:modelSrc,shift_video:+S.shiftVideo||12,shift_audio:+S.shiftAudio||3},_meta:{title:"MiniMax H3 Sigma Shift"}};
          modelSrc=["M:shift",0];
        }
        if(S.sageAttn){
          prompt["M:sage"]={class_type:"MiniMaxH3MemoryEfficientSageAttentionPatch",inputs:{model:modelSrc},_meta:{title:"MiniMax H3 Sage Attention (mem-efficient)"}};
          modelSrc=["M:sage",0];
        }
        if(S.solAttn){
          // NVIDIA Sol-Attn sparse attention (keeps prompt/ref/audio KV exact) + FFN chunking (−37% MLP peak VRAM).
          prompt["M:sol"]={class_type:"MiniMaxH3MemoryEfficientSolAttentionPatch",inputs:{model:modelSrc,enabled:true,tau:1.0,min_tokens:4096,strict:false,thresh_type:"diag",int8_qk:false,int8_pv:false,sink_conditioning:"exact_kv",dense_blocks:""},_meta:{title:"MiniMax H3 Sol-Attn (sparse)"}};
          modelSrc=["M:sol",0];
          prompt["M:solff"]={class_type:"MiniMaxH3ChunkFeedForward",inputs:{model:modelSrc,enabled:true,chunks:2,min_tokens:8192},_meta:{title:"MiniMax H3 FFN chunking (VRAM saver)"}};
          modelSrc=["M:solff",0];
        }
        if(turbo){
          prompt["M:turbo"]={class_type:"MiniMaxH3TurboLoRA",inputs:{model:modelSrc,lora_name:S.turboLora,strength:+S.turboStrength||1.0,low_vram:!!S.turboLowVram},_meta:{title:"MiniMax H3 Turbo LoRA (4-step)"}};
          modelSrc=["M:turbo",0];
        } else if(lx){
          prompt["M:turbo"]={class_type:"MiniMaxH3TurboLoRA",inputs:{model:modelSrc,lora_name:lxLora,strength:1.0,low_vram:!!S.turboLowVram},_meta:{title:"H3 Distilled Turbo (preset, 4-step)"}};
          modelSrc=["M:turbo",0];
        }
        // Cache accelerator (step reuse) — applied LAST so it wraps the fully-patched model, right
        // before the guider/scheduler. Mutually exclusive; skips redundant transformer work on
        // near-identical timesteps. total_steps must match the scheduler (turbo overrides steps).
        if(S.cacheEngine!=="off"){
          const _steps=turbo?(+S.turboSteps||6):(lx?4:(+S.steps||20));
          if(S.cacheEngine==="teacache" && _teaAvailable){
            prompt["M:cache"]={class_type:"MiniMaxH3TeaCache",inputs:{model:modelSrc,rel_l1_thresh:+S.teaThresh||0.15,start_step:2,end_step:-2,total_steps:_steps},_meta:{title:"TeaCache (step reuse)"}};
            modelSrc=["M:cache",0];
          } else if(S.cacheEngine==="spectrum" && _spectrumAvailable){
            prompt["M:cache"]={class_type:"SpectrumApplyMiniMaxH3",inputs:{model:modelSrc,enabled:true,blend_weight:+S.spectrumBlend||0.5,degree:1,ridge_lambda:0.10,window_size:2.0,flex_window:0.75,warmup_steps:1,tail_actual_steps:1,max_history:8,debug:false,audio_blend_weight:0.0,history_storage:"system_ram",offline_smoothing_replay:true,offline_archive_storage:"system_ram"},_meta:{title:"Spectrum (spectral forecast)"}};
            modelSrc=["M:cache",0];
          } else if(S.cacheEngine==="fbc" && _fbcAvailable){
            prompt["M:cache"]={class_type:"ApplyMiniMaxH3FirstBlockCache",inputs:{model:modelSrc,mode:S.fbcMode||"H3 Fast — 0.10 / max 2",threshold:0.10,start_percent:0.10,end_percent:0.95,max_consecutive_hits:2,temporal_guard:false},_meta:{title:"FirstBlockCache"}};
            modelSrc=["M:cache",0];
          }
        }
        set("M:sched","model",modelSrc); set("M:guider","model",modelSrc);

        // mode inputs
        // Reframe every input image to the output canvas (w×h) so the last frame + all refs
        // perfectly match the first frame's aspect. crop=center = "match" (no distortion).
        let _ffSrc=["M:ff",0], _lfSrc=["M:lf",0];
        const _rfCrop = S.reframe==="stretch" ? "disabled" : (S.reframe==="off" ? null : "center");
        const _reframed=(srcKey,dstKey)=>{ if(!_rfCrop) return [srcKey,0];
          prompt[dstKey]={class_type:"ImageScale",inputs:{image:[srcKey,0],upscale_method:"lanczos",width:w,height:h,crop:_rfCrop},_meta:{title:"Reframe "+w+"x"+h}}; return [dstKey,0]; };
        if(S.mode==="i2v"){
          prompt["M:ff"]={class_type:"LoadImage",inputs:{image:S.firstFrame,upload:"image"},_meta:{title:"First frame"}};
          _ffSrc=_reframed("M:ff","M:ffr"); prompt["M:cond"].inputs.first_frame=_ffSrc;
          if(S.useLastFrame&&S.lastFrame){ prompt["M:lf"]={class_type:"LoadImage",inputs:{image:S.lastFrame,upload:"image"},_meta:{title:"Last frame"}}; _lfSrc=_reframed("M:lf","M:lfr"); prompt["M:cond"].inputs.last_frame=_lfSrc; }
        } else if(r2v){
          // reference images — contiguous ref_image_0..N-1 (dotted autogrow keys)
          refImgNames.forEach((name,i)=>{
            const id="M:ri"+i;
            prompt[id]={class_type:"LoadImage",inputs:{image:name,upload:"image"},_meta:{title:`Ref image ${i+1}`}};
            prompt["M:cond"].inputs["ref_images.ref_image_"+i]=_reframed(id,id+"r");
          });
          // reference videos — LoadVideo -> GetVideoComponents (images + optional paired audio)
          refVids.forEach((v,i)=>{
            const lid="M:rv"+i, cid="M:rvc"+i;
            prompt[lid]={class_type:"LoadVideo",inputs:{file:v.file},_meta:{title:`Ref video ${i+1}`}};
            let vsrc=[lid,0];
            // Reference-video window (seconds). H3 only consumes up to `length` frames of each
            // reference (it slices to frame_count internally), so we ALWAYS cap the decoded window
            // to the output length — otherwise GetVideoComponents decodes the ENTIRE source clip
            // (big VRAM + slow) before the core discards the excess. The low-VRAM toggle caps tighter
            // still (default 4s) so a full 10–15s ref can't overflow 16 GB; off = full output-length
            // window (24 GB+). An explicit end trim always wins if it's shorter. end 0 = to finish.
            const vs=+v.start||0, ve=+v.end||0;
            const _outCap=len/FPS+0.6;                                          // output length (+margin), seconds
            const _capSec=S.refVidCap?Math.min((+S.refVidCapSec||4),_outCap):_outCap;
            const _refWin=(ve>vs)?Math.min(ve-vs,_capSec):_capSec;              // explicit trim wins if shorter
            const sid="M:rvt"+i;
            prompt[sid]={class_type:"Video Slice",inputs:{video:vsrc,start_time:vs,duration:_refWin,strict_duration:false},_meta:{title:`Ref video ${i+1} window (≤${_refWin.toFixed(1)}s)`}};
            vsrc=[sid,0];
            prompt[cid]={class_type:"GetVideoComponents",inputs:{video:vsrc},_meta:{title:`Ref video ${i+1} frames`}};
            prompt["M:cond"].inputs["ref_videos.ref_video_"+i]=[cid,0];
            if(v.useAudio) prompt["M:cond"].inputs["ref_video_audios.ref_video_audio_"+i]=[cid,1];
          });
          // standalone reference audio — LoadAudio
          refAuds.forEach((a,i)=>{
            const id="M:ra"+i;
            prompt[id]={class_type:"LoadAudio",inputs:{audio:a.file},_meta:{title:`Ref audio ${i+1}`}};
            let asrc=[id,0];
            // optional start/end trim (seconds) — end 0 = to the finish (large duration)
            const as=+a.start||0, ae=+a.end||0;
            if(as>0 || ae>as){ const tid="M:rat"+i; prompt[tid]={class_type:"TrimAudioDuration",inputs:{audio:asrc,start_index:as,duration:(ae>as?ae-as:100000)},_meta:{title:`Ref audio ${i+1} trim`}}; asrc=[tid,0]; }
            prompt["M:cond"].inputs["ref_audios.ref_audio_"+i]=asrc;
          });
        }

        // ── Two-pass HD (hires-fix): stage 1 renders low-res, then decode → upscale frames →
        // re-encode the video latent → re-join the stage-1 audio latent → stage-2 partial-denoise
        // refine at the target res. T2V / I2V only (fl2va). Mirrors the proven two-stage workflow
        // (euler + beta, stage 2 = 4 steps / denoise 0.2). Both stages use the SAME frame count. ──
        if(S.twoPass && (S.mode==="t2v"||S.mode==="i2v"||S.mode==="r2v") && _ptConcatAvail && _t8DecodeAvail){
          const _r2v=(S.mode==="r2v");
          // i2v/t2v: stage 1 = LOW draft, stage 2 = target (speed). r2v: stage 1 = target/full
          // (identity), stage 2 = a HIGHER refine res (quality). Frame count is identical either way.
          const s2res=_r2v ? calcRes(S.aspect, Math.max(+S.stage2Mp||1.2, S.megapixels), MULTIPLE) : {w,h};
          if(!_r2v){ const s1=calcRes(S.aspect, Math.min(+S.stage1Mp||0.4, S.megapixels), MULTIPLE); set("M:cond","width",s1.w); set("M:cond","height",s1.h); }
          prompt["M:t8dec"]={class_type:"MiniMaxH3AVDecodeT8",inputs:{av_latent:["M:samp",0],video_vae:["M:vae",0],audio_vae:["M:avae",0]},_meta:{title:"Stage 1 decode → frames + audio latent"}};
          // upscale frames to the stage-2 res — R2V prefers RTX VSR (clean hardware); else Lanczos
          if(_r2v && _rtxAvailable){
            prompt["M:up"]={class_type:"RTXVideoSuperResolution",inputs:{images:["M:t8dec",0],resize_type:"target dimensions","resize_type.width":s2res.w,"resize_type.height":s2res.h,quality:S.rtxQuality||"ULTRA"},_meta:{title:"RTX VSR upscale → refine res"}};
          } else {
            prompt["M:up"]={class_type:"ImageScale",inputs:{image:["M:t8dec",0],upscale_method:"lanczos",width:s2res.w,height:s2res.h,crop:"disabled"},_meta:{title:"Upscale frames → stage-2 res"}};
          }
          prompt["M:enc"]={class_type:"VAEEncode",inputs:{pixels:["M:up",0],vae:["M:vae",0]},_meta:{title:"Re-encode video latent (stage 2)"}};
          prompt["M:concat"]={class_type:"PT_H3ConcatAVLatent",inputs:{video_latent:["M:enc",0],audio_latent:["M:t8dec",3]},_meta:{title:"Re-join AV latent (stage-2 start)"}};
          // stage-2 conditioning: r2v reuses M:cond (ref2va is resolution-independent); i2v/t2v re-encodes keyframes
          let cond2;
          if(_r2v){ cond2=["M:cond",0]; }
          else { const c2={class_type:"MiniMaxH3ImageToVideo",inputs:{clip:["M:clip",0],vae:["M:vae",0],prompt:S.prompt||"",width:s2res.w,height:s2res.h,length:len},_meta:{title:"Stage 2 conditioning (target res)"}};
            if(S.mode==="i2v"){ if(S.firstFrame)c2.inputs.first_frame=_ffSrc; if(S.useLastFrame&&S.lastFrame)c2.inputs.last_frame=_lfSrc; }
            prompt["M:cond2"]=c2; cond2=["M:cond2",0]; }
          prompt["M:sampsel2"]={class_type:"KSamplerSelect",inputs:{sampler_name:"euler"},_meta:{title:"Stage 2 sampler (euler)"}};
          prompt["M:sched2"]={class_type:"BasicScheduler",inputs:{model:modelSrc,scheduler:"beta",steps:+S.stage2Steps||4,denoise:+S.stage2Denoise||0.2},_meta:{title:"Stage 2 scheduler (partial denoise)"}};
          prompt["M:guider2"]={class_type:"BasicGuider",inputs:{model:modelSrc,conditioning:cond2},_meta:{title:"Stage 2 guider"}};
          prompt["M:noise2"]={class_type:"RandomNoise",inputs:{noise_seed:(seed+1)%1000000000000000},_meta:{title:"Stage 2 noise"}};
          prompt["M:samp2"]={class_type:"SamplerCustomAdvanced",inputs:{noise:["M:noise2",0],guider:["M:guider2",0],sampler:["M:sampsel2",0],sigmas:["M:sched2",0],latent_image:["M:concat",0]},_meta:{title:"Stage 2 refine"}};
          set("M:vdec","samples",["M:samp2",0]); set("M:adec","samples",["M:samp2",0]);   // decode stage-2 output
        }

        try{
          const r=await api.fetchApi("/prompt",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});
          if(!r.ok){ const t=await r.text(); throw new Error(t); }
          const d=await r.json(); _activePromptId=d.prompt_id||null; _activeRunning=true;
          startCompletionWatch();   // guaranteed reset when our prompt leaves the queue
        }catch(e){ _activeShowError("ComfyUI rejected the graph:\n"+fmtErr(e)); _activeRunning=false; reset(); }
      };
      genBtn.onclick=generate;

      // ── keyboard shortcuts — capture:true so events reach us BEFORE ComfyUI's canvas
      // handler swallows them (that was why they didn't fire); hover read live via :hover. ──
      const _isEditable=(el)=> el && (el.tagName==="INPUT"||el.tagName==="TEXTAREA"||el.tagName==="SELECT"||el.isContentEditable);
      const _keyHandler=(e)=>{
        if(_lbIsOpen()) return;   // the detail lightbox owns the keyboard while it's open
        const fsOpen=fsOverlay.style.display!=="none", galOpen=galModal.style.display!=="none";
        if(e.key==="Escape"){ if(_nodeFS){_exitNodeFS();e.preventDefault();} else if(fsOpen){closeFullscreen();e.preventDefault();} else if(galOpen){_galSelectCb=null;galModal.style.display="none";e.preventDefault();} return; }
        if(_isEditable(e.target)) return;
        let over=false; try{ over=root.matches(":hover"); }catch(_e){}
        if(!over && !fsOpen && !galOpen && !_nodeFS) return;
        const k=(e.key||"").toLowerCase();
        if(k==="f"){ _toggleNodeFS(); e.preventDefault(); }
        else if(k==="g"){ if(galOpen){_galSelectCb=null;galModal.style.display="none";} else openGalleryModal(); e.preventDefault(); }
        else if((e.key===" "||e.code==="Space")&&!e.repeat){ if(!S.generating)generate(); e.preventDefault(); }
      };
      document.addEventListener("keydown",_keyHandler,{capture:true});
      // a subtle shortcuts hint under the buttons
      const shortcutsHint=tx(mk("div",{fontSize:"8.5px",color:C.muted,textAlign:"center",margin:"7px 0 0",letterSpacing:".03em"}),"Space · generate    F · fullscreen    G · gallery");
      right.appendChild(shortcutsHint);

      // assemble
      // ── credit footer (lower-third) — author + support links ──
      const footer=mk("div",{display:"flex",alignItems:"center",justifyContent:"center",gap:"9px",padding:"6px 10px",borderTop:"1px solid "+C.border,fontSize:"10px",color:C.muted,flex:"0 0 auto",background:C.bg1});
      const _credLink=(label,url,color)=>{ const a=tx(mk("a",{color:color,textDecoration:"none",fontWeight:"700",cursor:"pointer"},{href:url,target:"_blank",rel:"noopener noreferrer"}),label); a.onmouseenter=()=>{a.style.textDecoration="underline";}; a.onmouseleave=()=>{a.style.textDecoration="none";}; a.onclick=(e)=>{ e.preventDefault(); e.stopPropagation(); window.open(url,"_blank","noopener"); }; return a; };
      footer.append(
        tx(mk("span",{color:C.muted}),"made by"),
        tx(mk("span",{fontWeight:"800",color:C.text,letterSpacing:".02em"}),"The New Game Plus"),
        tx(mk("span",{color:C.border}),"·"),
        _credLink("☕ Ko-fi","https://ko-fi.com/thenewgameplus","#ff5e5b"),
        tx(mk("span",{color:C.border}),"·"),
        _credLink("▶ YouTube","https://www.youtube.com/@TheNewGamePluss","#ff4444"),
      );
      root.append(header,body,footer);
      const _w=this.addDOMWidget("mmh3_ui","div",root,{getValue(){return null;},setValue(){},serialize:false});
      // computeSize must be assigned ON the widget (options.computeSize is ignored by this
      // ComfyUI frontend). It returns the PERSISTED target size (from S.nodeSize, floored at
      // the min) so the node holds a real default and keeps whatever the user drags it to —
      // onResize writes the new target back into S.nodeSize.
      _w.computeSize=function(){ const t=S.nodeSize||[NODE_W,NODE_H]; return [Math.max(MIN_W,t[0]),Math.max(MIN_H-TITLE_H,t[1]-TITLE_H)]; };
      this.setSize((S.nodeSize&&S.nodeSize.length===2)?S.nodeSize.slice():[NODE_W,NODE_H]);

      // init
      renderRefImages(); renderRefVideos(); renderRefAudios();
      setMode(S.mode); updateRes(); updateDur(); rebuildTagRow(); updateSpeedNotes(); updateCacheUI(); updateTwoPassUI();
      _loadModels(); _loadTemplates(); _loadGallery();
      // probe the KJNodes sage-attention patch so its toggle can guide/guard the user
      api.fetchApi("/object_info/MiniMaxH3MemoryEfficientSageAttentionPatch").then(r=>r.ok?r.json():{}).then(d=>{ _sageAvailable=!!(d&&d.MiniMaxH3MemoryEfficientSageAttentionPatch); updateSpeedNotes(); }).catch(()=>{ _sageAvailable=false; updateSpeedNotes(); });
      api.fetchApi("/object_info/MiniMaxH3MemoryEfficientSolAttentionPatch").then(r=>r.ok?r.json():{}).then(d=>{ _solAvailable=!!(d&&d.MiniMaxH3MemoryEfficientSolAttentionPatch); updateSpeedNotes(); }).catch(()=>{ _solAvailable=false; updateSpeedNotes(); });
      // probe SeedVR2 so the Upscale tab's engine can guide/guard the user
      api.fetchApi("/object_info/SeedVR2VideoUpscaler").then(r=>r.ok?r.json():{}).then(d=>{ _svrAvailable=!!(d&&d.SeedVR2VideoUpscaler); if(S.mode==="upscale")setUpEngine(S.upscaleEngine); }).catch(()=>{ _svrAvailable=false; });
      api.fetchApi("/object_info/FlashVSRNode").then(r=>r.ok?r.json():{}).then(d=>{ _fvsrAvailable=!!(d&&d.FlashVSRNode); if(S.mode==="upscale")setUpEngine(S.upscaleEngine); }).catch(()=>{ _fvsrAvailable=false; });
      api.fetchApi("/object_info/RTXVideoSuperResolution").then(r=>r.ok?r.json():{}).then(d=>{ _rtxAvailable=!!(d&&d.RTXVideoSuperResolution); if(S.mode==="upscale")setUpEngine(S.upscaleEngine); }).catch(()=>{ _rtxAvailable=false; });
      // probe the Turbo sampler node so the Turbo toggle can guide/guard the user
      api.fetchApi("/object_info/MiniMaxH3TurboSampler").then(r=>r.ok?r.json():{}).then(d=>{ _turboNode=!!(d&&d.MiniMaxH3TurboSampler); updateSpeedNotes(); }).catch(()=>{ _turboNode=false; updateSpeedNotes(); });
      // probe the cache-accelerator nodes (TeaCache / Spectrum / FirstBlockCache) for the selector
      api.fetchApi("/object_info/MiniMaxH3TeaCache").then(r=>r.ok?r.json():{}).then(d=>{ _teaAvailable=!!(d&&d.MiniMaxH3TeaCache); updateCacheUI(); }).catch(()=>{ _teaAvailable=false; updateCacheUI(); });
      api.fetchApi("/object_info/SpectrumApplyMiniMaxH3").then(r=>r.ok?r.json():{}).then(d=>{ _spectrumAvailable=!!(d&&d.SpectrumApplyMiniMaxH3); updateCacheUI(); }).catch(()=>{ _spectrumAvailable=false; updateCacheUI(); });
      api.fetchApi("/object_info/ApplyMiniMaxH3FirstBlockCache").then(r=>r.ok?r.json():{}).then(d=>{ _fbcAvailable=!!(d&&d.ApplyMiniMaxH3FirstBlockCache); updateCacheUI(); }).catch(()=>{ _fbcAvailable=false; updateCacheUI(); });
      // two-pass HD nodes (PT_H3ConcatAVLatent + MiniMaxH3AVDecodeT8)
      api.fetchApi("/object_info/PT_H3ConcatAVLatent").then(r=>r.ok?r.json():{}).then(d=>{ _ptConcatAvail=!!(d&&d.PT_H3ConcatAVLatent); updateTwoPassUI(); }).catch(()=>{ _ptConcatAvail=false; updateTwoPassUI(); });
      api.fetchApi("/object_info/MiniMaxH3AVDecodeT8").then(r=>r.ok?r.json():{}).then(d=>{ _t8DecodeAvail=!!(d&&d.MiniMaxH3AVDecodeT8); updateTwoPassUI(); }).catch(()=>{ _t8DecodeAvail=false; updateTwoPassUI(); });

      window.__mmh3_nodes[this.id]={root,S,_t0:Date.now(),fns:{
        reset,setProgress:_activeSetProgress,showVideo:_activeShowVideo,showError:_activeShowError,persist,refreshGallery:_loadGallery,
        // test/debug hooks — drive the injection path headlessly
        generate,setMode,calcRes,durToLen,setSageAvailable:(v)=>{_sageAvailable=v;updateSpeedNotes();},setTurboAvailable:(v)=>{_turboNode=v;updateSpeedNotes();},
      }};
      _bindActive(window.__mmh3_nodes[this.id]);
    };
  },
});

function _bindActive(cached){
  if(!cached)return;
  _activeReset=cached.fns.reset||_activeReset;
  _activeShowVideo=cached.fns.showVideo||_activeShowVideo;
  _activeShowError=cached.fns.showError||_activeShowError;
  _activeRefreshGallery=cached.fns.refreshGallery||_activeRefreshGallery;
}
