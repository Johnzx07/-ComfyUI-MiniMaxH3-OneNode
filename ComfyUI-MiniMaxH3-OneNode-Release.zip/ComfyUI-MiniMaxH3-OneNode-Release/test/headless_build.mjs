// Headless build/TDZ smoke test for web/minimaxh3_one_node.js.
// Stubs ComfyUI's app/api + a minimal DOM, strips the two ESM imports, then runs
// the extension's onNodeCreated/_buildUI to catch reference errors, TDZ, and
// undefined-global mistakes WITHOUT a GPU or a running ComfyUI. It then drives the
// injection path (generate) across T2V / I2V / FLF / R2V and validates the emitted
// API graph — including the dotted COMFY_AUTOGROW_V3 reference keys.
//
//   node test/headless_build.mjs   ->  exit 0 on success, 1 on any thrown error.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.join(__dirname, "..", "web", "minimaxh3_one_node.js");
const IV = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "workflows", "iv.json"), "utf8"));
const R2V = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "workflows", "r2v.json"), "utf8"));

// ── minimal DOM ───────────────────────────────────────────────────────────────
function makeEl(tag){
  const el={
    tagName:(tag||"div").toUpperCase(), style:{}, children:[], _listeners:{},
    textContent:"", innerHTML:"", value:"", className:"", id:"",
    selectionStart:0, selectionEnd:0, files:[], step:"", min:"", max:"", type:"",
    classList:{ add(){}, remove(){}, toggle(){}, contains(){return false;} },
    appendChild(c){ this.children.push(c); c.parentElement=this; return c; },
    append(...cs){ cs.forEach(c=>this.appendChild(c)); },
    prepend(c){ this.children.unshift(c); c.parentElement=this; return c; },
    removeChild(c){ const i=this.children.indexOf(c); if(i>=0)this.children.splice(i,1); return c; },
    replaceChild(n,o){ const i=this.children.indexOf(o); if(i>=0)this.children[i]=n; else this.children.push(n); n.parentElement=this; return o; },
    remove(){ if(this.parentElement)this.parentElement.removeChild(this); },
    get lastChild(){ return this.children[this.children.length-1]||null; },
    get firstChild(){ return this.children[0]||null; },
    addEventListener(t,fn){ (this._listeners[t]||(this._listeners[t]=[])).push(fn); },
    removeEventListener(){},
    querySelector(){ return null; },
    querySelectorAll(){ return []; },
    getBoundingClientRect(){ return {left:0,top:0,width:100,height:100,right:100,bottom:100}; },
    focus(){}, blur(){}, select(){}, click(){}, scrollIntoView(){},
    setAttribute(){}, getAttribute(){return null;}, removeAttribute(){},
    insertBefore(n){ this.children.unshift(n); n.parentElement=this; return n; },
    cloneNode(){ return makeEl(this.tagName); },
    get offsetWidth(){ return 100; }, get offsetHeight(){ return 100; },
    set onclick(fn){ this._onclick=fn; }, get onclick(){ return this._onclick; },
    set onchange(fn){ this._onchange=fn; }, get onchange(){ return this._onchange; },
    set oninput(fn){ this._oninput=fn; }, get oninput(){ return this._oninput; },
    set onmouseenter(fn){}, set onmouseleave(fn){},
  };
  return el;
}
const idMap={};
const documentStub={
  _byId:idMap,
  createElement(t){ return makeEl(t); },
  createElementNS(_ns,t){ return makeEl(t); },
  getElementById(id){ return idMap[id]||null; },
  querySelector(){ return null; }, querySelectorAll(){ return []; },
  addEventListener(){}, removeEventListener(){},
  head:makeEl("head"), body:makeEl("body"),
};
const _origCreate=documentStub.createElement.bind(documentStub);
documentStub.createElement=(t)=>{ const e=_origCreate(t); Object.defineProperty(e,"id",{get(){return e._id||"";},set(v){ e._id=v; if(v)idMap[v]=e; }}); return e; };

// ── app / api stubs ───────────────────────────────────────────────────────────
const objectInfo={ MiniMaxH3SigmaShift:{}, MiniMaxH3MemoryEfficientSageAttentionPatch:{}, MiniMaxH3TurboSampler:{}, SeedVR2VideoUpscaler:{} };
let lastPrompt=null; // captures the graph submitted to /prompt
const apiStub={
  _l:{}, addEventListener(t,fn){ (this._l[t]||(this._l[t]=[])).push(fn); },
  async fetchApi(url,opts){
    if(url.includes("/object_info/")){ const k=url.split("/object_info/")[1]; return { ok:true, json:async()=>(objectInfo[k]?{[k]:objectInfo[k]}:{}) }; }
    if(url.includes("/minimaxh3/models")) return { ok:true, json:async()=>({
      diffusion_models:["minimax_h3_fl2va_pruned_fp8_scaled.safetensors","minimax_h3_ref2va_pruned_fp8_scaled.safetensors"],
      text_encoders:["qwen3vl_32b_minimax_h3_int8_convrot.safetensors"],
      vaes:["minimax_h3_video_vae_fp16.safetensors","minimax_h3_audio_vae_fp32.safetensors"],
      upscale_models:["4x_foolhardy_Remacri.pth"],
      loras:["minimax_h3_turbo_4step_ckpt500.safetensors"]}) };
    if(url.includes("/minimaxh3/config")) return { ok:true, json:async()=>({prompt_templates:[{name:"T",prompt:"hello"}],r2v_prompt_templates:[{name:"R",prompt:"<Picture 1> hi"}]}) };
    if(url.includes("/minimaxh3/outputs")) return { ok:true, json:async()=>({videos:[{filename:"MiniMax_H3_00001.mp4",subfolder:"ComfyUI-MiniMaxH3-OneNode",type:"output"}]}) };
    if(url.includes("/minimaxh3/workflow_r2v")) return { ok:true, json:async()=>JSON.parse(JSON.stringify(R2V)) };
    if(url.includes("/minimaxh3/workflow_iv"))  return { ok:true, json:async()=>JSON.parse(JSON.stringify(IV)) };
    if(url.includes("/upload/image")) return { ok:true, json:async()=>({name:"up.png",subfolder:"",type:"input"}) };
    if(url.includes("/prompt")&&opts&&opts.body){ try{ lastPrompt=JSON.parse(opts.body).prompt; }catch(e){} return { ok:true, json:async()=>({prompt_id:"pid"}), text:async()=>"" }; }
    return { ok:true, text:async()=>"{}", json:async()=>({}) };
  },
};
let captured=null;
const appStub={ registerExtension(def){ captured=def; }, graph:{ getNodeById(){ return null; }, links:{} } };

function makeNode(id,proto){
  const n=Object.create(proto||Object.prototype);
  Object.assign(n,{ id, widgets:[], inputs:[], outputs:[], size:[0,0],
    addDOMWidget(){ return {}; }, setSize(s){ this.size=s; }, addWidget(){ return {}; },
    onConnectionsChange:null });
  return n;
}

const ctx={
  app:appStub, api:apiStub, window:{}, document:documentStub,
  LiteGraph:{ NODE_SLOT_HEIGHT:20 }, console,
  requestAnimationFrame:(fn)=>{ try{ fn(); }catch(e){} return 1; },
  setTimeout:(fn)=>{ return 0; }, clearTimeout(){},
  URL:{ createObjectURL(){ return "blob:stub"; }, revokeObjectURL(){} },
  FormData:class{ append(){} },
  MutationObserver:class{ observe(){} disconnect(){} },
  localStorage:{ _d:{}, getItem(k){ return this._d[k]||null; }, setItem(k,v){ this._d[k]=v; }, removeItem(k){ delete this._d[k]; } },
  Math, JSON, Object, Array, String, Number, Boolean, Date, Promise, Set, Map, parseInt, parseFloat, isNaN, encodeURIComponent,
};
ctx.window.__mmh3_nodes=undefined;
ctx.window.localStorage=ctx.localStorage;

let src=fs.readFileSync(SRC,"utf8");
src=src.replace(/^\s*import\s+\{[^}]*\}\s+from\s+["'][^"']+["'];\s*$/gm,"");

const names=Object.keys(ctx);
const fn=new Function(...names, '"use strict";\n'+src+"\nreturn { get captured(){ return captured; } };");
let mod;
try{ mod=fn(...names.map(n=>ctx[n])); }
catch(e){ console.error("✗ Module top-level evaluation threw:\n",e); process.exit(1); }

const cls=(p,id)=>p&&p[id]&&p[id].class_type;
const assert=(c,m)=>{ if(!c) throw new Error(m); };

(async()=>{
  try{
    if(!captured) throw new Error("registerExtension was not called");
    // wrong node name early-returns (no throw, no hook)
    const proto1={};
    await captured.beforeRegisterNodeDef({prototype:proto1},{name:"SomeOtherNode"});
    if(proto1.onNodeCreated) throw new Error("hooked a foreign node");

    const proto={};
    await captured.beforeRegisterNodeDef({prototype:proto},{name:"MiniMaxH3OneNode"});
    assert(typeof proto.onNodeCreated==="function","onNodeCreated not installed");

    // first build (fresh)
    const n1=makeNode(11,proto); proto.onNodeCreated.call(n1);
    await new Promise(r=>setTimeout(r,0)); await Promise.resolve(); await Promise.resolve();

    // cached-path build (same id) + a fresh second instance
    const n2=makeNode(11,proto); proto.onNodeCreated.call(n2);
    const n3=makeNode(22,proto); proto.onNodeCreated.call(n3);
    await Promise.resolve();
    if(proto.onResize) proto.onResize.call(n1);
    if(proto.getSlotMenuOptions) proto.getSlotMenuOptions.call(n1);

    const cache=ctx.window.__mmh3_nodes[11];
    assert(cache&&cache.fns&&cache.fns.generate,"generate hook not exposed");
    const fns=cache.fns, S=cache.S;

    // sanity: resolution + length math matches the python
    const r=fns.calcRes("16:9 (Widescreen)",0.4,32);
    assert(r.w===864&&r.h===480,"calcRes 0.4/16:9 expected 864x480, got "+r.w+"x"+r.h);
    assert(fns.durToLen(5)===124,"durToLen(5) expected 124, got "+fns.durToLen(5));
    assert(fns.durToLen(15)===362,"durToLen(15) expected 362, got "+fns.durToLen(15));

    S.prompt="a cinematic shot, footsteps and wind";

    // ── T2V ────────────────────────────────────────────────────────────────
    fns.setMode("t2v"); fns.reset();
    lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(lastPrompt,"T2V did not submit");
    assert(cls(lastPrompt,"M:cond")==="MiniMaxH3ImageToVideo","T2V cond node wrong: "+cls(lastPrompt,"M:cond"));
    assert(lastPrompt["M:unet"].inputs.unet_name.includes("fl2va"),"T2V should use fl2va model");
    assert(lastPrompt["M:cond"].inputs.width===864&&lastPrompt["M:cond"].inputs.height===480,"T2V res not injected");
    assert(lastPrompt["M:cond"].inputs.length===124,"T2V length not 124");
    assert(!lastPrompt["M:ff"],"T2V must not add a first frame");
    assert(cls(lastPrompt,"M:guider")==="BasicGuider","T2V guider missing");
    assert(lastPrompt["M:cvid"].inputs.fps===24,"fps must be 24");
    assert(lastPrompt["M:sched"].inputs.scheduler==="simple","T2V scheduler should default simple");

    // ── I2V (first frame only) ───────────────────────────────────────────────
    fns.setMode("i2v"); S.firstFrame="start.png"; S.useLastFrame=false; S.lastFrame=null; fns.reset();
    lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(lastPrompt,"I2V did not submit");
    assert(cls(lastPrompt,"M:ff")==="LoadImage","I2V first frame loader missing");
    assert(JSON.stringify(lastPrompt["M:cond"].inputs.first_frame)===JSON.stringify(["M:ff",0]),"I2V first_frame not wired");
    assert(!lastPrompt["M:lf"],"I2V without last frame must not add M:lf");

    // ── FLF (first + last) ───────────────────────────────────────────────────
    S.useLastFrame=true; S.lastFrame="end.png"; fns.reset();
    lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(cls(lastPrompt,"M:lf")==="LoadImage","FLF last frame loader missing");
    assert(JSON.stringify(lastPrompt["M:cond"].inputs.last_frame)===JSON.stringify(["M:lf",0]),"FLF last_frame not wired");

    // I2V without a frame must be BLOCKED
    S.firstFrame=null; S.useLastFrame=false; fns.reset();
    lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(!lastPrompt,"I2V without a first frame should be blocked");
    S.firstFrame="start.png";

    // ── R2V (references) ─────────────────────────────────────────────────────
    fns.setMode("r2v");
    assert(S.scheduler==="beta","R2V should default scheduler to beta");
    S.allow9=false;
    S.refImages=["p1.png","p2.png","p3.png",null,null,null,null,null,null];
    S.refVideos=[{file:"clip.mp4",useAudio:true},{file:null,useAudio:true},{file:null,useAudio:true}];
    S.refAudios=["voice.wav",null,null];
    S.refImageSize="max";
    fns.reset();
    lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(lastPrompt,"R2V did not submit");
    assert(cls(lastPrompt,"M:cond")==="MiniMaxH3ReferenceToVideo","R2V cond wrong: "+cls(lastPrompt,"M:cond"));
    assert(lastPrompt["M:unet"].inputs.unet_name.includes("ref2va"),"R2V should use ref2va model");
    assert(lastPrompt["M:cond"].inputs.ref_image_size==="max","R2V ref_image_size not injected");
    // dotted autogrow keys — the make-or-break detail
    const ci=lastPrompt["M:cond"].inputs;
    assert(JSON.stringify(ci["ref_images.ref_image_0"])===JSON.stringify(["M:ri0",0]),"ref_images.ref_image_0 not wired");
    assert(JSON.stringify(ci["ref_images.ref_image_1"])===JSON.stringify(["M:ri1",0]),"ref_images.ref_image_1 not wired");
    assert(JSON.stringify(ci["ref_images.ref_image_2"])===JSON.stringify(["M:ri2",0]),"ref_images.ref_image_2 not wired");
    assert(ci["ref_images.ref_image_3"]===undefined,"empty image slots must not be wired");
    assert(cls(lastPrompt,"M:ri0")==="LoadImage"&&lastPrompt["M:ri0"].inputs.image==="p1.png","ref image loader wrong");
    // video -> LoadVideo + GetVideoComponents, paired audio on slot 1
    assert(cls(lastPrompt,"M:rv0")==="LoadVideo"&&lastPrompt["M:rv0"].inputs.file==="clip.mp4","ref video loader wrong");
    assert(cls(lastPrompt,"M:rvc0")==="GetVideoComponents","GetVideoComponents missing");
    assert(JSON.stringify(ci["ref_videos.ref_video_0"])===JSON.stringify(["M:rvc0",0]),"ref_videos.ref_video_0 not wired to frames");
    assert(JSON.stringify(ci["ref_video_audios.ref_video_audio_0"])===JSON.stringify(["M:rvc0",1]),"paired video audio not wired");
    // standalone audio
    assert(cls(lastPrompt,"M:ra0")==="LoadAudio"&&lastPrompt["M:ra0"].inputs.audio==="voice.wav","ref audio loader wrong");
    assert(JSON.stringify(ci["ref_audios.ref_audio_0"])===JSON.stringify(["M:ra0",0]),"ref_audios.ref_audio_0 not wired");

    // R2V with NO references must be blocked
    S.refImages=[null,null,null,null,null,null,null,null,null];
    S.refVideos=[{file:null,useAudio:true},{file:null,useAudio:true},{file:null,useAudio:true}];
    S.refAudios=[null,null,null];
    fns.reset();
    lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(!lastPrompt,"R2V with no references should be blocked");

    // ── sigma shift injection (on T2V) ───────────────────────────────────────
    fns.setMode("t2v"); S.sigmaShiftOn=true; S.shiftVideo=10; S.shiftAudio=2.5; fns.reset();
    lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(cls(lastPrompt,"M:shift")==="MiniMaxH3SigmaShift","sigma shift node missing");
    assert(lastPrompt["M:shift"].inputs.shift_video===10&&lastPrompt["M:shift"].inputs.shift_audio===2.5,"sigma shift values wrong");
    assert(JSON.stringify(lastPrompt["M:sched"].inputs.model)===JSON.stringify(["M:shift",0]),"scheduler not repointed to sigma shift");
    assert(JSON.stringify(lastPrompt["M:guider"].inputs.model)===JSON.stringify(["M:shift",0]),"guider not repointed to sigma shift");
    S.sigmaShiftOn=false;

    // ── speed toggles: Blackwell fast fp8 + sage attention (chained after sigma shift) ──
    S.sigmaShiftOn=false; S.fastFp8=true; S.sageAttn=true; fns.reset();
    lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(lastPrompt,"speed-toggle run did not submit");
    assert(lastPrompt["M:unet"].inputs.weight_dtype==="fp8_e4m3fn_fast","fast fp8 weight_dtype not set");
    assert(cls(lastPrompt,"M:sage")==="MiniMaxH3MemoryEfficientSageAttentionPatch","sage node missing");
    assert(JSON.stringify(lastPrompt["M:sage"].inputs.model)===JSON.stringify(["M:unet",0]),"sage should chain off unet when no sigma shift");
    assert(JSON.stringify(lastPrompt["M:sched"].inputs.model)===JSON.stringify(["M:sage",0]),"scheduler not repointed to sage");
    assert(JSON.stringify(lastPrompt["M:guider"].inputs.model)===JSON.stringify(["M:sage",0]),"guider not repointed to sage");
    // fp8 off → default dtype
    S.fastFp8=false; fns.reset(); lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(lastPrompt["M:unet"].inputs.weight_dtype==="default","fp8 off should be default dtype");
    // sigma shift + sage together → unet → shift → sage → sampler
    S.sigmaShiftOn=true; S.sageAttn=true; fns.reset(); lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(JSON.stringify(lastPrompt["M:shift"].inputs.model)===JSON.stringify(["M:unet",0]),"shift should chain off unet");
    assert(JSON.stringify(lastPrompt["M:sage"].inputs.model)===JSON.stringify(["M:shift",0]),"sage should chain off sigma shift");
    assert(JSON.stringify(lastPrompt["M:guider"].inputs.model)===JSON.stringify(["M:sage",0]),"guider should end at sage");
    // sage unavailable → blocked
    S.sigmaShiftOn=false; fns.setSageAvailable(false); fns.reset(); lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(!lastPrompt,"sage on but unavailable should block generate");
    fns.setSageAvailable(true); S.sageAttn=false; S.fastFp8=false;

    // ── Turbo 4-step LoRA: injects LoRA + swaps sampler + steps, skips sigma shift ──
    fns.setMode("t2v"); fns.setTurboAvailable(true);
    S.turboOn=true; S.turboLora="minimax_h3_turbo_4step_ckpt500.safetensors"; S.turboSteps=6;
    S.sigmaShiftOn=true; /* must be skipped under turbo */ fns.reset();
    lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(lastPrompt,"Turbo run did not submit");
    assert(cls(lastPrompt,"M:turbo")==="MiniMaxH3TurboLoRA","Turbo LoRA node missing");
    assert(lastPrompt["M:turbo"].inputs.lora_name==="minimax_h3_turbo_4step_ckpt500.safetensors","turbo lora_name wrong");
    assert(cls(lastPrompt,"M:sampsel")==="MiniMaxH3TurboSampler","sampler not swapped to Turbo sampler");
    assert(lastPrompt["M:sched"].inputs.steps===6,"turbo steps not applied");
    assert(lastPrompt["M:sched"].inputs.scheduler==="simple","turbo must force scheduler simple");
    assert(!lastPrompt["M:shift"],"custom sigma shift must be skipped under Turbo");
    assert(JSON.stringify(lastPrompt["M:guider"].inputs.model)===JSON.stringify(["M:turbo",0]),"guider not fed by turbo LoRA");
    // Turbo on but node missing → blocked
    fns.setTurboAvailable(false); fns.reset(); lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(!lastPrompt,"Turbo on but node missing should block");
    fns.setTurboAvailable(true);
    // Turbo off → normal sampler restored
    S.turboOn=false; S.sigmaShiftOn=false; fns.reset(); lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(cls(lastPrompt,"M:sampsel")==="KSamplerSelect","non-turbo should use KSamplerSelect");
    assert(!lastPrompt["M:turbo"],"turbo node should be absent when off");

    // ── resolution table + resize math sanity ────────────────────────────────
    assert(fns.calcRes("9:16 (Portrait Widescreen)",0.4,32).w < fns.calcRes("9:16 (Portrait Widescreen)",0.4,32).h,"portrait aspect should be taller than wide");

    // ── missing-model guard ──────────────────────────────────────────────────
    S.videoVae=""; fns.reset();
    lastPrompt=null; await fns.generate(); await Promise.resolve();
    assert(!lastPrompt,"missing model should block generate");

    console.log("✓ MiniMax H3 headless build OK — _buildUI (fresh/cached/2nd) + generate across T2V / I2V / FLF / R2V validated: fl2va vs ref2va model routing, res/length math (864x480 / 124-362), dotted COMFY_AUTOGROW_V3 ref keys (images/videos+paired-audio/standalone-audio), sigma-shift injection & repoint, and the frame/reference/model guards.");
    process.exit(0);
  }catch(e){
    console.error("✗ build test failed:\n",e);
    process.exit(1);
  }
})();
